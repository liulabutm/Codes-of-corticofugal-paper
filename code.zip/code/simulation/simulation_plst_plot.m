function [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change)
% baseline_substract=1;
% intp_times=100; % intepolation data to make the time scale fit in with tau (intepolate data 50 times to make the time scale in 0.002s)
plot_sup10a_flag=1;
x=[1:size(spk_TN_before,2)]; % original frame number        
xq=[1:((size(spk_TN_before,2)-1)/(intp_times*size(spk_TN_before,2)-1)):size(spk_TN_before,2)]; % new frame number
spk_TN_before_intp=zeros(size(spk_TN_before,1),size(spk_TN_before,2)*intp_times);
for i=1:size(spk_TN_before,1)
    v=squeeze(spk_TN_before(i,:)); % original firing rate
    spk_TN_before_intp(i,:)=interp1(x,v,xq); % new firing rate
end

%%%%%%% u %%%%%%%%
% % sort spk with prefdir
% for j=1:direction_group_num
% %     figure; hold on;
%     temp=[];
%     temp_aft=[];
%     for i=1:size(prefdir_ind,1)
%         if prefdir_ind(i,1)==j
%             temp(end+1,:)=spk_TN_before_intp(i,:);
%             
% %             temp_aft(end+1,:)=spk_TN_before_intp(i,:)*amp_change(1,j);
% %             plot([1:50], spk_TN_before(i,:))
%         end
%     end
%     
%     spk_aveneuron_bef_temp(j,:)=mean(temp,1);
% %     spk_aveneuron_bef(j,:)=spk_aveneuron_bef_temp(j,:);
%     spk_aveneuron_bef(j,:)=spk_aveneuron_bef_temp(j,:)-mean(spk_aveneuron_bef_temp(j,5*intp_times:10*intp_times),2);
%     spk_aveneuron_aft(j,:)=spk_aveneuron_bef(j,:)*amp_change(1,j);
%     for i=1:size(spk_aveneuron_bef,2)
%         if spk_aveneuron_bef(j,i)<0
%             spk_aveneuron_bef(j,i)=0;
%         end
%         if spk_aveneuron_aft(j,i)<0
%             spk_aveneuron_aft(j,i)=0;
%         end
%     end
% %     figure;
% %      plot([500:5000],spk_aveneuron_bef(j,500:5000))
% %      hold on
% %      plot([500:5000],spk_aveneuron_aft(j,500:5000))
% end

if baseline_substract
    if plot_sup10a_flag
        figure;
    end
    for j=1:direction_group_num
    %     figure; hold on;
        temp=[];
        temp_aft=[];
        for i=1:size(prefdir_ind,1)
            if prefdir_ind(i,1)==j
                temp(end+1,:)=spk_TN_before_intp(i,:);

    %             temp_aft(end+1,:)=spk_TN_before_intp(i,:)*amp_change(1,j);
    %             plot([1:50], spk_TN_before(i,:))
            end
        end

        spk_aveneuron_bef_temp(j,:)=mean(temp,1);
    %     spk_aveneuron_bef(j,:)=spk_aveneuron_bef_temp(j,:);
        spk_aveneuron_bef(j,:)=spk_aveneuron_bef_temp(j,:)-mean(spk_aveneuron_bef_temp(j,5*intp_times:10*intp_times),2);
        spk_aveneuron_aft(j,:)=spk_aveneuron_bef(j,:)*amp_change(1,j);
        for i=1:size(spk_aveneuron_bef,2)
            if spk_aveneuron_bef(j,i)<0
                spk_aveneuron_bef(j,i)=0;
            end
            if spk_aveneuron_aft(j,i)<0
                spk_aveneuron_aft(j,i)=0;
            end
        end
        
        if plot_sup10a_flag
            spk_aveneuron_bef_amp=spk_aveneuron_bef*18;
            spk_aveneuron_aft_amp=spk_aveneuron_aft*18;
            
            subplot(1,4,j);
             plot([1000:5000],spk_aveneuron_bef_amp(j,1000:5000))
             hold on
             plot([1000:5000],spk_aveneuron_aft_amp(j,1000:5000))
             ylim([0 ,9])
             xlim([1000,5000])
             if j==1
                title(['Temporo-nasal']);
             elseif j==2
                 title(['Upward']);
             elseif j==3
                 title(['Naso-temporal']);
             elseif j==4
                 title(['Downward']);
             end
        end
    end
else
    for j=1:direction_group_num
    %     figure; hold on;
        temp=[];
        temp_aft=[];
        for i=1:size(prefdir_ind,1)
            if prefdir_ind(i,1)==j
                temp(end+1,:)=spk_TN_before_intp(i,:);

                temp_aft(end+1,:)=spk_TN_before_intp(i,:)*amp_change(1,j);
    %             plot([1:50], spk_TN_before(i,:))
            end
        end

        spk_aveneuron_bef(j,:)=mean(temp,1);
        spk_aveneuron_aft(j,:)=mean(temp_aft,1);
    %     spk_aveneuron_bef(j,:)=spk_aveneuron_bef_temp(j,:);
%         spk_aveneuron_bef(j,:)=spk_aveneuron_bef_temp(j,:)-mean(spk_aveneuron_bef_temp(j,5*intp_times:10*intp_times),2);
%         spk_aveneuron_aft(j,:)=spk_aveneuron_bef(j,:)*amp_change(1,j);
%         for i=1:size(spk_aveneuron_bef,2)
%             if spk_aveneuron_bef(j,i)<0
%                 spk_aveneuron_bef(j,i)=0;
%             end
%             if spk_aveneuron_aft(j,i)<0
%                 spk_aveneuron_aft(j,i)=0;
%             end
%         end
        figure;
         plot([1000:5000],spk_aveneuron_bef(j,1000:5000))
         hold on
         plot([1000:5000],spk_aveneuron_aft(j,1000:5000))
    end
    
end
a=9;
if normspk_flag

    %%%%%% norm spk%%%%%
 
    % rate=neuron pref TN: spk_peak_control/spk_peak_projecting
%     spk_aveneuron_bef=spk_aveneuron_bef(:,0.5*intp_times*framerate:end);
%     spk_aveneuron_bef_projecting=spk_aveneuron_bef_projecting(:,0.5*intp_times*framerate:end);
%     spk_aveneuron_aft_projecting=spk_aveneuron_aft_projecting(:,0.5*intp_times*framerate:end);
    spk_aveneuron_bef_control_max=max(spk_aveneuron_bef(1,0.5*intp_times*framerate:end));
    spk_aveneuron_bef_projecting_max=max(spk_aveneuron_bef_projecting(1,0.5*intp_times*framerate:end));
    rate=spk_aveneuron_bef_control_max/spk_aveneuron_bef_projecting_max;
    spk_aveneuron_bef_norm=spk_aveneuron_bef/rate;
    for i=1:size(spk_aveneuron_bef_norm,1)
        spk_aveneuron_aft_norm(i,:)=spk_aveneuron_bef_norm(i,:)*amp_change(1,i);
%         figure
%         plot([1000:5000], spk_aveneuron_bef_norm(i,1000:5000))
%         hold on
%         plot([1000:5000], spk_aveneuron_aft_norm(i,1000:5000))
%         ylim([0 ,9])
    end
%     for i=1:size(spk_aveneuron_bef_norm,1)
%         
%         figure
%         plot([500:5000], spk_aveneuron_bef_projecting(i,500:5000))
%         hold on
%         plot([500:5000], spk_aveneuron_aft_projecting(i,500:5000))
%     end


    
    switch F4_DSI_mode
        case 'TNratio'
            for i=1:size(spk_aveneuron_bef,1)
                if i==1
                    spk_aveneuron_bef(i,:)=spk_aveneuron_bef_norm(1,:);
                    spk_aveneuron_aft(i,:)=spk_aveneuron_aft_norm(1,:);
                else
                    spk_aveneuron_bef(i,:)=spk_aveneuron_bef_norm(1,:)*DSI_TNratio;
                    spk_aveneuron_aft(i,:)=spk_aveneuron_bef(i,:)*amp_change(1,i);
                end
            end
%             for j=1:4
%                 figure;
%                  plot([500:5000],spk_aveneuron_bef(j,500:5000))
%                  hold on
%                  plot([500:5000],spk_aveneuron_aft(j,500:5000))
%                  ylim([0 4.5])
%             end
        otherwise
            spk_aveneuron_bef=spk_aveneuron_bef_norm;
            spk_aveneuron_aft=spk_aveneuron_aft_norm;
    end
    %%%%%% sum w*u %%%%%%%
    weighted_spk_aveneuron_bef=zeros(1,size(spk_aveneuron_bef,2));
    weighted_spk_aveneuron_aft=zeros(1,size(spk_aveneuron_bef,2));
    for j=1:size(spk_aveneuron_bef,1)
        weighted_spk_aveneuron_bef=weighted_spk_aveneuron_bef+spk_aveneuron_bef(j,:)*weight_dir(j,1)*a;
        weighted_spk_aveneuron_aft=weighted_spk_aveneuron_aft+spk_aveneuron_aft(j,:)*weight_dir(j,1)*a;

    end

    %%%%%%%%% delta t %%%%%%%%%%
    delta_t=1/(framerate*intp_times);

    %%%%%% integration %%%%%%%%%
    Is_bef=zeros(size(weighted_spk_aveneuron_bef,2)+1,1);
    Is_aft=zeros(size(weighted_spk_aveneuron_aft,2)+1,1);

    for i=10*intp_times:size(weighted_spk_aveneuron_bef,2) % skip the first 2 frames
        delta_Is_bef=(-1*Is_bef(i,1)+weighted_spk_aveneuron_bef(1,i))*delta_t/tau_corticofugal;
        Is_bef(i+1,1)=Is_bef(i,1)+delta_Is_bef;
        delta_Is_aft=(-1*Is_aft(i,1)+weighted_spk_aveneuron_aft(1,i))*delta_t/tau_corticofugal;
        Is_aft(i+1,1)=Is_aft(i,1)+delta_Is_aft;

    end
    if ~plot_sup10a_flag
        figure
        plot([1*framerate*intp_times:size(Is_bef,1)],Is_bef(1*framerate*intp_times:end))
        hold on
        plot([1*framerate*intp_times:size(Is_bef,1)],Is_aft(1*framerate*intp_times:end))% ylim([0 10])
    end
else
    switch F4_DSI_mode
        case 'TNratio'
            
            for i=2:size(spk_aveneuron_bef,1)
                spk_aveneuron_bef(i,:)=spk_aveneuron_bef(1,:)*DSI_TNratio;
                spk_aveneuron_aft(i,:)=spk_aveneuron_bef(i,:)*amp_change(1,i);
            end
%             for j=1:4
%                 figure;
%                  plot([500:5000],spk_aveneuron_bef(j,500:5000))
%                  hold on
%                  plot([500:5000],spk_aveneuron_aft(j,500:5000))
%                  ylim([0 4.5])
%             end
    end
    %%%%%% sum w*u %%%%%%%
    weighted_spk_aveneuron_bef=zeros(1,size(spk_aveneuron_bef,2));
    weighted_spk_aveneuron_aft=zeros(1,size(spk_aveneuron_bef,2));
    for j=1:size(spk_aveneuron_bef,1)
        weighted_spk_aveneuron_bef=weighted_spk_aveneuron_bef+spk_aveneuron_bef(j,:)*weight_dir(j,1)*a;
        weighted_spk_aveneuron_aft=weighted_spk_aveneuron_aft+spk_aveneuron_aft(j,:)*weight_dir(j,1)*a;

    end

    %%%%%%%%% delta t %%%%%%%%%%
    delta_t=1/(framerate*intp_times);

    %%%%%% integration %%%%%%%%%
    Is_bef=zeros(size(weighted_spk_aveneuron_bef,2)+1,1);
    Is_aft=zeros(size(weighted_spk_aveneuron_aft,2)+1,1);

    for i=10*intp_times:size(weighted_spk_aveneuron_bef,2) % skip the first 2 frames
        delta_Is_bef=(-1*Is_bef(i,1)+weighted_spk_aveneuron_bef(1,i))*delta_t/tau_corticofugal;
        Is_bef(i+1,1)=Is_bef(i,1)+delta_Is_bef;
        delta_Is_aft=(-1*Is_aft(i,1)+weighted_spk_aveneuron_aft(1,i))*delta_t/tau_corticofugal;
        Is_aft(i+1,1)=Is_aft(i,1)+delta_Is_aft;

    end
    if ~plot_sup10a_flag
        figure
        plot([10*intp_times:4500],Is_bef(10*intp_times:4500))
        hold on
        plot([10*intp_times:4500],Is_aft(10*intp_times:4500))% ylim([0 10])
        xlim([1000,5000])
        xticks([1000,3000,5000])
        xticklabels({'0';'2';'4'})
    end
end

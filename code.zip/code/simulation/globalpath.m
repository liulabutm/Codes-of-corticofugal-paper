function globalpath
global folderpath

folderpath= which('globalpath');
pos_backslash=strfind(folderpath, '\');
folderpath=folderpath(1:pos_backslash(end)-1);
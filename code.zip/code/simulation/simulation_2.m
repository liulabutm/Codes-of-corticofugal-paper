
%% calculate Is of NOT-DTN neurons with different factors 
% Factor 1: firing rate mode a. use the firing rate of projecting group for both groups but weights are different (same_spk)
%                            b. use the firing rate of respective groups (real_spk)

% Factor 2: Direction preference distribution (weight)
            % a. systematical: All neurons prefer TN or 90% prefer TN or... or no neuron prefer TN, using NOT-DTN projecting neurons
            % b. midbrain: use the prefer direction bias of midbrain group
            % c. systematical_midbrain: All neurons prefer TN or 90% prefer TN or ... or no neuron prefer TN, using midbrain projecting neurons
% Factor 3: amplitude change
%           a. amplitude change in all four directions based on correlation fitting rate
%           b. amplitude change only in TN 
%           c. amplitude change are all same amount in all directions

% Factor 4: DSI (ignore)
%           a. combine all neurons from projecting group and control group
%           b. assign spk of other directions based on the TN spk (* x%, x with a range), only compare projecting with new projecting

% Factor 5: spike response to TN bias in different groups that prefer different directions
            % a. use NOT-DTN preference bias, and compare Is when using NOT-DTN or midbrain spike response
            % b. use midbrain preference bias, and compare Is when using NOT-DTN or midbrain spike response
% formula: delta(Is)=(-Is+w*u)*delta(t)/tau 
% where w=distribution of preferred direction (4 directions)
%       u= firing rate 
%       delta(t)=framerate
%       tau got from previous NOT-DTN ephys recording 

close all;
clear all;
global folderpath
globalpath;

F1_spk_mode='real_spk' ;   %'real_spk' or 'same_spk'   default: real_spk
F2_prefdir_weight_mode='real';   % 'real' or 'systematical' or 'midbrain' or 'systematical_midbrain'  default: real
F2_prefdir_weight_spk_norm=0;   % 0 means no normlization, 1 means norm spk rate peak value of TN dir to make it same with the spk rate average peak of non-TN dir
F2_prefdir_weight_TNamp='real';   % 'real' or 'ave_all'   default: real
F2_prefdir_weight_TNrange=[0:5:100];
F3_Amp_change_mode='respectively';   % 'original' 'proj_cont_diff' or 'onlyTN' or 'same_amount'or 'exchange' or 'midbrain_amp' or 'respectively' default: original/respectively
F3_amp_change_onlyTN_range=[1:0.5:3.5];
F3_amp_change_exchange_dir=3; % which direction index (2, 3, or 4) that 0 direction want to exchange with
normspk_mode='original'; % 'norm' or 'original'  default: original
F4_DSI_mode='original';  % 'original' or 'combine' or 'TNratio'   default: original
F4_DSI_TNratio=[0:0.1:1];  % when ratio=0.38, DSI=0.44
F5_resp_bias_mode='original'; %'original' or 'projecting_prefdir' or 'control_prefdir'  default: original
F4_DSI_normSpk_prefdir='norm'; %'norm' or 'not_norm' , default: norm. This is to normalize the spiking rate by the one from preferred direction, in this case the maximum spiking rate of all neurons are the same


intp_times=100;  
baseline_substract=1; % if substract baseline spk rate or not (triger time)
direction_group_num=4;
framerate=10;
tau_corticofugal=0.003936870335627; % in second
amp_change=[1.436475469027090;-0.035641361987585;0.579873811684419;-0.074132315940561];% get from plasticity data
amp_change=(amp_change+1)';
amp_change_control=[0.752568033508310;0.168015002081494;0.806360908201737;0.335449392356845];
amp_change_control=(amp_change_control+1)';
load([folderpath '\summary.mat'])


switch F2_prefdir_weight_mode
    case 'systematical'
        for i=1:size(F2_prefdir_weight_TNrange,2)
            for j=1:direction_group_num
                if j==1
                    weight_dir_3D(i,j)=F2_prefdir_weight_TNrange(1,i);  
                else
                    weight_dir_3D(i,j)=(100-F2_prefdir_weight_TNrange(1,i))/(direction_group_num-1);
                end
            end
        end
    case 'systematical_midbrain'
        for i=1:size(F2_prefdir_weight_TNrange,2)
            for j=1:direction_group_num
                if j==1
                    weight_dir_3D(i,j)=F2_prefdir_weight_TNrange(1,i);  
                else
                    weight_dir_3D(i,j)=(100-F2_prefdir_weight_TNrange(1,i))/(direction_group_num-1);
                end
            end
        end
end
switch F2_prefdir_weight_TNamp
    case 'ave_all'
        amp_change(:,:)=mean(amp_change);
end

switch F3_Amp_change_mode
    case 'proj_cont_diff'
        amp_change=[amp_change;amp_change_control];
    case 'same_amount'
%        amp_change_sameamount=amp_change(1);
%         amp_change_sameamount=amp_change(3);
         amp_change_sameamount=mean(amp_change);
        for i=1:size(amp_change,2)
            amp_change(1,i)=amp_change_sameamount;
        end
    case 'exchange'
       amp_change_new=amp_change;
       amp_change_new(1)=amp_change(F3_amp_change_exchange_dir);
       amp_change_new(F3_amp_change_exchange_dir)=amp_change(1);
       amp_change=amp_change_new;
   
end

switch F4_DSI_normSpk_prefdir
    case 'norm'
        for i=1:size(summary.spk_all_before_projecting,1)
            maxvalue=max(max(summary.spk_all_before_projecting(i,:,5:end))); % the first 5 frames were affected by the activity at the end of the previous trial
            spkNorm_prefdir_projecting(i,:,:)=summary.spk_all_before_projecting(i,:,:)/maxvalue;
        end
        for i=1:size(summary.spk_all_before_control,1)
            maxvalue=max(max(summary.spk_all_before_control(i,:,5:end)));
            spkNorm_prefdir_control(i,:,:)=summary.spk_all_before_control(i,:,:)/maxvalue;
        end
        summary.spk_TN_before_projecting=squeeze(spkNorm_prefdir_projecting(:,1,:));
        summary.spk_TN_before_control=squeeze(spkNorm_prefdir_control(:,1,:));
end

for i=1:direction_group_num
       weight_dir_projecting(i,1)=sum(summary.prefdir_ind_projecting==i)/size(summary.prefdir_ind_projecting,1); 
   weight_dir_control(i,1)=sum(summary.prefdir_ind_control==i)/size(summary.prefdir_ind_control,1); 
end
summary.weight_dir_projecting=weight_dir_projecting;
summary.weight_dir_control=weight_dir_control;

switch F4_DSI_mode
    case 'original'
        switch normspk_mode
            case 'original'
                switch F1_spk_mode
                    case 'same_spk'
                        switch F2_prefdir_weight_mode
                            case 'real'
                                switch F3_Amp_change_mode
                                    case 'original'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;
                                        spk_aveneuron_bef_projecting=[];
                                        normspk_flag=0;
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                        Is_bef_projecting=Is_bef;
                                        Is_aft_projecting=Is_aft;
                                        title('projecting')

                                        % control group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_control;   
                                        spk_aveneuron_bef_projecting=[];
                                        normspk_flag=0;
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                        Is_bef_control=Is_bef;
                                        Is_aft_control=Is_aft;
                                        title('control')
                                        'Running line: 125-147'
                                    case 'correlation'

                                    case 'onlyTN'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;
                                        amp_change_new=zeros(size(F3_amp_change_onlyTN_range,2),size(amp_change,2));
                                        spk_aveneuron_bef_projecting=[];
                                        normspk_flag=0;  
                                        for i=1:size(F3_amp_change_onlyTN_range,2)
                                            amp_change_new(i,1)=F3_amp_change_onlyTN_range(1,i);
                                            amp_change_new(i,2:end)=amp_change(1,2:end);
                                            DSI_TNratio=F4_DSI_TNratio(1,1);
                                            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change_new(i,:));
                                            Is_bef_projecting(i,:)=Is_bef;
                                            Is_aft_projecting(i,:)=Is_aft;                                    
                                            title(['projecting amp change onlyTN ' num2str(amp_change_new(i,1))])
                                        end

                                        % control group
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_control;   
                                        amp_change_new=zeros(size(F3_amp_change_onlyTN_range,2),size(amp_change,2));
                                        spk_aveneuron_bef_projecting=[];
                                        normspk_flag=0;   
                                        for i=1:size(F3_amp_change_onlyTN_range,2)
                                            amp_change_new(i,1)=F3_amp_change_onlyTN_range(1,i);
                                            amp_change_new(i,2:end)=amp_change(1,2:end);
                                            DSI_TNratio=F4_DSI_TNratio(1,1);
                                            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change_new(i,:));                                
                                            Is_bef_control(i,:)=Is_bef;
                                            Is_aft_control(i,:)=Is_aft; 
                                            title(['control amp change onlyTN ' num2str(amp_change_new(i,1))])
                                        end

                                    case 'same_amount'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting=Is_bef;
                                        Is_aft_projecting=Is_aft;                                 
                                        title('projecting')
                                        % control group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_control;
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_control=Is_bef;
                                        Is_aft_control=Is_aft; 
                                        title('control')
                                    
                                end
                            case 'systematical'
                                % projecting group
                                prefdir_ind=summary.prefdir_ind_projecting;        
                                spk_TN_before=summary.spk_TN_before_projecting;
                                spk_aveneuron_bef_projecting=[];
                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                normspk_flag=0;  
                                for i=1:size(weight_dir_3D,1)
                                    weight_dir=(weight_dir_3D(i,:))'/100;                              
                                    [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                    Is_bef_projecting(i,:)=Is_bef;
                                    Is_aft_projecting(i,:)=Is_aft; 
                                    title(['projecting weight ' num2str(weight_dir_3D(i,:))])
                                    savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'projecting weight ' num2str(weight_dir_3D(i,:)) ]);
                                    saveas(gcf,['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'projecting weight ' num2str(weight_dir_3D(i,:)) ], 'epsc');
                   

                                end    
                        end
                    case 'real_spk'
                        switch F2_prefdir_weight_mode
                            case 'real'
                                switch F3_Amp_change_mode
                                    case 'original'
                                         switch F5_resp_bias_mode
                                            case 'original'
                                                % projecting group
                                             
                                                prefdir_ind=summary.prefdir_ind_projecting;        
                                                spk_TN_before=summary.spk_TN_before_projecting;
                                                weight_dir=summary.weight_dir_projecting;   
                                                spk_aveneuron_bef_projecting=[];
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=0;   
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                                Is_bef_projecting=Is_bef;
                                                Is_aft_projecting=Is_aft; 
                                                title('projecting')
                                                % control group
                                                prefdir_ind=summary.prefdir_ind_control;        
                                                spk_TN_before=summary.spk_TN_before_control;
                                                weight_dir=summary.weight_dir_control;   
                                                spk_aveneuron_bef_projecting=[];
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=0;   
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                                Is_bef_control=Is_bef;
                                                Is_aft_control=Is_aft; 
                                                title('control')
                                            case 'projecting_prefdir'
                                                % projecting group
                                                 
                                                prefdir_ind=summary.prefdir_ind_projecting;        
                                                spk_TN_before=summary.spk_TN_before_projecting;
                                                weight_dir=summary.weight_dir_projecting;   
                                                spk_aveneuron_bef_projecting=[];
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=0;   
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                                Is_bef_projecting=Is_bef;
                                                Is_aft_projecting=Is_aft;
                                                spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                                title('projecting')
                                                % control group
                                                prefdir_ind=summary.prefdir_ind_control;        
                                                spk_TN_before=summary.spk_TN_before_control;
                                                weight_dir=summary.weight_dir_projecting;   
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=0;  
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                                Is_bef_control=Is_bef;
                                                Is_aft_control=Is_aft;  
                                                title('control')
                                            case 'control_prefdir'
                                                % projecting group
                                                prefdir_ind=summary.prefdir_ind_projecting;        
                                                spk_TN_before=summary.spk_TN_before_projecting;
                                                weight_dir=summary.weight_dir_control;   
                                                spk_aveneuron_bef_projecting=[];
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=0;   
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                                Is_bef_projecting=Is_bef;
                                                Is_aft_projecting=Is_aft;
                                                spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                                title('projecting')
                                                % control group
                                                prefdir_ind=summary.prefdir_ind_control;        
                                                spk_TN_before=summary.spk_TN_before_control;
                                                weight_dir=summary.weight_dir_control;   
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=0;  
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                                Is_bef_control=Is_bef;
                                                Is_aft_control=Is_aft;  
                                                title('control')
                                        end
                                            
                                           

                                    case 'onlyTN'
                                        % projecting group
                                        
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        amp_change_new=zeros(size(F3_amp_change_onlyTN_range,2),size(amp_change,2));
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        for i=1:size(F3_amp_change_onlyTN_range,2)
                                            amp_change_new(i,1)=F3_amp_change_onlyTN_range(1,i);
                                            amp_change_new(i,2:end)=amp_change(1,2:end);                                    
                                            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change_new(i,:));                                
                                            Is_bef_projecting(i,:)=Is_bef;
                                            Is_aft_projecting(i,:)=Is_aft; 
                                            title(['projecting amp change onlyTN ' num2str(amp_change_new(i,1))])
                                            savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\projecting onlyTN ' num2str(amp_change_new(i,1)) '.fig' ]);
                                            %saveas(gcf,['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'projecting weight ' num2str(amp_change_new(i,1)) ], 'epsc');
                                
                                        end
                                        % control group
                                        prefdir_ind=summary.prefdir_ind_control;        
                                        spk_TN_before=summary.spk_TN_before_control;
                                        weight_dir=summary.weight_dir_projecting;   
                                        amp_change_new=zeros(size(F3_amp_change_onlyTN_range,2),size(amp_change,2));
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0; 
                                        for i=1:size(F3_amp_change_onlyTN_range,2)
                                            amp_change_new(i,1)=F3_amp_change_onlyTN_range(1,i);
                                            amp_change_new(i,2:end)=amp_change(1,2:end);                                      
                                            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change_new(i,:));                                
                                            Is_bef_control(i,:)=Is_bef;
                                            Is_aft_control(i,:)=Is_aft; 
                                            title(['control amp change onlyTN ' num2str(amp_change_new(i,1))])
                                            savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\control onlyTN ' num2str(amp_change_new(i,1)) '.fig' ]);
                                        end

                                    case 'same_amount'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting=Is_bef;
                                        Is_aft_projecting=Is_aft; 
                                        title('projecting')
                                        % control group
                                        prefdir_ind=summary.prefdir_ind_control;        
                                        spk_TN_before=summary.spk_TN_before_control;
                                        weight_dir=summary.weight_dir_control;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_control=Is_bef;
                                        Is_aft_control=Is_aft; 
                                        title('control')
                                    case 'exchange'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting=Is_bef;
                                        Is_aft_projecting=Is_aft;
                                        spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                        title('projecting')
                                        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'exchange projecting '  ]);

                                        % control group
                                        prefdir_ind=summary.prefdir_ind_control;        
                                        spk_TN_before=summary.spk_TN_before_control;
                                        weight_dir=summary.weight_dir_control; 
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_control=Is_bef;
                                        Is_aft_control=Is_aft;
                                        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'exchange control '  ]);
                                        title('control')
                                    case 'midbrain_amp'
                                        % projecting group
                                       
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting=Is_bef;
                                        Is_aft_projecting=Is_aft; 
                                        title('projecting')
                                        % control group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change_control);                                
                                        Is_bef_control=Is_bef;
                                        Is_aft_control=Is_aft; 
                                        title('control')
                                    case 'respectively'
                                        % NOT-DTN projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting=Is_bef;
                                        Is_aft_projecting=Is_aft; 
                                        title('NOT-DTN projecting')
                                        % Midbrain projecting group
                                        prefdir_ind=summary.prefdir_ind_control;        
                                        spk_TN_before=summary.spk_TN_before_control;
                                        weight_dir=summary.weight_dir_control;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change_control);                                
                                        Is_bef_control=Is_bef;
                                        Is_aft_control=Is_aft; 
                                        title('Midbrain projecting')
                                        'Running line: 434-455'
                                end
                            case 'systematical'
                                
                                if F2_prefdir_weight_spk_norm==0
                                    % projecting group
                                    prefdir_ind=summary.prefdir_ind_projecting;        
                                    spk_TN_before=summary.spk_TN_before_projecting;
                                    spk_aveneuron_bef_projecting=[];
                                    DSI_TNratio=F4_DSI_TNratio(1,1);
                                    normspk_flag=0;  
                                    for i=1:size(weight_dir_3D,1)
                                        weight_dir=(weight_dir_3D(i,:))'/100;                                
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting(i,:)=Is_bef;
                                        Is_aft_projecting(i,:)=Is_aft; 
                                        title(['projecting weight ' num2str(weight_dir_3D(i,:))])
                                        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\projecting weight ' num2str(weight_dir_3D(i,:)) '.fig' ]);
%                                         saveas(gcf,['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'projecting weight ' num2str(weight_dir_3D(i,:)) ], 'epsc');
                                    end
                                else 
                                    % projecting group
                                    prefdir_ind=summary.prefdir_ind_projecting;        
                                    spk_TN_before=summary.spk_TN_before_projecting;
                                    weight_dir=summary.weight_dir_projecting;   
                                    spk_aveneuron_bef_projecting=[];
                                    DSI_TNratio=F4_DSI_TNratio(1,1);
                                    normspk_flag=0;   
                                    [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                    Is_bef_projecting_temp=Is_bef;
                                    Is_aft_projecting_temp=Is_aft;
                                    spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                    title('projecting')
                                    % control group
                                    spk_aveneuron_bef_projecting(1,:)=(max(spk_aveneuron_bef(2,500:end))+max(spk_aveneuron_bef(3,500:end))+max(spk_aveneuron_bef(4,500:end)))/3;
                                    prefdir_ind=summary.prefdir_ind_projecting;        
                                    spk_TN_before=summary.spk_TN_before_projecting;
                                    DSI_TNratio=F4_DSI_TNratio(1,1);
                                    normspk_flag=1;  
                                    for i=1:size(weight_dir_3D,1)
                                        weight_dir=(weight_dir_3D(i,:))'/100;                                
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting(i,:)=Is_bef;
                                        Is_aft_projecting(i,:)=Is_aft; 
                                        title(['projecting weight norm spk as same with ave_nonTN' num2str(weight_dir_3D(i,1))])
                                        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\projecting weight ' num2str(weight_dir_3D(i,:)) '.fig' ]);
%                                         saveas(gcf,['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'projecting weight ' num2str(weight_dir_3D(i,:)) ], 'epsc');
                                    end
                                end
                            case 'systematical_midbrain'
                                    % projecting group , for normalization
                                    prefdir_ind=summary.prefdir_ind_projecting;        
                                    spk_TN_before=summary.spk_TN_before_projecting;
                                    weight_dir=summary.weight_dir_projecting;   
                                    spk_aveneuron_bef_projecting=[];
                                    DSI_TNratio=F4_DSI_TNratio(1,1);
                                    normspk_flag=0;   
                                    [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                    Is_bef_projecting_temp=Is_bef;
                                    Is_aft_projecting_temp=Is_aft;
                                    spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                    title('projecting')
                                    % control group
                                    prefdir_ind=summary.prefdir_ind_control;        
                                    spk_TN_before=summary.spk_TN_before_control;
                                    DSI_TNratio=F4_DSI_TNratio(1,1);
                                    normspk_flag=1;  
                                    for i=1:size(weight_dir_3D,1)
                                        weight_dir=(weight_dir_3D(i,:))'/100;                                
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_control(i,:)=Is_bef;
                                        Is_aft_control(i,:)=Is_aft; 
                                        title(['control weight ' num2str(weight_dir_3D(i,:))])
                                        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\control weight ' num2str(weight_dir_3D(i,:)) '.fig' ]);
%                                         saveas(gcf,['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'projecting weight ' num2str(weight_dir_3D(i,:)) ], 'epsc');
                                    end
                            case 'midbrain'
                                % projecting group
                               
                                prefdir_ind=summary.prefdir_ind_projecting;        
                                spk_TN_before=summary.spk_TN_before_projecting;
                                weight_dir=summary.weight_dir_control;   
                                spk_aveneuron_bef_projecting=[];
                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                normspk_flag=0;   
                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                Is_bef_projecting=Is_bef;
                                Is_aft_projecting=Is_aft;
                                spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                title('control')
                                    
                        end
                end
            case 'norm'
                switch F1_spk_mode
                    case 'same_spk'
                        switch F2_prefdir_weight_mode
                            case 'real'
                                switch F3_Amp_change_mode
                                    case 'original'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting=Is_bef;
                                        Is_aft_projecting=Is_aft;
                                        spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                        title('projecting')
                                        % control group

                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_control;   
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=1;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_control=Is_bef;
                                        Is_aft_control=Is_aft;                        
                                        title('control')


                                    case 'onlyTN'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        amp_change_new=zeros(size(F3_amp_change_onlyTN_range,2),size(amp_change,2));
                                        normspk_flag=0; 
                                        for i=1:size(F3_amp_change_onlyTN_range,2)
                                            amp_change_new(i,1)=F3_amp_change_onlyTN_range(1,i);
                                            amp_change_new(i,2:end)=amp_change(1,2:end);
                                            spk_aveneuron_bef_projecting=[]; 
                                            
                                            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change_new(i,:));                                
                                            Is_bef_projecting(i,:)=Is_bef;
                                            Is_aft_projecting(i,:)=Is_aft;
                                            temp_spk_aveneuron_bef(i,:,:)=spk_aveneuron_bef;                           
                                            title(['projecting amp change onlyTN ' num2str(amp_change_new(i,1))])
                                            savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\projecting onlyTN ' num2str(amp_change_new(i,1)) '.fig' ]);

                                        end
                                        % control group
        %                                 spk_aveneuron_bef_projecting=temp_spk_aveneuron_bef;
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_control; 
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=1; 
                                        for i=1:size(F3_amp_change_onlyTN_range,2)
                                            amp_change_new(i,1)=F3_amp_change_onlyTN_range(1,i);
                                            amp_change_new(i,2:end)=amp_change(1,2:end);
                                            spk_aveneuron_bef_projecting=squeeze(temp_spk_aveneuron_bef(i,:,:));                                      
                                            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change_new(i,:));                              
                                            Is_bef_control(i,:)=Is_bef;
                                            Is_aft_control(i,:)=Is_aft;
                                            title(['control amp change onlyTN ' num2str(amp_change_new(i,1))])
                                            savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\control onlyTN ' num2str(amp_change_new(i,1)) '.fig' ]);

                                        end


                                    case 'same_amount'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting=Is_bef;
                                        Is_aft_projecting=Is_aft;
                                        spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                        title('projecting')
                                        % control group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_control; 
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=1;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_control=Is_bef;
                                        Is_aft_control=Is_aft;   
                                        title('control')
                                end
                            case 'systematical'
        %                         % projecting group
        %                         prefdir_ind=summary.prefdir_ind_projecting;        
        %                         spk_TN_before=summary.spk_TN_before_projecting;
        %                         for i=1:size(weight_dir_3D,1)
        %                             weight_dir=(weight_dir_3D(i,:))'/100;   
        %                             [Is_bef,Is_aft]=simulation_plst(prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
        %                             Is_inc_perc_projecting(i,1)=(max(Is_aft)-max(Is_bef))/max(Is_bef);
        %                             title(['projecting weight ' num2str(weight_dir_3D(i,:))])
        %                         end    
                        end
                    case 'real_spk'
                        switch F2_prefdir_weight_mode
                            case 'real'
                                switch F3_Amp_change_mode
                                    case 'original'
                                        switch F5_resp_bias_mode
                                            case 'original'
                                                % projecting group
                                                prefdir_ind=summary.prefdir_ind_projecting;        
                                                spk_TN_before=summary.spk_TN_before_projecting;
                                                weight_dir=summary.weight_dir_projecting;   
                                                spk_aveneuron_bef_projecting=[];
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=0;   
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                                Is_bef_projecting=Is_bef;
                                                Is_aft_projecting=Is_aft;
                                                spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                                title('projecting')
                                                % control group
                                                prefdir_ind=summary.prefdir_ind_control;        
                                                spk_TN_before=summary.spk_TN_before_control;
                                                weight_dir=summary.weight_dir_control;   
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=1;  
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                                Is_bef_control=Is_bef;
                                                Is_aft_control=Is_aft;  
                                                title('control')
                                            case 'projecting_prefdir'
                                                % projecting group
                                                prefdir_ind=summary.prefdir_ind_projecting;        
                                                spk_TN_before=summary.spk_TN_before_projecting;
                                                weight_dir=summary.weight_dir_projecting;   
                                                spk_aveneuron_bef_projecting=[];
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=0;   
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                                Is_bef_projecting=Is_bef;
                                                Is_aft_projecting=Is_aft;
                                                spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                                title('projecting')
                                                % control group
                                                prefdir_ind=summary.prefdir_ind_control;        
                                                spk_TN_before=summary.spk_TN_before_control;
                                                weight_dir=summary.weight_dir_projecting;   
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=1;  
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                                Is_bef_control=Is_bef;
                                                Is_aft_control=Is_aft;  
                                                title('control')
                                            case 'control_prefdir'
                                                % projecting group
                                                prefdir_ind=summary.prefdir_ind_projecting;        
                                                spk_TN_before=summary.spk_TN_before_projecting;
                                                weight_dir=summary.weight_dir_control;   
                                                spk_aveneuron_bef_projecting=[];
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=0;   
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                                Is_bef_projecting=Is_bef;
                                                Is_aft_projecting=Is_aft;
                                                spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                                title('projecting')
                                                % control group
                                                prefdir_ind=summary.prefdir_ind_control;        
                                                spk_TN_before=summary.spk_TN_before_control;
                                                weight_dir=summary.weight_dir_control;   
                                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                                normspk_flag=1;  
                                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                                Is_bef_control=Is_bef;
                                                Is_aft_control=Is_aft;  
                                                title('control')
                                        end
                                  case 'proj_cont_diff'
                                         
                                        for i=1:size(amp_change,1)
                                            % projecting group
                                            prefdir_ind=summary.prefdir_ind_projecting;        
                                            spk_TN_before=summary.spk_TN_before_projecting;
                                            weight_dir=summary.weight_dir_projecting;   
                                            spk_aveneuron_bef_projecting=[];
                                            DSI_TNratio=F4_DSI_TNratio(1,1);
                                            normspk_flag=0;
                                            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change(i,:));                                
                                            Is_bef_projecting(i,:)=Is_bef;
                                            Is_aft_projecting(i,:)=Is_aft; 
                                            title('projecting')
                                            savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\proj_cont_amp_diff_projecting ' num2str(amp_change(i,1)) '.fig' ]);
                                            
                                            spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                            % control group
                                            prefdir_ind=summary.prefdir_ind_control;        
                                            spk_TN_before=summary.spk_TN_before_control;
                                            weight_dir=summary.weight_dir_control;
                                            DSI_TNratio=F4_DSI_TNratio(1,1);
                                            normspk_flag=1; 
                                            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change(2,:));                                
                                            Is_bef_control(i,:)=Is_bef;
                                            Is_aft_control(i,:)=Is_aft; 
                                            title('control')
                                            savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\proj_cont_amp_diff_control ' num2str(amp_change(2,1)) '.fig' ]);
                                            
                                            
                                        end
                                        


                                    case 'onlyTN'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        amp_change_new=zeros(size(F3_amp_change_onlyTN_range,2),size(amp_change,2));
                                        for i=1:size(F3_amp_change_onlyTN_range,2)
                                            amp_change_new(i,1)=F3_amp_change_onlyTN_range(1,i);
                                            amp_change_new(i,2:end)=amp_change(1,2:end);
                                            spk_aveneuron_bef_projecting=[];
                                            
                                            normspk_flag=0;   
                                            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change_new(i,:));                               
                                            Is_bef_projecting(i,:)=Is_bef;
                                            Is_aft_projecting(i,:)=Is_aft;
                                            temp_spk_aveneuron_bef(i,:,:)=spk_aveneuron_bef;
                                            title(['projecting amp change onlyTN ' num2str(amp_change_new(i,1))])
                                            savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\projecting onlyTN ' num2str(amp_change_new(i,1)) '.fig' ]);

                                        end
                                        % control group
                                        prefdir_ind=summary.prefdir_ind_control;        
                                        spk_TN_before=summary.spk_TN_before_control;
                                        weight_dir=summary.weight_dir_control;   
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        amp_change_new=zeros(size(F3_amp_change_onlyTN_range,2),size(amp_change,2));
                                        for i=1:size(F3_amp_change_onlyTN_range,2)
                                            amp_change_new(i,1)=F3_amp_change_onlyTN_range(1,i);
                                            amp_change_new(i,2:end)=amp_change(1,2:end);
                                            
                                            normspk_flag=1;
                                            spk_aveneuron_bef_projecting=squeeze(temp_spk_aveneuron_bef(i,:,:));
                                            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change_new(i,:));                                
                                            Is_bef_control(i,:)=Is_bef;
                                            Is_aft_control(i,:)=Is_aft; 
                                            title(['control amp change onlyTN ' num2str(amp_change_new(i,1))])
                                            savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\control onlyTN ' num2str(amp_change_new(i,1)) '.fig' ]);

                                        end

                                    case 'same_amount'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting=Is_bef;
                                        Is_aft_projecting=Is_aft;
                                        spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                        title('projecting')
                                        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'same amount projecting '  ]);

                                        % control group
                                        prefdir_ind=summary.prefdir_ind_control;        
                                        spk_TN_before=summary.spk_TN_before_control;
                                        weight_dir=summary.weight_dir_control; 
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=1;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_control=Is_bef;
                                        Is_aft_control=Is_aft;
                                        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'same amount control '  ]);
                                        title('control')
                                    case 'exchange'
                                        % projecting group
                                        prefdir_ind=summary.prefdir_ind_projecting;        
                                        spk_TN_before=summary.spk_TN_before_projecting;
                                        weight_dir=summary.weight_dir_projecting;   
                                        spk_aveneuron_bef_projecting=[];
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=0;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_projecting=Is_bef;
                                        Is_aft_projecting=Is_aft;
                                        spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                        title('projecting')
                                        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'exchange projecting '  ]);

                                        % control group
                                        prefdir_ind=summary.prefdir_ind_control;        
                                        spk_TN_before=summary.spk_TN_before_control;
                                        weight_dir=summary.weight_dir_control; 
                                        DSI_TNratio=F4_DSI_TNratio(1,1);
                                        normspk_flag=1;   
                                        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
                                        Is_bef_control=Is_bef;
                                        Is_aft_control=Is_aft;
                                        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\' 'exchange control '  ]);
                                        title('control')
                                        
                                end
                            case 'systematical'
        %                         % projecting group
        %                         prefdir_ind=summary.prefdir_ind_projecting;        
        %                         spk_TN_before=summary.spk_TN_before_projecting;
        %                         for i=1:size(weight_dir_3D,1)
        %                             weight_dir=(weight_dir_3D(i,:))'/100;   
        %                             spk_aveneuron_bef_projecting=[];
        %                             normspk_flag=0;   
        %                             [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
        %                             Is_bef_projecting=Is_bef;
        %                             Is_aft_projecting=Is_aft;
        %                             spk_aveneuron_bef_projecting=spk_aveneuron_bef;
        %                             title(['projecting weight ' num2str(weight_dir_3D(i,:))])
        %                         end
                            case 'midbrain'
                                % projecting group
                               
                                prefdir_ind=summary.prefdir_ind_projecting;        
                                spk_TN_before=summary.spk_TN_before_projecting;
                                weight_dir=summary.weight_dir_control;   
                                spk_aveneuron_bef_projecting=[];
                                DSI_TNratio=F4_DSI_TNratio(1,1);
                                normspk_flag=0;   
                                [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);
                                Is_bef_projecting=Is_bef;
                                Is_aft_projecting=Is_aft;
                                spk_aveneuron_bef_projecting=spk_aveneuron_bef;
                                title('projecting')
                               
                        end
                end


        end
    case 'combine'
        load('E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\data\summary_all_projecting_control.mat')
        prefdir_ind=summary.prefdir_ind_projecting;        
        spk_TN_before=summary.spk_TN_before_projecting;
        weight_dir=summary.weight_dir_projecting;   
        spk_aveneuron_bef_projecting=[];
        DSI_TNratio=F4_DSI_TNratio(1,1);
        normspk_flag=0;   
        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
        Is_bef_projecting=Is_bef;
        Is_aft_projecting=Is_aft;
        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\projecting combine_rmDSI.fig' ]);
        title('projecting')
        % control group
        prefdir_ind=summary.prefdir_ind_projecting;        
        spk_TN_before=summary.spk_TN_before_projecting;
        weight_dir=summary.weight_dir_control;
        DSI_TNratio=F4_DSI_TNratio(1,1);
        normspk_flag=0;   
        [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
        Is_bef_control=Is_bef;
        Is_aft_control=Is_aft;
        title('control')
        savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\control combine_rmDSI.fig' ]);

    case 'TNratio'
        % projecting group
        prefdir_ind=summary.prefdir_ind_projecting;        
        spk_TN_before=summary.spk_TN_before_projecting;
        weight_dir=summary.weight_dir_projecting;   
        
        for i=1:size(F4_DSI_TNratio,2)
            DSI_TNratio=F4_DSI_TNratio(1,i);
            spk_aveneuron_bef_projecting=[];
            normspk_flag=0;   
            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                               
            Is_bef_projecting(i,:)=Is_bef;
            Is_aft_projecting(i,:)=Is_aft;
            temp_spk_aveneuron_bef(i,:,:)=spk_aveneuron_bef;
            title(['projecting DSI TNratio ' num2str(DSI_TNratio)])
            savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\projecting DSI TNratio ' num2str(DSI_TNratio) '.fig' ]);

        end
        % control group
        prefdir_ind=summary.prefdir_ind_control;        
        spk_TN_before=summary.spk_TN_before_control;
        weight_dir=summary.weight_dir_control;   
        for i=1:size(F4_DSI_TNratio,2)
            DSI_TNratio=F4_DSI_TNratio(1,i);
            normspk_flag=1;
            spk_aveneuron_bef_projecting=squeeze(temp_spk_aveneuron_bef(i,:,:));
            [Is_bef,Is_aft,spk_aveneuron_bef,spk_aveneuron_aft]=simulation_plst(F4_DSI_mode,DSI_TNratio,spk_aveneuron_bef_projecting,baseline_substract,intp_times,normspk_flag,prefdir_ind,weight_dir,spk_TN_before,direction_group_num,framerate,tau_corticofugal,amp_change);                                
            Is_bef_control(i,:)=Is_bef;
            Is_aft_control(i,:)=Is_aft; 
            title(['control DSI TNratio ' num2str(DSI_TNratio)])
            savefig(['E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation\control DSI TNratio ' num2str(DSI_TNratio) '.fig' ]);
        end
end



endframenum=4500;
switch F4_DSI_mode
    case 'TNratio'
        for i=1:size(Is_bef_projecting,1)
            Is_inc_perc_projecting(i,:)=(max(Is_aft_projecting(i,:))-max(Is_bef_projecting(i,:)))/max(Is_aft_projecting(i,:));
            Is_inc_projecting(i,:)=max(Is_aft_projecting(i,:))-max(Is_bef_projecting(i,:));

            Is_intgr_bef_projecting(i,:)=sum(Is_bef_projecting(i,1000:endframenum))*(1/framerate/intp_times);
            Is_intgr_aft_projecting(i,:)=sum(Is_aft_projecting(i,1000:endframenum))*(1/framerate/intp_times);
            Is_intgr_inc_projecting(i,:)=Is_intgr_aft_projecting(i,:)-Is_intgr_bef_projecting(i,:);
            Is_intgr_inc_perc_projecting(i,:)=(Is_intgr_aft_projecting(i,:)-Is_intgr_bef_projecting(i,:))/Is_intgr_bef_projecting(i,:);

            Is_inc_perc_control(i,:)=(max(Is_aft_control(i,:))-max(Is_bef_control(i,:)))/max(Is_aft_control(i,:));
            Is_inc_control(i,:)=max(Is_aft_control(i,:))-max(Is_bef_control(i,:));

            Is_intgr_bef_control(i,:)=sum(Is_bef_control(i,1000:endframenum))*(1/framerate/intp_times);
            Is_intgr_aft_control(i,:)=sum(Is_aft_control(i,1000:endframenum))*(1/framerate/intp_times);
            Is_intgr_inc_control(i,:)=Is_intgr_aft_control(i,:)-Is_intgr_bef_control(i,:);
            Is_intgr_inc_perc_control(i,:)=(Is_intgr_aft_control(i,:)-Is_intgr_bef_control(i,:))/Is_intgr_bef_control(i,:);
        end
%         figure
%         plot([1:size(Is_intgr_inc_projecting,1)],flip(Is_intgr_inc_projecting))
%         hold on
%         plot([1:size(Is_intgr_inc_control,1)],flip(Is_intgr_inc_control))
%         title('increase absolute')
%         ylim([0.1 0.4])

        figure
        plot([1:size(Is_intgr_inc_perc_projecting,1)],flip(Is_intgr_inc_perc_projecting))
        hold on 
        plot([1:size(Is_intgr_inc_perc_control,1)],flip(Is_intgr_inc_perc_control))
        title('increase percentage')
        ylim([0 0.3])
    otherwise
        switch F3_Amp_change_mode
            case 'onlyTN'
                for i=1:size(Is_bef_projecting,1)
                    Is_inc_perc_projecting(i,:)=(max(Is_aft_projecting(i,:))-max(Is_bef_projecting(i,:)))/max(Is_aft_projecting(i,:));
                    Is_inc_projecting(i,:)=max(Is_aft_projecting(i,:))-max(Is_bef_projecting(i,:));

                    Is_intgr_bef_projecting(i,:)=sum(Is_bef_projecting(i,1000:endframenum))*(1/framerate/intp_times);
                    Is_intgr_aft_projecting(i,:)=sum(Is_aft_projecting(i,1000:endframenum))*(1/framerate/intp_times);
                    Is_intgr_inc_projecting(i,:)=Is_intgr_aft_projecting(i,:)-Is_intgr_bef_projecting(i,:);
                    Is_intgr_inc_perc_projecting(i,:)=(Is_intgr_aft_projecting(i,:)-Is_intgr_bef_projecting(i,:))/Is_intgr_bef_projecting(i,:);

                    Is_inc_perc_control(i,:)=(max(Is_aft_control(i,:))-max(Is_bef_control(i,:)))/max(Is_aft_control(i,:));
                    Is_inc_control(i,:)=max(Is_aft_control(i,:))-max(Is_bef_control(i,:));

                    Is_intgr_bef_control(i,:)=sum(Is_bef_control(i,1000:endframenum))*(1/framerate/intp_times);
                    Is_intgr_aft_control(i,:)=sum(Is_aft_control(i,1000:endframenum))*(1/framerate/intp_times);
                    Is_intgr_inc_control(i,:)=Is_intgr_aft_control(i,:)-Is_intgr_bef_control(i,:);
                    Is_intgr_inc_perc_control(i,:)=(Is_intgr_aft_control(i,:)-Is_intgr_bef_control(i,:))/Is_intgr_bef_control(i,:);
                
                end
%                 figure
%                 plot([1:size(Is_intgr_inc_projecting,1)],Is_intgr_inc_projecting)
%                 hold on
%                 plot([1:size(Is_intgr_inc_control,1)],Is_intgr_inc_control)
%                 title('increase absolute')

                figure
                plot([1:size(Is_intgr_inc_perc_projecting,1)],Is_intgr_inc_perc_projecting)
                hold on 
                plot([1:size(Is_intgr_inc_perc_control,1)],Is_intgr_inc_perc_control)
                title('increase percentage')
                ylim([0,2.2])
            case 'proj_cont_diff'
                for i=1:size(Is_bef_projecting,1)
                    Is_inc_perc_projecting(i,:)=(max(Is_aft_projecting(i,:))-max(Is_bef_projecting(i,:)))/max(Is_aft_projecting(i,:));
                    Is_inc_projecting(i,:)=max(Is_aft_projecting(i,:))-max(Is_bef_projecting(i,:));

                    Is_intgr_bef_projecting(i,:)=sum(Is_bef_projecting(i,1000:endframenum))*(1/framerate/intp_times);
                    Is_intgr_aft_projecting(i,:)=sum(Is_aft_projecting(i,1000:endframenum))*(1/framerate/intp_times);
                    Is_intgr_inc_projecting(i,:)=Is_intgr_aft_projecting(i,:)-Is_intgr_bef_projecting(i,:);
                    Is_intgr_inc_perc_projecting(i,:)=(Is_intgr_aft_projecting(i,:)-Is_intgr_bef_projecting(i,:))/Is_intgr_bef_projecting(i,:);

                end
                figure
                plot([1,2], Is_intgr_inc_perc_projecting,'o')
                xlim([0 3])
                ylim([0.1 1.5])

            otherwise
                switch F2_prefdir_weight_mode
                        case 'systematical'
                            for i=1:size(Is_bef_projecting,1)
                                Is_inc_perc_projecting(i,:)=(max(Is_aft_projecting(i,:))-max(Is_bef_projecting(i,:)))/max(Is_aft_projecting(i,:));
                                Is_inc_projecting(i,:)=max(Is_aft_projecting(i,:))-max(Is_bef_projecting(i,:));

                                Is_intgr_bef_projecting(i,:)=sum(Is_bef_projecting(i,1000:endframenum))*(1/framerate/intp_times);
                                Is_intgr_aft_projecting(i,:)=sum(Is_aft_projecting(i,1000:endframenum))*(1/framerate/intp_times);
                                Is_intgr_inc_projecting(i,:)=Is_intgr_aft_projecting(i,:)-Is_intgr_bef_projecting(i,:);
                                Is_intgr_inc_perc_projecting(i,:)=(Is_intgr_aft_projecting(i,:)-Is_intgr_bef_projecting(i,:))/Is_intgr_bef_projecting(i,:);
                            end
%                             figure
%                             plot([1:size(Is_intgr_inc_projecting,1)],Is_intgr_inc_projecting)
%                             title('increase absolute')

                            figure
                            plot([1:size(Is_intgr_inc_perc_projecting,1)],Is_intgr_inc_perc_projecting)
                            title('increase percentage')
                            ylim([0.1 1.5])
                            
                        case 'midbrain'
                            Is_inc_perc_projecting=(max(Is_aft_projecting)-max(Is_bef_projecting))/max(Is_aft_projecting);
                            Is_inc_projecting=max(Is_aft_projecting)-max(Is_bef_projecting);

                            Is_intgr_bef_projecting=sum(Is_bef_projecting(1000:endframenum,1))*(1/framerate/intp_times);
                            Is_intgr_aft_projecting=sum(Is_aft_projecting(1000:endframenum,1))*(1/framerate/intp_times);
                            Is_intgr_inc_projecting=Is_intgr_aft_projecting-Is_intgr_bef_projecting;
                            Is_intgr_inc_perc_projecting=(Is_intgr_aft_projecting-Is_intgr_bef_projecting)/Is_intgr_bef_projecting;
                            figure
                            plot(1,Is_intgr_inc_perc_projecting ,'-o' );
                            xlim([0,2])
        %                     ylim([0.5 1.6])
                            ylim([0.1 1.5])
                            title('increase percentage')
                        case 'systematical_midbrain'
                            for i=1:size(Is_bef_control,1)
                                Is_inc_perc_control(i,:)=(max(Is_aft_control(i,:))-max(Is_bef_control(i,:)))/max(Is_aft_control(i,:));
                                Is_inc_control(i,:)=max(Is_aft_control(i,:))-max(Is_bef_control(i,:));

                                Is_intgr_bef_control(i,:)=sum(Is_bef_control(i,1000:endframenum))*(1/framerate/intp_times);
                                Is_intgr_aft_control(i,:)=sum(Is_aft_control(i,1000:endframenum))*(1/framerate/intp_times);
                                Is_intgr_inc_control(i,:)=Is_intgr_aft_control(i,:)-Is_intgr_bef_control(i,:);
                                Is_intgr_inc_perc_control(i,:)=(Is_intgr_aft_control(i,:)-Is_intgr_bef_control(i,:))/Is_intgr_bef_control(i,:);
                            end
%                             figure
%                             plot([1:size(Is_intgr_inc_control,1)],Is_intgr_inc_control)
%                             title('increase absolute')

                            figure
                            plot([1:size(Is_intgr_inc_perc_control,1)],Is_intgr_inc_perc_control)
                            title('increase percentage')
                            ylim([0.1 1.5])   

                otherwise

                    Is_inc_perc_projecting=(max(Is_aft_projecting)-max(Is_bef_projecting))/max(Is_aft_projecting);
                    Is_inc_projecting=max(Is_aft_projecting)-max(Is_bef_projecting);

                    Is_intgr_bef_projecting=sum(Is_bef_projecting(1000:endframenum,1))*(1/framerate/intp_times);
                    Is_intgr_aft_projecting=sum(Is_aft_projecting(1000:endframenum,1))*(1/framerate/intp_times);
                    Is_intgr_inc_projecting=Is_intgr_aft_projecting-Is_intgr_bef_projecting;
                    Is_intgr_inc_perc_projecting=(Is_intgr_aft_projecting-Is_intgr_bef_projecting)/Is_intgr_bef_projecting;

                    Is_inc_perc_control=(max(Is_aft_control)-max(Is_bef_control))/max(Is_aft_control);
                    Is_inc_control=max(Is_aft_control)-max(Is_bef_control);

                    Is_intgr_bef_control=sum(Is_bef_control(1000:endframenum,1))*(1/framerate/intp_times);
                    Is_intgr_aft_control=sum(Is_aft_control(1000:endframenum,1))*(1/framerate/intp_times);
                    Is_intgr_inc_control=Is_intgr_aft_control-Is_intgr_bef_control;
                    Is_intgr_inc_perc_control=(Is_intgr_aft_control-Is_intgr_bef_control)/Is_intgr_bef_control;
                
%                     figure
%                     plot([1 2],[Is_intgr_inc_projecting Is_intgr_inc_control],'-o' );
%                     xlim([0,3])
% %                     ylim([0.2,0.5])                    
%                     title('integration increase absolute value')
                     figure
                    plot([1 2],[Is_intgr_inc_perc_projecting Is_intgr_inc_perc_control],'-o'  );
                    xlim([0,3])
%                     ylim([0.5 1.6])
                    ylim([0 1.5])
%                     ylim([0 1.5])
                    title('increase percentage')
                    
                end
        end
end
    
        
        

   
% OKR plasticity

%% test precedure
global OKR_tuning_path OKR_root_path OKR_eye_path
globalpara_OKR;

%run the folders automatically
%load the list of running sequence and the properties of each folder
saveflag=1;   %1=save cal and sortdata

RunFolderSeq=table2cell(readtable([OKR_root_path '\analysis\recording_paras_plasticity.xlsx']));
runind=find(cell2mat(RunFolderSeq(:,8)));
% figure;
% for i=1:size(runind,1)
%     mouse_list(i,:)=RunFolderSeq{runind(i,1),1};
% end
for f=1:size(runind,1)
    
%     hold on
    mouse_name=RunFolderSeq{runind(f),1}; 
    sitename_bef1d=RunFolderSeq{runind(f),2}; 
    sitename_bef1h=RunFolderSeq{runind(f),3}; 
    sitename_befall=RunFolderSeq{runind(f),4}; 
    sitename_aft=RunFolderSeq{runind(f),5}; 
    sitename_2nd_bef1h=RunFolderSeq{runind(f),6}; 
    sitename_2nd_aft=RunFolderSeq{runind(f),7}; 
    bef1d=load([OKR_eye_path sitename_bef1d '.mat' ]);
    bef1h=load([OKR_eye_path sitename_bef1h '.mat' ]);
    befall=load([OKR_eye_path sitename_befall '.mat' ]);
    aft=load([OKR_eye_path sitename_aft '.mat' ]);
    bef1h_2nd=load([OKR_eye_path sitename_2nd_bef1h '.mat' ]);   
    aft_2nd=load([OKR_eye_path sitename_2nd_aft '.mat' ]);
    tuning_bef1d(f,1)=bef1d.datapara.tuningvalue(1,1);
    tuning_bef1h(f,1)=bef1h.datapara.tuningvalue(1,1);
    tuning_befall(f,1)=befall.datapara.tuningvalue(1,1);
    tuning_aft(f,1)=aft.datapara.tuningvalue(1,1);
    tuning_bef1d_2nd(f,1)=bef1h_2nd.datapara.tuningvalue(1,1);
    tuning_aft_2nd(f,1)=aft_2nd.datapara.tuningvalue(1,1);

    
    error_bef1d(f,1)=bef1d.datapara.errorvalue(1,1);
    error_bef1h(f,1)=bef1h.datapara.errorvalue(1,1);
    error_befall(f,1)=befall.datapara.errorvalue(1,1);
    error_aft(f,1)=aft.datapara.errorvalue(1,1);
    error_bef1d_2nd(f,1)=bef1h_2nd.datapara.errorvalue(1,1);
    error_aft_2nd(f,1)=aft_2nd.datapara.errorvalue(1,1);
    figure;
    errorbar([1 2 3 4 5 6], [tuning_bef1d(f,1) tuning_bef1h(f,1) tuning_befall(f,1) tuning_aft(f,1) tuning_bef1d_2nd(f,1) tuning_aft_2nd(f,1)],[error_bef1d(f,1) error_bef1h(f,1) error_befall(f,1) error_aft(f,1) error_bef1d_2nd(f,1) error_aft_2nd(f,1)],'-o','Color','k');
    xticks([1 2 3 4 5 6])
    xticklabels({'before 1day','before 1h','before all','aft','2nd before 1h','2nd aft'})
 
    title(mouse_name)
   % hold on
    
%     clearvars -except RunFolderSeq runind saveflag OKR_tuning_path OKR_root_path OKR_eye_path mouse_list
%     close all
end

OKR_potent=(tuning_aft-tuning_bef1d)./tuning_bef1d;
figure
for i=1:size(tuning_bef1d,1)
   plot(1,OKR_potent(i,1),'-o')
   hold on    
end
errorbar(1.2,mean(OKR_potent),std(OKR_potent)/sqrt(size(OKR_potent,1)))
xlim([0.5 1.5])
[p,h]=signrank(OKR_potent);
legend({'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'})
%%
figure
tuning_bef1d_mean=mean(tuning_bef1d,1);
tuning_bef1h_mean=mean(tuning_bef1h,1);
tuning_befall_mean=mean(tuning_befall,1);
tuning_aft_mean=mean(tuning_aft,1);
tuning_aft_2nd_mean=mean(tuning_aft_2nd,1);
tuning_bef1d_2nd_mean=mean(tuning_bef1d_2nd,1);

tuning_bef1d_SEM = std(tuning_bef1d,1)./sqrt(size(tuning_bef1d,1));
tuning_bef1h_SEM = std(tuning_bef1h,1)./sqrt(size(tuning_bef1h,1));
tuning_befall_SEM = std(tuning_befall,1)./sqrt(size(tuning_befall,1));
tuning_aft_SEM = std(tuning_aft,1)./sqrt(size(tuning_aft,1));
tuning_aft_2nd_SEM = std(tuning_aft_2nd,1)./sqrt(size(tuning_aft_2nd,1));
tuning_bef1h_2nd_SEM = std(tuning_bef1d_2nd,1)./sqrt(size(tuning_bef1d_2nd,1));
errorbar([1 2 3 4 5 6], [tuning_bef1d_mean tuning_bef1h_mean tuning_befall_mean tuning_aft_mean tuning_bef1d_2nd_mean tuning_aft_2nd_mean],[tuning_bef1d_SEM tuning_bef1h_SEM tuning_befall_SEM tuning_aft_SEM tuning_bef1h_2nd_SEM tuning_aft_2nd_SEM],'Color','b','LineWidth',2);
xticks([1 2 3 4 5 6])
xticklabels({'before 1day','before 1h','before all','aft','2nd before 1h','2nd aft'})
 
% legend([mouse_list(1,:), mouse_list(2,:),mouse_list(3,:),mouse_list(4,:),mouse_list(5,:),mouse_list(6,:),mouse_list(7,:),mouse_list(8,:),mouse_list(9,:),mouse_list(10,:),mouse_list(11,:),])
% legend off

%% with LED
global OKR_tuning_path OKR_root_path OKR_eye_path
globalpara_OKR;

%run the folders automatically
%load the list of running sequence and the properties of each folder
saveflag=1;   %1=save cal and sortdata

RunFolderSeq=table2cell(readtable([OKR_root_path '\analysis\recording_paras_plasticity.xlsx'],'Sheet','combine'));
runind=find(cell2mat(RunFolderSeq(:,6)));
% figure;
for i=1:size(runind,1)
    mouse_list(i,:)=RunFolderSeq{runind(i,1),1};
end
for f=1:size(runind,1)
    figure;
%     hold on
    mouse_name=RunFolderSeq{runind(f),1}; 
    sitename_bef1d=RunFolderSeq{runind(f),2}; 
    sitename_bef1h=RunFolderSeq{runind(f),3}; 
    sitename_befall=RunFolderSeq{runind(f),4}; 
    sitename_aft=RunFolderSeq{runind(f),5}; 
%     sitename_2nd_bef1h=RunFolderSeq{runind(f),6}; 
%     sitename_2nd_aft=RunFolderSeq{runind(f),7}; 
    bef1d=load([OKR_eye_path sitename_bef1d '.mat' ]);
    bef1h=load([OKR_eye_path sitename_bef1h '.mat' ]);
    befall=load([OKR_eye_path sitename_befall '.mat' ]);
    aft=load([OKR_eye_path sitename_aft '.mat' ]);
%     bef1h_2nd=load([OKR_eye_path sitename_2nd_bef1h '.mat' ]);   
%     aft_2nd=load([OKR_eye_path sitename_2nd_aft '.mat' ]);
    tuning_bef1d(f,:)=bef1d.datapara.tuningvalue(1,:); %(2nd dimension: 1=withoutLED, 2=withLED)
    tuning_bef1h(f,:)=bef1h.datapara.tuningvalue(1,:);
    tuning_befall(f,:)=befall.datapara.tuningvalue(1,:);
    tuning_aft(f,:)=aft.datapara.tuningvalue(1,:);
%     tuning_bef1d_2nd(f,1)=bef1h_2nd.datapara.tuningvalue(1,1);
%     tuning_aft_2nd(f,1)=aft_2nd.datapara.tuningvalue(1,1);
    
    
    error_bef1d(f,:)=bef1d.datapara.errorvalue(1,:);
    error_bef1h(f,:)=bef1h.datapara.errorvalue(1,:);
    error_befall(f,:)=befall.datapara.errorvalue(1,:);
    error_aft(f,:)=aft.datapara.errorvalue(1,:);
%     error_bef1d_2nd(f,1)=bef1h_2nd.datapara.errorvalue(1,1);
%     error_aft_2nd(f,1)=aft_2nd.datapara.errorvalue(1,1);
    
    errorbar([1 2 3 4], [tuning_bef1d(f,1) tuning_bef1h(f,1) tuning_befall(f,1) tuning_aft(f,1) ],[error_bef1d(f,2) error_bef1h(f,2) error_befall(f,2) error_aft(f,2)],'-o','Color','k');
    xticks([1 2 3 4 5 6])
    xticklabels({'before 1day','before 1h','before all','aft'})
    hold on
    errorbar([1 2 3 4], [tuning_bef1d(f,2) tuning_bef1h(f,2) tuning_befall(f,2) tuning_aft(f,2) ],[error_bef1d(f,2) error_bef1h(f,2) error_befall(f,2) error_aft(f,2)],'-o','Color','b');

    title(mouse_name)
    hold off
    
    % cortical contribution
    LED_modulation_ind_bef1d(f,1)=(tuning_bef1d(f,1)-tuning_bef1d(f,2))./tuning_bef1d(f,1); 
    LED_modulation_ind_bef1h(f,1)=(tuning_bef1h(f,1)-tuning_bef1h(f,2))./tuning_bef1h(f,1); 
    LED_modulation_ind_befall(f,1)=(tuning_befall(f,1)-tuning_befall(f,2))./tuning_befall(f,1); 
    LED_modulation_ind_aft(f,1)=(tuning_aft(f,1)-tuning_aft(f,2))./tuning_aft(f,1); 
    figure
    plot([1 2 3 4], [LED_modulation_ind_bef1d(f,1) LED_modulation_ind_bef1h(f,1) LED_modulation_ind_befall(f,1) LED_modulation_ind_aft(f,1)])
    title([mouse_name 'cortical contribution'])
    xticks([1 2 3 4 5 6])
    xticklabels({'before 1day','before 1h','before all','aft'})
end

%% averaged figure
figure
tuning_bef1d_mean=mean(tuning_bef1d,1);
tuning_bef1h_mean=mean(tuning_bef1h,1);
tuning_befall_mean=mean(tuning_befall,1);
tuning_aft_mean=mean(tuning_aft,1);
% tuning_aft_2nd_mean=mean(tuning_aft_2nd,1);
% tuning_bef1d_2nd_mean=mean(tuning_bef1d_2nd,1);

tuning_bef1d_withoutLED_SEM = std(tuning_bef1d(:,1),1)./sqrt(size(tuning_bef1d,1));
tuning_bef1h_withoutLED_SEM = std(tuning_bef1h(:,1),1)./sqrt(size(tuning_bef1h,1));
tuning_befall_withoutLED_SEM = std(tuning_befall(:,1),1)./sqrt(size(tuning_befall,1));
tuning_aft_withoutLED_SEM = std(tuning_aft(:,1),1)./sqrt(size(tuning_aft,1));
tuning_bef1d_withLED_SEM = std(tuning_bef1d(:,2),1)./sqrt(size(tuning_bef1d,1));
tuning_bef1h_withLED_SEM = std(tuning_bef1h(:,2),1)./sqrt(size(tuning_bef1h,1));
tuning_befall_withLED_SEM = std(tuning_befall(:,2),1)./sqrt(size(tuning_befall,1));
tuning_aft_withLED_SEM = std(tuning_aft(:,2),1)./sqrt(size(tuning_aft,1));

% tuning_aft_2nd_SEM = std(tuning_aft_2nd,1)./sqrt(size(tuning_aft_2nd,1));
% tuning_bef1h_2nd_SEM = std(tuning_bef1d_2nd,1)./sqrt(size(tuning_bef1d_2nd,1));
errorbar([1 2 3 4], [tuning_bef1d_mean(:,1) tuning_bef1h_mean(:,1) tuning_befall_mean(:,1) tuning_aft_mean(:,1)],[tuning_bef1d_withoutLED_SEM tuning_bef1h_withoutLED_SEM tuning_befall_withoutLED_SEM tuning_aft_withoutLED_SEM ],'Color','k','LineWidth',2);
xticks([1 2 3 4 5 6])
xticklabels({'before 1day','before 1h','before all','aft','2nd before 1h','2nd aft'})
hold on
errorbar([1 2 3 4], [tuning_bef1d_mean(:,2) tuning_bef1h_mean(:,2) tuning_befall_mean(:,2) tuning_aft_mean(:,2)],[tuning_bef1d_withLED_SEM tuning_bef1h_withLED_SEM tuning_befall_withLED_SEM tuning_aft_withLED_SEM ],'Color','b','LineWidth',2);
hold off
title('averaged tuning')
% cortical contribution
figure
LED_modulation_ind_bef1d_mean=mean(LED_modulation_ind_bef1d,1);
LED_modulation_ind_bef1h_mean=mean(LED_modulation_ind_bef1h,1);
LED_modulation_ind_befall_mean=mean(LED_modulation_ind_befall,1);
LED_modulation_ind_aft_mean=mean(LED_modulation_ind_aft,1);

LED_modulation_ind_bef1d_SEM=std(LED_modulation_ind_bef1d(:,1),1)./sqrt(size(LED_modulation_ind_bef1d,1));
LED_modulation_ind_bef1h_SEM=std(LED_modulation_ind_bef1h(:,1),1)./sqrt(size(LED_modulation_ind_bef1h,1));
LED_modulation_ind_befall_SEM=std(LED_modulation_ind_befall(:,1),1)./sqrt(size(LED_modulation_ind_befall,1));
LED_modulation_ind_aft_SEM=std(LED_modulation_ind_aft(:,1),1)./sqrt(size(LED_modulation_ind_aft,1));

errorbar([1 2 3 4], [LED_modulation_ind_bef1d_mean LED_modulation_ind_bef1h_mean LED_modulation_ind_befall_mean LED_modulation_ind_aft_mean],[LED_modulation_ind_bef1d_SEM LED_modulation_ind_bef1h_SEM LED_modulation_ind_befall_SEM LED_modulation_ind_aft_SEM])
title('averaged cortical contribution')
xticks([1 2 3 4 5 6])
xticklabels({'before 1day','before 1h','before all','aft'})
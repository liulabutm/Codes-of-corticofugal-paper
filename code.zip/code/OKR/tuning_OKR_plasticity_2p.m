% OKR plasticity

%% 2p
global OKR_tuning_path OKR_root_path OKR_eye_path calpath
globalpara_OKR;
globalpara;

%run the folders automatically
%load the list of running sequence and the properties of each folder
saveflag=1;   %1=save cal and sortdata

RunFolderSeq=table2cell(readtable([OKR_root_path '\analysis\recording_paras_plasticity.xlsx'],'Sheet','2p'));
runind=find(cell2mat(RunFolderSeq(:,2)));
% figure;
% for i=1:size(runind,1)
%     mouse_list(i,:)=RunFolderSeq{runind(i,1),1};
% end
for f=1:size(runind,1)
%     figure;
%     hold on
    mouse_name=RunFolderSeq{runind(f),1}; 
    sitename_bef1d=RunFolderSeq{runind(f),3}; 
    sitename_aft=RunFolderSeq{runind(f),4};     
    bef1d=load([OKR_eye_path sitename_bef1d '.mat' ]);   
    aft=load([OKR_eye_path sitename_aft '.mat' ]);    
    tuning_bef1d(f,1)=bef1d.datapara.tuningvalue(1,1);   
    tuning_aft(f,1)=aft.datapara.tuningvalue(1,1);    
    sitename_2p=RunFolderSeq{runind(f),5}; 
    error_bef1d(f,1)=bef1d.datapara.errorvalue(1,1);   
    error_aft(f,1)=aft.datapara.errorvalue(1,1);
    load([calpath sitename_2p '\peak\sortdata.mat']);
    OKRgain_bef1d(f,1)=tuning_bef1d(f,1)/5;
    OKRgain_aft(f,1)=tuning_aft(f,1)/5;
    OKR_plst=(tuning_aft(f,1)-tuning_bef1d(f,1))/tuning_bef1d(f,1);
    
    sortdata.tuning_bef1d=tuning_bef1d;
    sortdata.tuning_aft=tuning_aft;
    sortdata.OKRgain_bef1d=OKRgain_bef1d;
    sortdata.OKRgain_aft=OKRgain_aft;
    sortdata.OKR_plst=OKR_plst;
%     save([calpath sitename_2p '\peak\sortdata.mat'],'sortdata');
%     errorbar([1 2 ], [tuning_bef1d(f,1)  tuning_aft(f,1) ],[error_bef1d(f,1)  error_aft(f,1) ],'-o','Color','k');
%     xlim([0,3])
%     xticks([0 1 2 3])
%     xticklabels({' ','before 1day','aft',' '})
%     ylim([0 5])
%     title(mouse_name)
   % hold on
%     savefig([OKR_tuning_path '\2p\' mouse_name]);
%     saveas(gcf,[OKR_tuning_path '\2p\'  mouse_name], 'tiff');
 
%     clearvars -except RunFolderSeq runind saveflag OKR_tuning_path OKR_root_path OKR_eye_path mouse_list
%     close all
end

%% plot bef and aft OKR
figure
for i=1:size(tuning_bef1d,1)
    plot([1 2],[tuning_bef1d(i,1) tuning_aft(i,1)],'-o','Color','k')
    hold on
end
legend({'1','2','3','4','5','6','7','8','9','10','11','12'})
for i=1:size(tuning_bef1d,1)
    perc_inc(i,1)=(tuning_aft(i,1)-tuning_bef1d(i,1))/tuning_bef1d(i,1);
end
mean_perc=mean(perc_inc);
SEM_perc=mean(perc_inc)/sqrt(size(perc_inc,1));
tuning_bef1d_mean=mean(tuning_bef1d,1);
% tuning_bef1h_mean=mean(tuning_bef1h,1);
% tuning_befall_mean=mean(tuning_befall,1);
tuning_aft_mean=mean(tuning_aft,1);
% tuning_aft_2nd_mean=mean(tuning_aft_2nd,1);
% tuning_bef1d_2nd_mean=mean(tuning_bef1d_2nd,1);

tuning_bef1d_SEM = std(tuning_bef1d,1)./sqrt(size(tuning_bef1d,1));
% tuning_bef1h_SEM = std(tuning_bef1h,1)./sqrt(size(tuning_bef1h,1));
% tuning_befall_SEM = std(tuning_befall,1)./sqrt(size(tuning_befall,1));
tuning_aft_SEM = std(tuning_aft,1)./sqrt(size(tuning_aft,1));
% tuning_aft_2nd_SEM = std(tuning_aft_2nd,1)./sqrt(size(tuning_aft_2nd,1));
% tuning_bef1h_2nd_SEM = std(tuning_bef1d_2nd,1)./sqrt(size(tuning_bef1d_2nd,1));
errorbar([0.5 2.5], [tuning_bef1d_mean tuning_aft_mean ],[tuning_bef1d_SEM tuning_aft_SEM],'Color','b','LineWidth',2);
xticks([0 1 2 3])
xticklabels({' ','before 1day','aft',' '})
 xlim([0 3])
[h_beh,p_beh]=ttest(tuning_bef1d,tuning_aft,'Tail','left');
p=signrank(tuning_bef1d,tuning_aft);

plst_index=(tuning_aft-tuning_bef1d)./tuning_bef1d;
figure
for i=1:size(plst_index,1)
    plot(1, plst_index(i,1),'-o')
    hold on
end
errorbar(1.5,mean(plst_index,1),std(plst_index,1)/sqrt(size(plst_index,1)))
xlim([0.8,2])


%% plot bef and aft OKR, norm bef as 1
tuning_aft_norm=[];
figure
for i=1:size(tuning_bef1d,1)
    tuning_aft_norm(i,1)=tuning_aft(i,1)/tuning_bef1d(i,1);
    plot([1 2],[1 tuning_aft_norm(i,1)],'-o','Color','k')
    hold on
end


tuning_bef1d_mean=1;
% tuning_bef1h_mean=mean(tuning_bef1h,1);
% tuning_befall_mean=mean(tuning_befall,1);
tuning_aft_mean=mean(tuning_aft_norm,1);
% tuning_aft_2nd_mean=mean(tuning_aft_2nd,1);
% tuning_bef1d_2nd_mean=mean(tuning_bef1d_2nd,1);

tuning_bef1d_SEM = 0;
% tuning_bef1h_SEM = std(tuning_bef1h,1)./sqrt(size(tuning_bef1h,1));
% tuning_befall_SEM = std(tuning_befall,1)./sqrt(size(tuning_befall,1));
tuning_aft_SEM = std(tuning_aft_norm,1)./sqrt(size(tuning_aft_norm,1));
% tuning_aft_2nd_SEM = std(tuning_aft_2nd,1)./sqrt(size(tuning_aft_2nd,1));
% tuning_bef1h_2nd_SEM = std(tuning_bef1d_2nd,1)./sqrt(size(tuning_bef1d_2nd,1));
errorbar([0.5 2.5], [tuning_bef1d_mean tuning_aft_mean ],[tuning_bef1d_SEM tuning_aft_SEM],'Color','b','LineWidth',2);
xticks([0 1 2 3])
xticklabels({' ','before 1day','aft',' '})
 xlim([0 3])
[h_beh,p_beh]=ttest(tuning_bef1d,tuning_aft,'Tail','left');


%% with LED
global OKR_tuning_path OKR_root_path OKR_eye_path
globalpara_OKR;

%run the folders automatically
%load the list of running sequence and the properties of each folder
saveflag=1;   %1=save cal and sortdata

RunFolderSeq=table2cell(readtable([OKR_root_path '\analysis\recording_paras_plasticity.xlsx'],'Sheet','combine'));
runind=find(cell2mat(RunFolderSeq(:,6)));
% figure;
for i=1:size(runind,1)
    mouse_list(i,:)=RunFolderSeq{runind(i,1),1};
end
for f=1:size(runind,1)
    figure;
%     hold on
    mouse_name=RunFolderSeq{runind(f),1}; 
    sitename_bef1d=RunFolderSeq{runind(f),2}; 
    sitename_bef1h=RunFolderSeq{runind(f),3}; 
    sitename_befall=RunFolderSeq{runind(f),4}; 
    sitename_aft=RunFolderSeq{runind(f),5}; 
%     sitename_2nd_bef1h=RunFolderSeq{runind(f),6}; 
%     sitename_2nd_aft=RunFolderSeq{runind(f),7}; 
    bef1d=load([OKR_eye_path sitename_bef1d '.mat' ]);
    bef1h=load([OKR_eye_path sitename_bef1h '.mat' ]);
    befall=load([OKR_eye_path sitename_befall '.mat' ]);
    aft=load([OKR_eye_path sitename_aft '.mat' ]);
%     bef1h_2nd=load([OKR_eye_path sitename_2nd_bef1h '.mat' ]);   
%     aft_2nd=load([OKR_eye_path sitename_2nd_aft '.mat' ]);
    tuning_bef1d(f,:)=bef1d.datapara.tuningvalue(1,:); %(2nd dimension: 1=withoutLED, 2=withLED)
    tuning_bef1h(f,:)=bef1h.datapara.tuningvalue(1,:);
    tuning_befall(f,:)=befall.datapara.tuningvalue(1,:);
    tuning_aft(f,:)=aft.datapara.tuningvalue(1,:);
%     tuning_bef1d_2nd(f,1)=bef1h_2nd.datapara.tuningvalue(1,1);
%     tuning_aft_2nd(f,1)=aft_2nd.datapara.tuningvalue(1,1);
    
    
    error_bef1d(f,:)=bef1d.datapara.errorvalue(1,:);
    error_bef1h(f,:)=bef1h.datapara.errorvalue(1,:);
    error_befall(f,:)=befall.datapara.errorvalue(1,:);
    error_aft(f,:)=aft.datapara.errorvalue(1,:);
%     error_bef1d_2nd(f,1)=bef1h_2nd.datapara.errorvalue(1,1);
%     error_aft_2nd(f,1)=aft_2nd.datapara.errorvalue(1,1);
    
    errorbar([1 2 3 4], [tuning_bef1d(f,1) tuning_bef1h(f,1) tuning_befall(f,1) tuning_aft(f,1) ],[error_bef1d(f,2) error_bef1h(f,2) error_befall(f,2) error_aft(f,2)],'-o','Color','k');
    xticks([1 2 3 4 5 6])
    xticklabels({'before 1day','before 1h','before all','aft'})
    hold on
    errorbar([1 2 3 4], [tuning_bef1d(f,2) tuning_bef1h(f,2) tuning_befall(f,2) tuning_aft(f,2) ],[error_bef1d(f,2) error_bef1h(f,2) error_befall(f,2) error_aft(f,2)],'-o','Color','b');

    title(mouse_name)
    hold off
    
    % cortical contribution
    LED_modulation_ind_bef1d(f,1)=(tuning_bef1d(f,1)-tuning_bef1d(f,2))./tuning_bef1d(f,1); 
    LED_modulation_ind_bef1h(f,1)=(tuning_bef1h(f,1)-tuning_bef1h(f,2))./tuning_bef1h(f,1); 
    LED_modulation_ind_befall(f,1)=(tuning_befall(f,1)-tuning_befall(f,2))./tuning_befall(f,1); 
    LED_modulation_ind_aft(f,1)=(tuning_aft(f,1)-tuning_aft(f,2))./tuning_aft(f,1); 
    figure
    plot([1 2 3 4], [LED_modulation_ind_bef1d(f,1) LED_modulation_ind_bef1h(f,1) LED_modulation_ind_befall(f,1) LED_modulation_ind_aft(f,1)])
    title([mouse_name 'cortical contribution'])
    xticks([1 2 3 4 5 6])
    xticklabels({'before 1day','before 1h','before all','aft'})
end

%% averaged figure
figure
tuning_bef1d_mean=mean(tuning_bef1d,1);
tuning_bef1h_mean=mean(tuning_bef1h,1);
tuning_befall_mean=mean(tuning_befall,1);
tuning_aft_mean=mean(tuning_aft,1);
% tuning_aft_2nd_mean=mean(tuning_aft_2nd,1);
% tuning_bef1d_2nd_mean=mean(tuning_bef1d_2nd,1);

tuning_bef1d_withoutLED_SEM = std(tuning_bef1d(:,1),1)./sqrt(size(tuning_bef1d,1));
tuning_bef1h_withoutLED_SEM = std(tuning_bef1h(:,1),1)./sqrt(size(tuning_bef1h,1));
tuning_befall_withoutLED_SEM = std(tuning_befall(:,1),1)./sqrt(size(tuning_befall,1));
tuning_aft_withoutLED_SEM = std(tuning_aft(:,1),1)./sqrt(size(tuning_aft,1));
tuning_bef1d_withLED_SEM = std(tuning_bef1d(:,2),1)./sqrt(size(tuning_bef1d,1));
tuning_bef1h_withLED_SEM = std(tuning_bef1h(:,2),1)./sqrt(size(tuning_bef1h,1));
tuning_befall_withLED_SEM = std(tuning_befall(:,2),1)./sqrt(size(tuning_befall,1));
tuning_aft_withLED_SEM = std(tuning_aft(:,2),1)./sqrt(size(tuning_aft,1));

% tuning_aft_2nd_SEM = std(tuning_aft_2nd,1)./sqrt(size(tuning_aft_2nd,1));
% tuning_bef1h_2nd_SEM = std(tuning_bef1d_2nd,1)./sqrt(size(tuning_bef1d_2nd,1));
errorbar([1 2 3 4], [tuning_bef1d_mean(:,1) tuning_bef1h_mean(:,1) tuning_befall_mean(:,1) tuning_aft_mean(:,1)],[tuning_bef1d_withoutLED_SEM tuning_bef1h_withoutLED_SEM tuning_befall_withoutLED_SEM tuning_aft_withoutLED_SEM ],'Color','k','LineWidth',2);
xticks([1 2 3 4 5 6])
xticklabels({'before 1day','before 1h','before all','aft','2nd before 1h','2nd aft'})
hold on
errorbar([1 2 3 4], [tuning_bef1d_mean(:,2) tuning_bef1h_mean(:,2) tuning_befall_mean(:,2) tuning_aft_mean(:,2)],[tuning_bef1d_withLED_SEM tuning_bef1h_withLED_SEM tuning_befall_withLED_SEM tuning_aft_withLED_SEM ],'Color','b','LineWidth',2);
hold off
title('averaged tuning')
% cortical contribution
figure
LED_modulation_ind_bef1d_mean=mean(LED_modulation_ind_bef1d,1);
LED_modulation_ind_bef1h_mean=mean(LED_modulation_ind_bef1h,1);
LED_modulation_ind_befall_mean=mean(LED_modulation_ind_befall,1);
LED_modulation_ind_aft_mean=mean(LED_modulation_ind_aft,1);

LED_modulation_ind_bef1d_SEM=std(LED_modulation_ind_bef1d(:,1),1)./sqrt(size(LED_modulation_ind_bef1d,1));
LED_modulation_ind_bef1h_SEM=std(LED_modulation_ind_bef1h(:,1),1)./sqrt(size(LED_modulation_ind_bef1h,1));
LED_modulation_ind_befall_SEM=std(LED_modulation_ind_befall(:,1),1)./sqrt(size(LED_modulation_ind_befall,1));
LED_modulation_ind_aft_SEM=std(LED_modulation_ind_aft(:,1),1)./sqrt(size(LED_modulation_ind_aft,1));

errorbar([1 2 3 4], [LED_modulation_ind_bef1d_mean LED_modulation_ind_bef1h_mean LED_modulation_ind_befall_mean LED_modulation_ind_aft_mean],[LED_modulation_ind_bef1d_SEM LED_modulation_ind_bef1h_SEM LED_modulation_ind_befall_SEM LED_modulation_ind_aft_SEM])
title('averaged cortical contribution')
xticks([1 2 3 4 5 6])
xticklabels({'before 1day','before 1h','before all','aft'})
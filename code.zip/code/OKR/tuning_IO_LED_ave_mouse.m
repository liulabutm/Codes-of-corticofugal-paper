
%tuning curve of vertical location with VC silencing after averaging mouses


%paired t test of tuning with or without LED
global OKR_tuning_path OKR_root_path OKR_eye_path
globalpara_OKR;

%run the folders automatically
%load the list of running sequence and the properties of each folder
saveflag=1;   %1=save cal and sortdata

RunFolderSeq=table2cell(readtable([OKR_root_path '\analysis\recording_paras_IO.xlsx'],'Sheet','combine'));
runind=find(cell2mat(RunFolderSeq(:,4)));

% VDind=strfind(RunFolderSeq(:,4),'Ventral');
% for i=1:size(VDind,1)
%     if isempty(VDind{i,1})
%         VDind{i,1}=0;        
%     end    
% end
% VDind=cell2mat(VDind);
% runind=strfind(VDind',1);  %find which one is ventral stream     
% removeind=strfind(cell2mat(RunFolderSeq(runind,5))',0);  %find which one do not need to run within OS stim
% runind(removeind)=[];  %remove the no-run one
for f=1:size(runind,1)
    % changed para for each time
    saline_sitename=RunFolderSeq{runind(f),2};
    CNO_sitename=RunFolderSeq{runind(f),3};
    mouse_name=RunFolderSeq{runind(f),1};
    
    %saline
    salinedata=load([OKR_eye_path saline_sitename '.mat' ]);
    
    tuning_without_LED_saline=(salinedata.datapara.tuningvalue(:,1))';
    tuning_with_LED_saline=(salinedata.datapara.tuningvalue(:,2))';
    
    LED_modulation_ind_saline=(tuning_without_LED_saline-tuning_with_LED_saline)./tuning_without_LED_saline;    
    
    %CNO
    CNOdata=load([OKR_eye_path CNO_sitename '.mat' ]);
    
    tuning_without_LED_CNO=(CNOdata.datapara.tuningvalue(:,1))';
    tuning_with_LED_CNO=(CNOdata.datapara.tuningvalue(:,2))';
    
    LED_modulation_ind_CNO=(tuning_without_LED_CNO-tuning_with_LED_CNO)./tuning_without_LED_CNO;    
    
    
    
    if f==1
        tuning_without_LED_saline_load=tuning_without_LED_saline;
        tuning_with_LED_saline_load=tuning_with_LED_saline;
        LED_modulation_ind_saline_load=LED_modulation_ind_saline;
        tuning_loadseq={mouse_name};
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_saline_load.mat'],'tuning_without_LED_saline_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_saline_load.mat'],'tuning_with_LED_saline_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_saline_load.mat'],'LED_modulation_ind_saline_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat'],'tuning_loadseq');
        tuning_without_LED_CNO_load=tuning_without_LED_CNO;
        tuning_with_LED_CNO_load=tuning_with_LED_CNO;
        LED_modulation_ind_CNO_load=LED_modulation_ind_CNO;
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_CNO_load.mat'],'tuning_without_LED_CNO_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_CNO_load.mat'],'tuning_with_LED_CNO_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_CNO_load.mat'],'LED_modulation_ind_CNO_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat'],'tuning_loadseq');
    else
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_saline_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_saline_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_saline_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat']);
        tuning_without_LED_saline_load(end+1,:)=tuning_without_LED_saline; 
        tuning_with_LED_saline_load(end+1,:)=tuning_with_LED_saline; 
        LED_modulation_ind_saline_load(end+1,:)=LED_modulation_ind_saline;
        tuning_loadseq(end+1,:)={mouse_name};
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_saline_load.mat'],'tuning_without_LED_saline_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_saline_load.mat'],'tuning_with_LED_saline_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_saline_load.mat'],'LED_modulation_ind_saline_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat'],'tuning_loadseq');
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_CNO_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_CNO_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_CNO_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat']);
        tuning_without_LED_CNO_load(end+1,:)=tuning_without_LED_CNO; 
        tuning_with_LED_CNO_load(end+1,:)=tuning_with_LED_CNO; 
        LED_modulation_ind_CNO_load(end+1,:)=LED_modulation_ind_CNO;
        %tuning_loadseq(end+1,:)={mouse_name};
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_CNO_load.mat'],'tuning_without_LED_CNO_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_CNO_load.mat'],'tuning_with_LED_CNO_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_CNO_load.mat'],'LED_modulation_ind_CNO_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat'],'tuning_loadseq');
    end
    
    
    
    clearvars -except RunFolderSeq runind saveflag OKR_tuning_path OKR_root_path OKR_eye_path
    close all
end

%% paired t test
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_loadseq.mat')
load([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_CNO_load.mat']);
load([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_CNO_load.mat']);
load([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_CNO_load.mat']);
load([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_saline_load.mat']);
load([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_saline_load.mat']);
load([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_saline_load.mat']);

Ave_LED_modulation_ind_saline_load=mean(LED_modulation_ind_saline_load,1);
Ave_LED_modulation_ind_CNO_load=mean(LED_modulation_ind_CNO_load,1);
for i=1:size(LED_modulation_ind_CNO_load,2)
    [h_ttest(1,i),p_ttest(1,i)]=ttest(LED_modulation_ind_saline_load(:,i),LED_modulation_ind_CNO_load(:,i),'Tail','right');
    [p_Wil(1,i),h_Wil(1,i)] = signrank(LED_modulation_ind_saline_load(:,i),LED_modulation_ind_CNO_load(:,i),'Tail','right');
end
a=mean(LED_modulation_ind_saline_load,2);
b=mean(LED_modulation_ind_CNO_load,2);
[p_Wil_saline,h_Wil_saline] = signrank(mean(LED_modulation_ind_saline_load,2));
[p_Wil_CNO,h_Wil_CNO] = signrank(mean(LED_modulation_ind_CNO_load,2));
[p_Wil,h_Wil] = signrank(a,b,'Tail','right');

    %[h_ttest,p_ttest]=ttest(tuning_without_LED_load,tuning_with_LED_load);

%% plot tuning of an example mouse
% P-m0
%%%%%%%%%%% CNO
load('E:\OKR_Behavior\eye\40trk211018_roundP-VGTCHR2-m0-SF4ALL.mat')

tuning_withoutLED=datapara.tuningvalue(:,1);
tuning_withLED=datapara.tuningvalue(:,2);
error_withoutLED=datapara.errorvalue(:,1);
error_withLED=datapara.errorvalue(:,2);

figure;
SF=datapara.unipara;

errorbar(SF, tuning_withoutLED, error_withoutLED,'Color', [0.0118 0.0118 0.0118]);
hold on;
errorbar(SF, tuning_withLED, error_withLED,'Color', [0 0.4471 0.7412]);

% xticks([-1 0 1 2])
% xticklabels({' ','upper','lower',' '})
yticks([0 1 2 3 4 5])
yticklabels({'0','1','2','3','4','5 '})

%%%%%%%%%%%% saline
load('E:\OKR_Behavior\eye\40trk211014_roundP-VGTCHR2-m0-SF1ALL.mat')

tuning_withoutLED=datapara.tuningvalue(:,1);
tuning_withLED=datapara.tuningvalue(:,2);
error_withoutLED=datapara.errorvalue(:,1);
error_withLED=datapara.errorvalue(:,2);

figure;
SF=datapara.unipara;

errorbar(SF, tuning_withoutLED, error_withoutLED,'Color', [0.0118 0.0118 0.0118]);
hold on;
errorbar(SF, tuning_withLED, error_withLED,'Color', [0 0.4471 0.7412]);

% xticks([-1 0 1 2])
% xticklabels({' ','upper','lower',' '})
yticks([0 1 2 3 4 5])
yticklabels({'0','1','2','3','4','5 '})


%% plot OKR of with or without LED (individual mouses and average)
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_loadseq.mat')
load([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_CNO_load.mat']);
load([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_CNO_load.mat']);
load([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_CNO_load.mat']);
load([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_saline_load.mat']);
load([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_saline_load.mat']);
load([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_saline_load.mat']);



LEDflag=[0,1];
for j=1:size(tuning_with_LED_saline_load,2)  % upper and lower
    tuning_temp=[tuning_without_LED_load(:,j),tuning_with_LED_saline_load(:,j)];
    figure;
    for i=1:size(tuning_with_LED_saline_load,1)  %individual mouse
        plot(LEDflag,tuning_temp(i,:),'-o');
        xticks([0 1])
        xticklabels({'control','cortical silencing'})
        yticks([0 1 2 3 4 5])
        yticklabels({'0','1','2','3','4','5 '})
        hold on;
    end
    
    figure;
    SEM = std(tuning_temp,1)./sqrt(size(tuning_temp,1));
    Ave_tuning=mean(tuning_temp,1);
    errorbar(LEDflag, Ave_tuning, SEM);
    xticks([-1 0 1 2])
    xticklabels({' ','control','cortical silencing',' '})
    yticks([0 1 2 3 4 5])
    yticklabels({'0','1','2','3','4','5 '})
    
    
    
    
end






%% plot cortical contribution of individual mouses

% hm4d
% load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\tuning_with_LED_CNO_load.mat')
% load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\tuning_with_LED_saline_load.mat')
% load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\tuning_without_LED_CNO_load.mat')
% load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\tuning_without_LED_saline_load.mat')
% load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\LED_modulation_ind_CNO_load.mat')
% load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\LED_modulation_ind_saline_load.mat')
% load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\tuning_loadseq.mat')

% tdtomato
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\tdtomato control\data\tuning_with_LED_CNO_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\tdtomato control\data\tuning_with_LED_saline_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\tdtomato control\data\tuning_without_LED_CNO_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\tdtomato control\data\tuning_without_LED_saline_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\tdtomato control\data\LED_modulation_ind_CNO_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\tdtomato control\data\LED_modulation_ind_saline_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\tdtomato control\data\tuning_loadseq.mat')



SF=[0.04 0.08 0.16 0.32 0.45];

% ventral
figure;
for i=1:size(LED_modulation_ind_CNO_load,1)
    plot(SF,LED_modulation_ind_saline_load(i,:),'-o','Color','k');
    %xticks([0 1])
    %xticklabels({'upper','lower'})
    yticks([-0.5 0 0.1 0.2 0.3])
    yticklabels({'','0','0.1','0.2','0.3'})
    hold on;
end
% legend(tuning_loadseq{i});
% legend off
% 
% legend('1','2','3','4','5','6','7','8','9','10','11');
% legend('off');
% mean 

SEM_ventral = std(LED_modulation_ind_saline_load,1)./sqrt(size(LED_modulation_ind_saline_load,1));
SEM_dorsal = std(LED_modulation_ind_CNO_load,1)./sqrt(size(LED_modulation_ind_CNO_load,1));

Ave_ind_ventral=mean(LED_modulation_ind_saline_load,1);
Ave_ind_dorsal=mean(LED_modulation_ind_CNO_load,1);
hold on;
errorbar(SF, Ave_ind_ventral, SEM_ventral,'Color',[0.4660 0.6740 0.1880],'LineWidth',1.3);

% dorsal
figure;
for i=1:size(LED_modulation_ind_CNO_load,1)
    plot(SF,LED_modulation_ind_CNO_load(i,:),'-o','Color','k');
    %xticks([0 1])
    %xticklabels({'upper','lower'})
    yticks([-0.5 0 0.1 0.2 0.3])
    yticklabels({'','0','0.1','0.2','0.3'})
    hold on;
end
legend(tuning_loadseq{i});
legend off

legend('1','2','3','4','5','6','7','8','9','10','11');
legend('off');
% mean 

SEM_ventral = std(LED_modulation_ind_saline_load,1)./sqrt(size(LED_modulation_ind_saline_load,1));
SEM_dorsal = std(LED_modulation_ind_CNO_load,1)./sqrt(size(LED_modulation_ind_CNO_load,1));

Ave_ind_ventral=mean(LED_modulation_ind_saline_load,1);
Ave_ind_dorsal=mean(LED_modulation_ind_CNO_load,1);
hold on;
errorbar(SF, Ave_ind_dorsal, SEM_dorsal,'Color',[0.8500 0.3250 0.0980],'LineWidth',1.3);


% ventral vs dorsal
figure;
errorbar(SF, Ave_ind_ventral, SEM_ventral,'Color',[0.4660 0.6740 0.1880]);
hold on
errorbar(SF, Ave_ind_dorsal, SEM_dorsal,'Color',[0.8500 0.3250 0.0980]);
% xticks([-1 0 1 2])
% xticklabels({' ','upper','lower',' '})
% yticks([0 1 2 3 4 5])
% yticklabels({'0','1','2','3','4','5 '})



%% average SF of modulation  
LED_modulation_ind_CNO_averageSF=mean(LED_modulation_ind_CNO_load(:,1:5),2); % only average last 4 SF 
LED_modulation_ind_saline_averageSF=mean(LED_modulation_ind_saline_load(:,1:5),2);
[h_ave,p_ave]=ttest(LED_modulation_ind_CNO_averageSF,LED_modulation_ind_saline_averageSF,'Tail','left');
[p_Wil_ave,h_Wil_ave] = signrank(LED_modulation_ind_CNO_averageSF,LED_modulation_ind_saline_averageSF,'Tail','left');
%[p_Wil_ave,h_Wil_ave] = signrank(LED_modulation_ind_saline_averageSF,0,'Tail','right');

figure
for i=1:size(LED_modulation_ind_CNO_load,1)
%     LED_modulation_ind_averageSF_temp(i,1)=mean(LED_modulation_ind_ventral_load(i,2:5),2); % 1st dimention= ventral
%     LED_modulation_ind_averageSF_temp(i,2)=mean(LED_modulation_ind_dorsal_load(i,2:5),2);  % 2nd dimention= dorsal
    plot([1 2],[LED_modulation_ind_CNO_averageSF(i,:),LED_modulation_ind_saline_averageSF(i,:)],'-o','Color','k')
    hold on
end
% average
SEM_ventral_aveSF= std(LED_modulation_ind_CNO_averageSF,1)./sqrt(size(LED_modulation_ind_CNO_averageSF,1));
SEM_dorsal_aveSF= std(LED_modulation_ind_saline_averageSF,1)./sqrt(size(LED_modulation_ind_saline_averageSF,1));

errorbar([1 2],[mean(LED_modulation_ind_CNO_averageSF,1),mean(LED_modulation_ind_saline_averageSF,1)],[SEM_ventral_aveSF,SEM_dorsal_aveSF],'Color','b');

xlim([0,3])
xticks([ 0 1 2 3])
xticklabels({' ','CNO','Saline',' '})
legend({'1','2','3','4','5','6','7','8','9','10','11','12'})
%% 
for i=1:size(LED_modulation_ind_saline_load,2)
    [h_ventral_0(i,1),p_ventral_0(i,1)]=ttest(LED_modulation_ind_saline_load(:,i),0);
    [h_dorsal_0(i,1),p_dorsal_0(i,1)]=ttest(LED_modulation_ind_CNO_load(:,i),0);

    
end




%% plot dots of index of with or without LED
VGT_ind_pos2=LED_modulation_ind_saline_load;
VGT_ind_pos1=LED_modulation_ind_pos1_load;
C57_ind_pos2=LED_modulation_ind_saline_load;
C57_ind_pos1=LED_modulation_ind_pos1_load;
x1=rand(1,size(VGT_ind_pos2,1))/2;
x2=rand(1,size(C57_ind_pos2,1))/2+0.5;
figure;
plot(x1,VGT_ind_pos2,'.');
hold on;
plot(x2,C57_ind_pos2,'.');
hold on;
plot([0,1],[0,0]);

figure;
plot(x1,VGT_ind_pos1,'.');
hold on;
plot(x2,C57_ind_pos1,'.');
hold on;
plot([0,1],[0,0]);


[h_pos2,p_pos2]=ttest2(VGT_ind_pos2,C57_ind_pos2,'Tail','right');
[h_pos1,p_pos1]=ttest2(VGT_ind_pos1,C57_ind_pos1,'Tail','right');

%% compare between CNO and saline without LED
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\tuning_loadseq.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\tuning_with_LED_CNO_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\tuning_with_LED_saline_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\tuning_without_LED_CNO_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\tuning_without_LED_saline_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\LED_modulation_ind_CNO_load.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\OKR behavior\IO\hm4d\data\LED_modulation_ind_saline_load.mat')

% for i=1:size(tuning_without_LED_CNO_load,1)
%    figure
%    plot([1:5], tuning_without_LED_CNO_load(i,:))
%    hold on
%    plot([1:5], tuning_without_LED_saline_load(i,:)) 
%    ylim([0 5]) 
% end

compareSFsele=[1:5];
for i=1:size(tuning_without_LED_CNO_load,1)
    aveTuning_CNO(i,1)=mean(tuning_without_LED_CNO_load(i,compareSFsele));
    aveTuning_saline(i,1)=mean(tuning_without_LED_saline_load(i,compareSFsele));
end

figure
for i=1:size(tuning_without_LED_CNO_load,1)
    plot([1,2],[aveTuning_CNO(i,1),aveTuning_saline(i,1)],'-o')
    hold on
end
xlim([0 3])

SEM_CNO=std(aveTuning_CNO)./sqrt(size(aveTuning_CNO,1));
SEM_saline=std(aveTuning_saline)./sqrt(size(aveTuning_saline,1));
errorbar([0.8 2.2],[mean(aveTuning_CNO),mean(aveTuning_saline)],[SEM_CNO,SEM_saline],'Color','k');
xticks([0 1 2 3])
xticklabels({'','CNO','saline',''})


norm_tuning=tuning_without_LED_CNO_load./tuning_without_LED_saline_load;
mean_norm_tuning=mean(norm_tuning,2);

figure
for i=1:size(tuning_without_LED_CNO_load,1)
    plot(1,mean_norm_tuning(i,1),'-o')
    hold on
end
SEM=std(mean_norm_tuning)./sqrt(size(mean_norm_tuning,1));
errorbar(0.8,mean(mean_norm_tuning),SEM,'Color','k');
xlim([0.5 1.5])


%% plot cortical contribution for example mouse
% ventral
load('E:\OKR_Behavior\eye\40trk211014_roundP-VGTCHR2-m0-SF1ALL.mat')
cortical_contri_saline=(datapara.tuningvalue(:,1)-datapara.tuningvalue(:,2))./datapara.tuningvalue(:,1);

load('E:\OKR_Behavior\eye\40trk211018_roundP-VGTCHR2-m0-SF4ALL.mat')
cortical_contri_CNO=(datapara.tuningvalue(:,1)-datapara.tuningvalue(:,2))./datapara.tuningvalue(:,1);

figure
plot([1:5],cortical_contri_saline,'-o')
title("saline")
ylim([-0.05,0.4])
figure
plot([1:5],cortical_contri_CNO,'-o')
title("CNO")
ylim([-0.05,0.4])



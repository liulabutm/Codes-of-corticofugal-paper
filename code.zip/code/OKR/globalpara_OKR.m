function globalpara_OKR
global OKR_tuning_path OKR_root_path OKR_eye_path OKR_AVE_path

OKR_root_path='E:\OKR_Behavior';
OKR_tuning_path='E:\OKR_Behavior\analysis\tuning';
OKR_eye_path='E:\OKR_Behavior\eye\';
OKR_AVE_path='E:\OKR_Behavior\analysis\Ave tuning among animals';
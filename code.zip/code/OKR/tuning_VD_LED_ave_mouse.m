
%tuning curve of vertical location with VC silencing after averaging mouses


%paired t test of tuning with or without LED
global OKR_tuning_path OKR_root_path OKR_eye_path
globalpara_OKR;

%run the folders automatically
%load the list of running sequence and the properties of each folder
saveflag=1;   %1=save cal and sortdata

RunFolderSeq=table2cell(readtable([OKR_root_path '\analysis\recording_paras_VD.xlsx'],'Sheet','combine'));
runind=find(cell2mat(RunFolderSeq(:,4)));

% VDind=strfind(RunFolderSeq(:,4),'Ventral');
% for i=1:size(VDind,1)
%     if isempty(VDind{i,1})
%         VDind{i,1}=0;        
%     end    
% end
% VDind=cell2mat(VDind);
% runind=strfind(VDind',1);  %find which one is ventral stream     
% removeind=strfind(cell2mat(RunFolderSeq(runind,5))',0);  %find which one do not need to run within OS stim
% runind(removeind)=[];  %remove the no-run one
for f=1:size(runind,1)
    % changed para for each time
    Ventral_sitename=RunFolderSeq{runind(f),2};
    Dorsal_sitename=RunFolderSeq{runind(f),3};
    mouse_name=RunFolderSeq{runind(f),1};
    
    %ventral
    ventraldata=load([OKR_eye_path Ventral_sitename '.mat' ]);
    
    tuning_without_LED_ventral=(ventraldata.datapara.tuningvalue(:,1))';
    tuning_with_LED_ventral=(ventraldata.datapara.tuningvalue(:,2))';
    
    LED_modulation_ind_ventral=(tuning_without_LED_ventral-tuning_with_LED_ventral)./tuning_without_LED_ventral;    
    
    %dorsal
    dorsaldata=load([OKR_eye_path Dorsal_sitename '.mat' ]);
    
    tuning_without_LED_dorsal=(dorsaldata.datapara.tuningvalue(:,1))';
    tuning_with_LED_dorsal=(dorsaldata.datapara.tuningvalue(:,2))';
    
    LED_modulation_ind_dorsal=(tuning_without_LED_dorsal-tuning_with_LED_dorsal)./tuning_without_LED_dorsal;    
    
    
    
    if f==1
        tuning_without_LED_ventral_load=tuning_without_LED_ventral;
        tuning_with_LED_ventral_load=tuning_with_LED_ventral;
        LED_modulation_ind_ventral_load=LED_modulation_ind_ventral;
        tuning_loadseq={mouse_name};
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_ventral_load.mat'],'tuning_without_LED_ventral_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_ventral_load.mat'],'tuning_with_LED_ventral_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_ventral_load.mat'],'LED_modulation_ind_ventral_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat'],'tuning_loadseq');
        tuning_without_LED_dorsal_load=tuning_without_LED_dorsal;
        tuning_with_LED_dorsal_load=tuning_with_LED_dorsal;
        LED_modulation_ind_dorsal_load=LED_modulation_ind_dorsal;
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_dorsal_load.mat'],'tuning_without_LED_dorsal_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_dorsal_load.mat'],'tuning_with_LED_dorsal_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_dorsal_load.mat'],'LED_modulation_ind_dorsal_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat'],'tuning_loadseq');
    else
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_ventral_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_ventral_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_ventral_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat']);
        tuning_without_LED_ventral_load(end+1,:)=tuning_without_LED_ventral; 
        tuning_with_LED_ventral_load(end+1,:)=tuning_with_LED_ventral; 
        LED_modulation_ind_ventral_load(end+1,:)=LED_modulation_ind_ventral;
        tuning_loadseq(end+1,:)={mouse_name};
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_ventral_load.mat'],'tuning_without_LED_ventral_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_ventral_load.mat'],'tuning_with_LED_ventral_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_ventral_load.mat'],'LED_modulation_ind_ventral_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat'],'tuning_loadseq');
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_dorsal_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_dorsal_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_dorsal_load.mat']);
        load([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat']);
        tuning_without_LED_dorsal_load(end+1,:)=tuning_without_LED_dorsal; 
        tuning_with_LED_dorsal_load(end+1,:)=tuning_with_LED_dorsal; 
        LED_modulation_ind_dorsal_load(end+1,:)=LED_modulation_ind_dorsal;
        tuning_loadseq(end+1,:)={mouse_name};
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_without_LED_dorsal_load.mat'],'tuning_without_LED_dorsal_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_with_LED_dorsal_load.mat'],'tuning_with_LED_dorsal_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\LED_modulation_ind_dorsal_load.mat'],'LED_modulation_ind_dorsal_load');
        save([OKR_tuning_path '\vertical location\cortical silencing\tuning_loadseq.mat'],'tuning_loadseq');
    end
    
    
    
    clearvars -except RunFolderSeq runind saveflag OKR_tuning_path OKR_root_path OKR_eye_path
    close all
end

%% paired t test
% load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_loadseq.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_with_LED_dorsal_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_with_LED_ventral_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_without_LED_dorsal_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_without_LED_ventral_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\LED_modulation_ind_dorsal_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\LED_modulation_ind_ventral_load.mat')

Ave_LED_modulation_ind_ventral_load=mean(LED_modulation_ind_ventral_load,1);
Ave_LED_modulation_ind_dorsal_load=mean(LED_modulation_ind_dorsal_load,1);
for i=1:size(LED_modulation_ind_dorsal_load,2)
    [h_ttest(1,i),p_ttest(1,i)]=ttest(LED_modulation_ind_ventral_load(:,i),LED_modulation_ind_dorsal_load(:,i),'Tail','right');
    [p_Wil(1,i),h_Wil(1,i)] = signrank(LED_modulation_ind_ventral_load(:,i),LED_modulation_ind_dorsal_load(:,i),'Tail','right');
end


    %[h_ttest,p_ttest]=ttest(tuning_without_LED_load,tuning_with_LED_load);

%% plot tuning of an example mouse

%%%%%%%%%%% ventral
load('E:\OKR_Behavior\eye\40trk210702_roundJ-VGTCHR2-m0-SF4ALL.mat')

tuning_withoutLED=datapara.tuningvalue(:,1);
tuning_withLED=datapara.tuningvalue(:,2);
error_withoutLED=datapara.errorvalue(:,1);
error_withLED=datapara.errorvalue(:,2);

figure;
SF=datapara.unipara;

errorbar(SF, tuning_withoutLED, error_withoutLED,'Color', [0.0118 0.0118 0.0118]);
hold on;
errorbar(SF, tuning_withLED, error_withLED,'Color', [0 0.4471 0.7412]);

% xticks([-1 0 1 2])
% xticklabels({' ','upper','lower',' '})
yticks([0 1 2 3 4 5])
yticklabels({'0','1','2','3','4','5 '})

%%%%%%%%%%%% dorsal
load('E:\OKR_Behavior\eye\40trk210707_roundJ-VGTCHR2-m0-SF7ALLALL.mat')

tuning_withoutLED=datapara.tuningvalue(:,1);
tuning_withLED=datapara.tuningvalue(:,2);
error_withoutLED=datapara.errorvalue(:,1);
error_withLED=datapara.errorvalue(:,2);

figure;
SF=datapara.unipara;

errorbar(SF, tuning_withoutLED, error_withoutLED,'Color', [0.0118 0.0118 0.0118]);
hold on;
errorbar(SF, tuning_withLED, error_withLED,'Color', [0 0.4471 0.7412]);

% xticks([-1 0 1 2])
% xticklabels({' ','upper','lower',' '})
yticks([0 1 2 3 4 5])
yticklabels({'0','1','2','3','4','5 '})


%% plot OKR of with or without LED (individual mouses and average)
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_loadseq.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_with_LED_dorsal_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_with_LED_ventral_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_without_LED_dorsal_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_without_LED_ventral_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\LED_modulation_ind_dorsal_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\LED_modulation_ind_ventral_load.mat')



LEDflag=[0,1];
for j=1:size(tuning_with_LED_ventral_load,2)  % upper and lower
    tuning_temp=[tuning_without_LED_load(:,j),tuning_with_LED_ventral_load(:,j)];
    figure;
    for i=1:size(tuning_with_LED_ventral_load,1)  %individual mouse
        plot(LEDflag,tuning_temp(i,:),'-o');
        xticks([0 1])
        xticklabels({'control','cortical silencing'})
        yticks([0 1 2 3 4 5])
        yticklabels({'0','1','2','3','4','5 '})
        hold on;
    end
    
    figure;
    SEM = std(tuning_temp,1)./sqrt(size(tuning_temp,1));
    Ave_tuning=mean(tuning_temp,1);
    errorbar(LEDflag, Ave_tuning, SEM);
    xticks([-1 0 1 2])
    xticklabels({' ','control','cortical silencing',' '})
    yticks([0 1 2 3 4 5])
    yticklabels({'0','1','2','3','4','5 '})
    
    
    
    
end






%% plot cortical contribution of individual mouses
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_loadseq.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_with_LED_dorsal_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_with_LED_ventral_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_without_LED_dorsal_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\tuning_without_LED_ventral_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\LED_modulation_ind_dorsal_load.mat')
load('E:\OKR_Behavior\analysis\tuning\vertical location\cortical silencing\LED_modulation_ind_ventral_load.mat')

SF=[0.04 0.08 0.16 0.32 0.45];

% ventral
figure;
for i=1:size(LED_modulation_ind_dorsal_load,1)
    plot(SF,LED_modulation_ind_ventral_load(i,:),'-o','Color','k');
    %xticks([0 1])
    %xticklabels({'upper','lower'})
    yticks([-0.5 0 0.1 0.2 0.3])
    yticklabels({'','0','0.1','0.2','0.3'})
    hold on;
end
legend(tuning_loadseq{i});
legend off

legend('1','2','3','4','5','6','7','8','9','10','11');
legend('off');
% mean 

SEM_ventral = std(LED_modulation_ind_ventral_load,1)./sqrt(size(LED_modulation_ind_ventral_load,1));
SEM_dorsal = std(LED_modulation_ind_dorsal_load,1)./sqrt(size(LED_modulation_ind_dorsal_load,1));

Ave_ind_ventral=mean(LED_modulation_ind_ventral_load,1);
Ave_ind_dorsal=mean(LED_modulation_ind_dorsal_load,1);
hold on;
errorbar(SF, Ave_ind_ventral, SEM_ventral,'Color',[0.4660 0.6740 0.1880],'LineWidth',1.3);

% dorsal
figure;
for i=1:size(LED_modulation_ind_dorsal_load,1)
    plot(SF,LED_modulation_ind_dorsal_load(i,:),'-o','Color','k');
    %xticks([0 1])
    %xticklabels({'upper','lower'})
    yticks([-0.5 0 0.1 0.2 0.3])
    yticklabels({'','0','0.1','0.2','0.3'})
    hold on;
end
legend(tuning_loadseq{i});
legend off

legend('1','2','3','4','5','6','7','8','9','10','11');
legend('off');
% mean 

SEM_ventral = std(LED_modulation_ind_ventral_load,1)./sqrt(size(LED_modulation_ind_ventral_load,1));
SEM_dorsal = std(LED_modulation_ind_dorsal_load,1)./sqrt(size(LED_modulation_ind_dorsal_load,1));

Ave_ind_ventral=mean(LED_modulation_ind_ventral_load,1);
Ave_ind_dorsal=mean(LED_modulation_ind_dorsal_load,1);
hold on;
errorbar(SF, Ave_ind_dorsal, SEM_dorsal,'Color',[0.8500 0.3250 0.0980],'LineWidth',1.3);


% ventral vs dorsal
figure;
errorbar(SF, Ave_ind_ventral, SEM_ventral,'Color',[0.4660 0.6740 0.1880]);
hold on
errorbar(SF, Ave_ind_dorsal, SEM_dorsal,'Color',[0.8500 0.3250 0.0980]);
% xticks([-1 0 1 2])
% xticklabels({' ','upper','lower',' '})
% yticks([0 1 2 3 4 5])
% yticklabels({'0','1','2','3','4','5 '})



%% average SF of modulation  
LED_modulation_ind_ventral_averageSF=mean(LED_modulation_ind_ventral_load(:,2:5),2); % only average last 4 SF 
LED_modulation_ind_dorsal_averageSF=mean(LED_modulation_ind_dorsal_load(:,2:5),2);
[h_ave,p_ave]=ttest(LED_modulation_ind_ventral_averageSF,LED_modulation_ind_dorsal_averageSF,'Tail','right');
[p_Wil_ave,h_Wil_ave] = signrank(LED_modulation_ind_ventral_averageSF,LED_modulation_ind_dorsal_averageSF,'Tail','right');

figure
for i=1:size(LED_modulation_ind_ventral_load,1)
%     LED_modulation_ind_averageSF_temp(i,1)=mean(LED_modulation_ind_ventral_load(i,2:5),2); % 1st dimention= ventral
%     LED_modulation_ind_averageSF_temp(i,2)=mean(LED_modulation_ind_dorsal_load(i,2:5),2);  % 2nd dimention= dorsal
    plot([1 2],[LED_modulation_ind_ventral_averageSF(i,:),LED_modulation_ind_dorsal_averageSF(i,:)],'-o','Color','k')
    hold on
    text(2.2,LED_modulation_ind_dorsal_averageSF(i,:),num2str(i),'FontSize', 10)
end
% average
SEM_ventral_aveSF= std(LED_modulation_ind_ventral_averageSF,1)./sqrt(size(LED_modulation_ind_ventral_averageSF,1));
SEM_dorsal_aveSF= std(LED_modulation_ind_dorsal_averageSF,1)./sqrt(size(LED_modulation_ind_dorsal_averageSF,1));

errorbar([1 2],[mean(LED_modulation_ind_ventral_averageSF,1),mean(LED_modulation_ind_dorsal_averageSF,1)],[SEM_ventral_aveSF,SEM_dorsal_aveSF],'Color','b');

xlim([0,3])
xticks([ 0 1 2 3])
xticklabels({' ','Ventral','Dorsal',' '})
%% 
for i=1:size(LED_modulation_ind_ventral_load,2)
    [h_ventral_0(i,1),p_ventral_0(i,1)]=ttest(LED_modulation_ind_ventral_load(:,i),0);
    [h_dorsal_0(i,1),p_dorsal_0(i,1)]=ttest(LED_modulation_ind_dorsal_load(:,i),0);

    
end




%% plot dots of index of with or without LED
VGT_ind_pos2=LED_modulation_ind_ventral_load;
VGT_ind_pos1=LED_modulation_ind_pos1_load;
C57_ind_pos2=LED_modulation_ind_ventral_load;
C57_ind_pos1=LED_modulation_ind_pos1_load;
x1=rand(1,size(VGT_ind_pos2,1))/2;
x2=rand(1,size(C57_ind_pos2,1))/2+0.5;
figure;
plot(x1,VGT_ind_pos2,'.');
hold on;
plot(x2,C57_ind_pos2,'.');
hold on;
plot([0,1],[0,0]);

figure;
plot(x1,VGT_ind_pos1,'.');
hold on;
plot(x2,C57_ind_pos1,'.');
hold on;
plot([0,1],[0,0]);


[h_pos2,p_pos2]=ttest2(VGT_ind_pos2,C57_ind_pos2,'Tail','right');
[h_pos1,p_pos1]=ttest2(VGT_ind_pos1,C57_ind_pos1,'Tail','right');


%% plot cortical contribution for example mouse
% ventral
load('E:\OKR_Behavior\eye\40trk210713_roundK-VGTCHR2-m2-SF2ALL.mat')

cortical_contri_ventral=(datapara.tuningvalue(:,1)-datapara.tuningvalue(:,2))./datapara.tuningvalue(:,1);

load('E:\OKR_Behavior\eye\40trk210716_roundK-VGTCHR2-m2-SF4ALL.mat')
cortical_contri_dorsal=(datapara.tuningvalue(:,1)-datapara.tuningvalue(:,2))./datapara.tuningvalue(:,1);

figure
plot([1:5],cortical_contri_ventral,'-o')
title("ventral")
ylim([-0.05,0.3])
figure
plot([1:5],cortical_contri_dorsal,'-o')
title("dorsal")
ylim([-0.05,0.3])











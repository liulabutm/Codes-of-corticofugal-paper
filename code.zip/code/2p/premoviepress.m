function premoviepress(Tavevalues, resizefactor, bind, discard1stVolume, smoothmethod, subtractbackground, saturation)
%tasks: compress in (1)time and (2)pixel; (3)bind green and red channels;
%(4)remove discarded Flyback Frames; (5)remove the first volume
global NPYdataparentpath moviedataparentpath vsparaparentpath rawdataparentpath calpath
globalpara;
if nargin<1
    Tavevalues=[2, 1]; % [Tave_2d, Tave_3d]
    resizefactor=0.5;
    bind=0;
    discard1stVolume=true; % only used in 3d imaging
    smoothmethod='sum'; %  'ave'
    subtractbackground=true;
    saturation=true;
end
if isempty(Tavevalues)
    Tavevalues=[2, 1]; % [Tave_2d, Tave_3d]
elseif length(Tavevalues)~=2
    disp('Tave need two values');
    return
end
if isempty(resizefactor)
    resizefactor=0.5; %how much reduce the resolution to speed up
end
if isempty(bind)
    bind=0;
end
if isempty(discard1stVolume)
    discard1stVolume=true; % only used in 3d imaging
end
if isempty(smoothmethod)
    smoothmethod='sum';
end
if isempty(subtractbackground)
    subtractbackground=true;
end
if isempty(saturation)
    saturation=True;
end
numDiscardVolumes=2; %can be changed; make it equal to Tave_3d 

RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));
runind=find(cell2mat(RunFolderSeq(:,6)));

%parpool;%Start parallel pool
for f=1:size(runind,1)  %recording list
    sitename=RunFolderSeq{runind(f),1};
    temppos=strfind(sitename,'_');
    tempname=sitename(1:(temppos(end-1)-1));
    selpath=[rawdataparentpath tempname '\']; %raw data folder; all foler paths terminate with '\'

    %read file name
    filelist=dir(selpath);
    filelistsub={};%containing the file names of original tif
    for i=1:length(filelist)
        if ~isempty(strfind(filelist(i).name, '.tif'))
            filelistsub=[filelistsub filelist(i).name];
        end
    end
    
    %use first file to get the information about tiff file
    filepathtemp=[selpath filelistsub{1}];
    info=imfinfo(filepathtemp);
    numimgsperstim = size(info,1); % images/movie  number of images per stimulus of original tif (each channel provides one image in each frame)
    info=info(1);
    SI_old.SampleFormat=info.SampleFormat;  % data type
    SI_old.ImgHeight=round(info.Height); %%%need change
    SI_old.ImgWidth=round(info.Width);   %%%need change
    SI_old.acqsPerLoop=getheader(info,'Software','SI.acqsPerLoop','%f');
    SI_old.hBeams.powers=getheader(info,'Software','SI.hBeams.powers','%f');
    SI_old.hBeams.pzAdjust=getheader(info,'Software','SI.hBeams.pzAdjust','%l');
    SI_old.hChannels.channelSave=getheader(info,'Software','SI.hChannels.channelSave','%f'); %%%need change
    SI_old.numofchan=length(SI_old.hChannels.channelSave); 
    SI_old.hFastZ.discardFlybackFrames=getheader(info,'Software','SI.hFastZ.discardFlybackFrames','%l'); %flag  %%%do not change; use as history tag; do not use its value in SI
    SI_old.hFastZ.enable=getheader(info,'Software','SI.hFastZ.enable','%l'); %flag
    SI_old.hFastZ.hasFastZ=getheader(info,'Software','SI.hFastZ.hasFastZ','%l'); %flag
    SI_old.hFastZ.numDiscardFlybackFrames=getheader(info,'Software','SI.hFastZ.numDiscardFlybackFrames','%f'); %%%do not change; use as history tag; do not use its value in SI
    SI_old.hFastZ.numFramesPerVolume=getheader(info,'Software','SI.hFastZ.numFramesPerVolume','%f');        %%%need change
    SI_old.hFastZ.numVolumes=getheader(info,'Software','SI.hFastZ.numVolumes','%f');                        %%%need change
    SI_old.hFastZ.waveformType=getheader(info,'Software','SI.hFastZ.waveformType','%s');
    SI_old.hScan2D.channelsDataType=getheader(info,'Software','SI.hScan2D.channelsDataType','%s');
    SI_old.hStackManager.framesPerSlice=getheader(info,'Software','SI.hStackManager.framesPerSlice','%f');  %%%need change in 2d acquistion
    SI_old.hStackManager.numSlices=getheader(info,'Software','SI.hStackManager.numSlices','%f'); %does not include the discarded slice
    SI_old.hStackManager.stackZStepSize=getheader(info,'Software','SI.hStackManager.stackZStepSize','%f');
    SI_old.hStackManager.stackReturnHome=getheader(info,'Software','SI.hStackManager.stackReturnHome','%l'); %flag
    SI_old.hStackManager.stackStartCentered=getheader(info,'Software','SI.hStackManager.stackStartCentered','%l'); %flag
    SI_old.hRoiManager.scanFrameRate=getheader(info,'Software','SI.hRoiManager.scanFrameRate','%f');       %%%need change
    SI_old.hRoiManager.scanVolumeRate=getheader(info,'Software','SI.hRoiManager.scanVolumeRate','%f');     %%%need change
    SI_old.hRoiManager.scanZoomFactor=getheader(info,'Software','SI.hRoiManager.scanZoomFactor','%f');
    discardFlybackFrames=SI_old.hFastZ.discardFlybackFrames;
    SI=SI_old; % new parameter
    if SI_old.hFastZ.enable
        Tave=Tavevalues(2);
        if discardFlybackFrames
            SI.hFastZ.numFramesPerVolume=SI_old.hFastZ.numFramesPerVolume-SI_old.hFastZ.numDiscardFlybackFrames;
            info=setheader(info,'Software','SI.hFastZ.numFramesPerVolume',SI.hFastZ.numFramesPerVolume);
        end        
        if SI.hFastZ.numFramesPerVolume~=SI_old.hStackManager.numSlices
            disp('error: SI.hFastZ.numFramesPerVolume~=SI_old.hStackManager.numSlices');
        end
        if discard1stVolume
            SI.hFastZ.numVolumes=(SI_old.hFastZ.numVolumes-numDiscardVolumes)/Tave; % replace actualnumimgsperstim %remove the first few volumes because of the error in moving trajectory
        else
            SI.hFastZ.numVolumes=SI_old.hFastZ.numVolumes/Tave;  % replace actualnumimgsperstim
        end
        info=setheader(info,'Software','SI.hFastZ.numVolumes',SI.hFastZ.numVolumes);
    else
        Tave=Tavevalues(1);
        SI.hStackManager.framesPerSlice=SI_old.hStackManager.framesPerSlice/Tave;  % replace actualnumimgsperstim
        info=setheader(info,'Software','SI.hStackManager.framesPerSlice',SI.hStackManager.framesPerSlice);
    end
    SI.hRoiManager.scanFrameRate=SI_old.hRoiManager.scanFrameRate/Tave;
    info=setheader(info,'Software','SI.hRoiManager.scanFrameRate',SI.hRoiManager.scanFrameRate);
    SI.hRoiManager.scanVolumeRate=SI_old.hRoiManager.scanVolumeRate/Tave;
    info=setheader(info,'Software','SI.hRoiManager.scanVolumeRate',SI.hRoiManager.scanVolumeRate);
    framerate_old=SI_old.hRoiManager.scanVolumeRate;
    actualframerate=SI.hRoiManager.scanVolumeRate; % frame rate of the compressed tif
    SI.ImgHeight=round(SI_old.ImgHeight*resizefactor);
    if bind
        SI.hChannels.channelSave=1;
        info=setheader(info,'Software','SI.hChannels.channelSave',SI.hChannels.channelSave);
        SI.numofchan=1;
        SI.ImgWidth=round(SI_old.ImgWidth*resizefactor)*SI_old.numofchan;
    else
        SI.ImgWidth=round(SI_old.ImgWidth*resizefactor);
    end
    
    backslashpos=strfind(selpath, '\');
    [SUCCESS,MESSAGE,MESSAGEID]=mkdir(moviedataparentpath,[selpath(backslashpos(end-1)+1:backslashpos(end)-1) '_comp']);
    if ~SUCCESS
        disp('failed in making a new directory');
        return
    end
    comp_path=[moviedataparentpath selpath(backslashpos(end-1)+1:backslashpos(end)-1) '_comp\'];
    
    tagstruct.ImageLength = SI.ImgHeight;
    tagstruct.ImageWidth = SI.ImgWidth;
    tagstruct.SampleFormat = Tiff.SampleFormat.Int;
    tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
    tagstruct.BitsPerSample = 16; % Number of bits per component; component here is color channel
    tagstruct.SamplesPerPixel = 1; % The number of components per pixel;1 for grayscale, 3 for RGB images
    tagstruct.Compression = Tiff.Compression.None;
    tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
    tagstruct.ResolutionUnit=Tiff.ResolutionUnit.Centimeter;
    tagstruct.XResolution=round(SI_old.ImgWidth*resizefactor)/(0.041612*2.5/SI.hRoiManager.scanZoomFactor); %unit  pixels per Centimeter  416.12micron/512pixel for 2.5x zoom  %%%%%%%%%
    tagstruct.YResolution=SI.ImgHeight/(0.041612*2.5/SI.hRoiManager.scanZoomFactor);
    tagstruct.Software=info.Software;
    tagstruct.Artist=info.Artist;
    % derive the min pixel value of the images over the whole exeperiment;
    % for each channel and each slice
    if SI_old.hFastZ.enable %3D
        if discardFlybackFrames
            maxnumSlices=SI_old.hFastZ.numFramesPerVolume-SI_old.hFastZ.numDiscardFlybackFrames;
        else
            maxnumSlices=SI_old.hFastZ.numFramesPerVolume;
        end        
        minpixvalue=zeros(SI_old.numofchan, maxnumSlices, Tave, SI.hFastZ.numVolumes, length(filelistsub)); % channel, slices, volume
    else %2D
        minpixvalue=zeros(SI_old.numofchan, 1, Tave, SI.hStackManager.framesPerSlice, length(filelistsub)); % channel, 1 slice, frame/stim
    end
    parfor j=1:length(filelistsub)
        if SI_old.hFastZ.enable %3D
            if discardFlybackFrames
                maxnumSlices=SI_old.hFastZ.numFramesPerVolume-SI_old.hFastZ.numDiscardFlybackFrames;
            else
                maxnumSlices=SI_old.hFastZ.numFramesPerVolume;
            end        
            minpixvaluetemp=zeros(SI_old.numofchan, maxnumSlices, Tave, SI.hFastZ.numVolumes); % channel, slices, volume
        else %2D
            minpixvaluetemp=zeros(SI_old.numofchan, 1, Tave, SI.hStackManager.framesPerSlice); % channel, 1 slice, frame/stim
        end
        if SI_old.hFastZ.enable  % volume 3d imaging
            if discard1stVolume
                deltaVolNum=numDiscardVolumes/Tave; % consider discarded volumes
            else
                deltaVolNum=0;
            end
            if discardFlybackFrames
                maxnumSlices=SI_old.hFastZ.numFramesPerVolume-SI_old.hFastZ.numDiscardFlybackFrames;
            else
                maxnumSlices=SI_old.hFastZ.numFramesPerVolume;
            end
            for i=1:SI.hFastZ.numVolumes %final volume number per stim (after Tave and discard the first few volumes)
                comp_im=zeros(SI.ImgHeight,SI.ImgWidth,SI_old.numofchan,maxnumSlices, Tave);
                for p=1:Tave 
                    for r=1:maxnumSlices % 2 for jiashu, 4 for lynn by only select remaining slices for each volumne, the last slice/frame is discarded
                        for q=1:SI_old.numofchan                           
                            tempI=double(imread([selpath filelistsub{j}],(i-1+deltaVolNum)*Tave*SI_old.hFastZ.numFramesPerVolume*SI_old.numofchan+(p-1)*SI_old.hFastZ.numFramesPerVolume*SI_old.numofchan+(r-1)*SI_old.numofchan+q)); %single frame; by adding deltaVolNum, 1st few volumes are discarded
                            minpixvaluetemp(q,r,p,i)=min(min(tempI));                          
                        end
                    end
                end
            end
            minpixvalue(:,:,:,:,j)=minpixvaluetemp;
        else        % 2d imaging
            for i=1:SI.hStackManager.framesPerSlice %final frame number per stim
                comp_im=zeros(SI.ImgHeight,SI.ImgWidth,SI_old.numofchan,Tave);               
                for p=1:Tave %ave frames
                    for q=1:SI_old.numofchan
                        tempI=double(imread([selpath filelistsub{j}],(i-1)*Tave*SI_old.numofchan+(p-1)*SI_old.numofchan+q)); %single frame;
                        minpixvaluetemp(q,1,p,i)=min(min(tempI));
                    end
                end                
            end
            minpixvalue(:,:,:,:,j)=minpixvaluetemp;
        end   
    end
    
    minpixvalue_reduced=zeros(size(minpixvalue,1), size(minpixvalue,2), size(minpixvalue,3));
    for p=1:size(minpixvalue,3)
        for r=1:size(minpixvalue,2)
            for q=1:size(minpixvalue,1)
                minpixvalue_reduced(q,r,p)=min(min(minpixvalue(q,r,p,:,:)));
            end
        end
    end
    
    parfor j=1:length(filelistsub)
        imObj = Tiff([comp_path filelistsub{j}],'w'); % for saving processed images
        info=imfinfo([selpath filelistsub{j}]);
        if SI_old.hFastZ.enable  % volume 3d imaging
            if discard1stVolume
                deltaVolNum=numDiscardVolumes/Tave; % consider discarded volumes
            else
                deltaVolNum=0;
            end
            if discardFlybackFrames
                maxnumSlices=SI_old.hFastZ.numFramesPerVolume-SI_old.hFastZ.numDiscardFlybackFrames;
            else
                maxnumSlices=SI_old.hFastZ.numFramesPerVolume;
            end
            for i=1:SI.hFastZ.numVolumes %final volume number per stim (after Tave and discard the first few volumes)
                if bind
                    comp_im=zeros(SI.ImgHeight,SI.ImgWidth,maxnumSlices, Tave); %SI.ImgWidth=round(SI_old.ImgWidth*resizefactor)*SI_old.numofchan
                else
                    comp_im=zeros(SI.ImgHeight,SI.ImgWidth,SI_old.numofchan,maxnumSlices, Tave);
                end
                for p=1:Tave 
                    for r=1:maxnumSlices % 2 for jiashu, 4 for lynn by only select remaining slices for each volumne, the last slice/frame is discarded
                        for q=1:SI_old.numofchan                           
                            tempI=double(imread([selpath filelistsub{j}],(i-1+deltaVolNum)*Tave*SI_old.hFastZ.numFramesPerVolume*SI_old.numofchan+(p-1)*SI_old.hFastZ.numFramesPerVolume*SI_old.numofchan+(r-1)*SI_old.numofchan+q))-minpixvalue_reduced(q,r,p); %single frame; by adding deltaVolNum, 1st few volumes are discarded; make the smallest pixel value to be zero
                            switch lower(smoothmethod)
                                case 'sum'
                                    tempI1 = imresize(tempI, resizefactor, 'bilinear')/(resizefactor^2); % multiplied with (resizefactor^2) to do real binning, which avoid the sacrifice of floating points.
                                case 'ave'
                                    tempI1 = imresize(tempI, resizefactor, 'bilinear'); % multiplied with (resizefactor^2) to do real binning, which avoid the sacrifice of floating points.
                            end
                            if bind %bind channels
                                comp_im(:,(1+(q-1)*size(tempI1,2)):(q*size(tempI1,2)),r,p)=tempI1;
                            else
                                comp_im(:,:,q,r,p)=tempI1;
                            end                            
                        end
                    end
                end
                if bind %sum or save in time
                    switch lower(smoothmethod)
                        case 'sum'
                            sum_comp_im=sum(comp_im,4);
                        case 'ave'
                            sum_comp_im=mean(comp_im,4);
                    end
                    for r=1:maxnumSlices
                        if subtractbackground
                            minsum_comp_im=min(min(sum_comp_im(:,:,r)));
                            sum_comp_im(:,:,r)=sum_comp_im(:,:,r)-minsum_comp_im;
                        end
                        minsum_comp_im=min(min(sum_comp_im(:,:,r)));
                        maxsum_comp_im=max(max(sum_comp_im(:,:,r)));                    
                        if maxsum_comp_im > (2^15-1)
                            disp([comp_path filelistsub{j} ' ' num2str(i) 'volume ' num2str(r) 'slice:' ' data overflow']);
                            if saturation
                                temp=sum_comp_im(:,:,r);
                                temp(temp>2^15-1)=2^15-1;
                                sum_comp_im(:,:,r)=temp;
                            else
                                sum_comp_im(:,:,r)=sum_comp_im(:,:,r)/maxsum_comp_im*2^15-1;
                            end
                            minsum_comp_im=min(min(sum_comp_im(:,:,r)));
                            maxsum_comp_im=max(max(sum_comp_im(:,:,r)));                            
                        end                        
                        setTag(imObj,tagstruct);
                        setTag(imObj,'SMinSampleValue', minsum_comp_im);
                        setTag(imObj,'SMaxSampleValue', maxsum_comp_im);                        
                        setTag(imObj,'ImageDescription',info((i-1+deltaVolNum)*Tave*SI_old.hFastZ.numFramesPerVolume*SI_old.numofchan+(r-1)*SI_old.numofchan+1).ImageDescription);
                        write(imObj,int16(sum_comp_im(:,:,r)));
                        if ~(i==SI.hFastZ.numVolumes && r==maxnumSlices)
                            writeDirectory(imObj);
                        end
                    end
                else
                    switch lower(smoothmethod)
                        case 'sum'
                            sum_comp_im=sum(comp_im,5);
                        case 'ave'
                            sum_comp_im=mean(comp_im,5);
                    end
                    for r=1:maxnumSlices
                        for q=1:SI_old.numofchan
                            if subtractbackground
                                minsum_comp_im=min(min(sum_comp_im(:,:,q,r)));
                                sum_comp_im(:,:,q,r)=sum_comp_im(:,:,q,r)-minsum_comp_im;
                            end
                            minsum_comp_im=min(min(sum_comp_im(:,:,q,r)));
                            maxsum_comp_im=max(max(sum_comp_im(:,:,q,r)));  %%%%%%%%%%%%%%%%%%%%modified
                            if maxsum_comp_im > (2^15-1)               %%%%%%%%%%%%%modified
                                disp([comp_path filelistsub{j} ' ' num2str(i) 'volume ' num2str(r) 'slice ' num2str(q) 'chan:' ' data overflow']);
                                if saturation
                                    temp=sum_comp_im(:,:,q,r);
                                    temp(temp>2^15-1)=2^15-1;
                                    sum_comp_im(:,:,q,r)=temp;
                                else
                                    sum_comp_im(:,:,q,r)=sum_comp_im(:,:,q,r)/maxsum_comp_im*2^15-1;
                                end
                                minsum_comp_im=min(min(sum_comp_im(:,:,q,r)));
                                maxsum_comp_im=max(max(sum_comp_im(:,:,q,r)));
                            end                              
                            setTag(imObj,tagstruct);
                            setTag(imObj,'SMinSampleValue', minsum_comp_im);
                            setTag(imObj,'SMaxSampleValue', maxsum_comp_im);                            
                            setTag(imObj,'ImageDescription',info((i-1+deltaVolNum)*Tave*SI_old.hFastZ.numFramesPerVolume*SI_old.numofchan+(r-1)*SI_old.numofchan+q).ImageDescription);
                            write(imObj,int16(sum_comp_im(:,:,q,r)));
                            if ~(i==SI.hFastZ.numVolumes && q==SI_old.numofchan && r==maxnumSlices)
                                writeDirectory(imObj);
                            end                            
                        end
                    end
                end
            end          
        else        % 2d imaging
            for i=1:SI.hStackManager.framesPerSlice %final frame number per stim
                if bind
                    comp_im=zeros(SI.ImgHeight,SI.ImgWidth,Tave); %SI.ImgWidth=round(SI_old.ImgWidth*resizefactor)*SI_old.numofchan
                else
                    comp_im=zeros(SI.ImgHeight,SI.ImgWidth,SI_old.numofchan,Tave);
                end                
                for p=1:Tave %ave frames
                    for q=1:SI_old.numofchan
                        tempI=double(imread([selpath filelistsub{j}],(i-1)*Tave*SI_old.numofchan+(p-1)*SI_old.numofchan+q))-minpixvalue_reduced(q,1,p); %single frame; make the smallest pixel value to be zero
                        switch lower(smoothmethod)
                            case 'sum'
                                tempI1 = imresize(tempI, resizefactor, 'bilinear')/(resizefactor^2); % multiplied with (resizefactor^2) to do real binning, which avoid the sacrifice of floating points.
                            case 'ave'
                                tempI1 = imresize(tempI, resizefactor, 'bilinear'); % multiplied with (resizefactor^2) to do real binning, which avoid the sacrifice of floating points.
                        end
                        if bind %bind channels
                            comp_im(:,(1+(q-1)*size(tempI1,2)):(q*size(tempI1,2)),p)=tempI1;
                        else
                            comp_im(:,:,q,p)=tempI1;
                        end
                    end
                end
                if bind %sum and save
                    switch lower(smoothmethod)
                        case 'sum'                    
                            sum_comp_im=sum(comp_im,3);
                        case 'ave'
                            sum_comp_im=mean(comp_im,3);
                    end
                    if subtractbackground
                        minsum_comp_im=min(min(sum_comp_im));
                        sum_comp_im=sum_comp_im-minsum_comp_im;
                    end                    
                    minsum_comp_im=min(min(sum_comp_im));
                    maxsum_comp_im=max(max(sum_comp_im));
                    if maxsum_comp_im > (2^15-1)
                        disp([comp_path filelistsub{j} ' ' num2str(i) 'frame:' ' data overflow']);
                        if saturation
                            temp=sum_comp_im;
                            temp(temp>2^15-1)=2^15-1;
                            sum_comp_im=temp;                            
                        else
                            sum_comp_im=sum_comp_im/maxsum_comp_im*2^15-1;                            
                        end
                        minsum_comp_im=min(min(sum_comp_im));
                        maxsum_comp_im=max(max(sum_comp_im));                        
                    end                     
                    setTag(imObj,tagstruct);
                    setTag(imObj,'SMinSampleValue', minsum_comp_im);
                    setTag(imObj,'SMaxSampleValue', maxsum_comp_im);
                    setTag(imObj,'ImageDescription',info((i-1)*Tave*SI_old.numofchan+1).ImageDescription);
                    write(imObj,int16(sum_comp_im));
                    if ~(i==SI.hStackManager.framesPerSlice)
                        writeDirectory(imObj);
                    end
                else
                    switch lower(smoothmethod)
                        case 'sum'
                            sum_comp_im=sum(comp_im,4);                 
                        case 'ave'
                            sum_comp_im=mean(comp_im,4);
                    end
                    for q=1:SI_old.numofchan
                        if subtractbackground
                            minsum_comp_im=min(min(sum_comp_im(:,:,q)));
                            sum_comp_im(:,:,q)=sum_comp_im(:,:,q)-minsum_comp_im;
                        end
                        minsum_comp_im=min(min(sum_comp_im(:,:,q)));
                        maxsum_comp_im=max(max(sum_comp_im(:,:,q)));                    
                        if maxsum_comp_im > (2^15-1)
                            disp([comp_path filelistsub{j} ' ' num2str(i) 'frame ' num2str(q) 'chan:' ' data overflow']);
                            if saturation
                                temp=sum_comp_im(:,:,q);
                                temp(temp>2^15-1)=2^15-1;
                                sum_comp_im(:,:,q)=temp;
                            else
                                sum_comp_im(:,:,q)=sum_comp_im(:,:,q)/maxsum_comp_im*2^15-1;
                            end
                            minsum_comp_im=min(min(sum_comp_im(:,:,q)));
                            maxsum_comp_im=max(max(sum_comp_im(:,:,q)));
                        end                          
                        setTag(imObj,tagstruct);
                        setTag(imObj,'SMinSampleValue', minsum_comp_im);
                        setTag(imObj,'SMaxSampleValue', maxsum_comp_im);
                        setTag(imObj,'ImageDescription',info((i-1)*Tave*SI_old.numofchan+q).ImageDescription);
                        write(imObj,int16(sum_comp_im(:,:,q)));
                        if ~(i==SI.hStackManager.framesPerSlice && q==SI_old.numofchan)
                            writeDirectory(imObj);
                        end                            
                    end
                end                
            end
        end
        close(imObj);    
    end
    save([comp_path 'imagepara.mat'], 'Tavevalues', 'resizefactor', 'bind', 'discard1stVolume', 'numDiscardVolumes', 'NPYdataparentpath', 'moviedataparentpath', 'vsparaparentpath', 'rawdataparentpath', 'calpath', 'SI_old', 'SI', 'Tave', 'framerate_old', 'actualframerate');
    clearvars -except saturation subtractbackground smoothmethod Tavevalues resizefactor bind discard1stVolume numDiscardVolumes NPYdataparentpath moviedataparentpath vsparaparentpath rawdataparentpath calpath RunFolderSeq runind  
end
delete(gcp('nocreate')); % end parallel pool

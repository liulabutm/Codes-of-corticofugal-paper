function update_conversion(step_num)
%%step_num: 
%which step need to be updated to all conversion files of the same mouse

%parent folder for the conversion file of each mouse
conversion_folder='E:\two-photon imaging\jiashu\data\blood vessel match';

%get updated conversion file
cd(conversion_folder)
[filename, pathname] = uigetfile({'*.mat'},'File Selector');
temp=load(strcat(pathname, filename));
%get the updated info for specific step
temp=temp.conversion(step_num,:);

%get parent folder path
backslash_ind=strfind(pathname,'\');
parent_folder=pathname(1:(backslash_ind(end-1)-1));
recording_name=pathname((backslash_ind(end-1)+1):(end-1));

%get other recording folders of the same mouse
recording_folders = dir(parent_folder); 
list_recording=string({recording_folders([recording_folders.isdir]).name})';
%remove '.' and '..' for list_recording
dot_flag=strfind(list_recording,'.');
remove_ind=[];
for p=1:length(dot_flag)
    if sum(dot_flag{p,1})>0
        remove_ind=[remove_ind p];
    end
end
list_recording(remove_ind)=[];

% update conversion to all recording of the same mouse
for i = 1:length(list_recording)
    if list_recording(i) ~= recording_name
        if isfile([parent_folder '\' list_recording{i} '\conversion.mat'])
            load([parent_folder '\' list_recording{i} '\conversion.mat'])
            conversion(step_num,:)=temp;
            cd([parent_folder '\' list_recording{i}])
            save('conversion.mat','conversion')
        end
    end
end


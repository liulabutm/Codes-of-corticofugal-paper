function varargout = mapping(varargin)
% MAPPING MATLAB code for mapping.fig
%      MAPPING, by itself, creates a new MAPPING or raises the existing
%      singleton*.
%
%      H = MAPPING returns the handle to a new MAPPING or the handle to
%      the existing singleton*.
%
%      MAPPING('Callback',hObject,eventData,handles,...) calls the local
%      function named Callback in MAPPING.M with the given input arguments.
%
%      MAPPING('Property','Value',...) creates a new MAPPING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before mapping_OpeningFcn gets called.  An
%      unrecognized property name or invalid value mamapping_para.map_stepes property application
%      stop.  All inputs are passed to mapping_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help mapping

% Last Modified by GUIDE v2.5 10-May-2020 15:43:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @mapping_OpeningFcn, ...
                   'gui_OutputFcn',  @mapping_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before mapping is made visible.
function mapping_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to mapping (see VARARGIN)

% Choose default command line output for mapping
global fighandle
fighandle=figure;
set(fighandle,'position', [1300 -200 1200 1000]);
global conversion %initiating conversion file & set default values
conversion = cell(5,1); 
%the conversion parameter files
%conversion(1,1): step1
%conversion(2,1): step2
%conversion(3,1): step3
%conversion(4,1): step4
%conversion(5,1): step5 - outlining cortex
conversion{1,1}.img1=[];
conversion{1,1}.img1_path=[];
conversion{1,1}.img2=[];
conversion{1,1}.img2_path=[];
conversion{1,1}.shift=[0;0]; %first y and then x %right:+,lef:t-,up:-,down:+
conversion{1,1}.angle=0;%counterclocmapping_para.map_stepwise +, closewise - 
conversion{1,1}.ratio=[1;1];%first y and then x
conversion{1,1}.zoom=0.4;
conversion{1,1}.done=0;
conversion{2,1}.img1=[];
conversion{2,1}.img1_path=[];
conversion{2,1}.img2=[];
conversion{2,1}.img2_path=[];
conversion{2,1}.shift=[0;0];%first y and then x
conversion{2,1}.angle=0;
conversion{2,1}.ratio=[1;1];%first y and then x
conversion{2,1}.zoom=0.8;
conversion{2,1}.done=0;
conversion{3,1}.img1=[];
conversion{3,1}.img1_path=[];
conversion{3,1}.img2=[];
conversion{3,1}.img2_path=[];
conversion{3,1}.shift=[0;0];%first y and then x
conversion{3,1}.angle=0;
conversion{3,1}.ratio=[1;1];%first y and then x
conversion{3,1}.zoom=1;
conversion{3,1}.done=0;
conversion{4,1}.img1=[];
conversion{4,1}.img1_path=[];
conversion{4,1}.img2=[];
conversion{4,1}.img2_path=[];
conversion{4,1}.shift=[0;0];%first y and then x
conversion{4,1}.angle=0;
conversion{4,1}.ratio=[1;1];%first y and then x
conversion{4,1}.zoom=0.3;
conversion{4,1}.done=0;
conversion{5,1}.img=[];
conversion{5,1}.img_path=[];
conversion{5,1}.angle=0;
conversion{5,1}.done=0;
conversion{5,1}.outline=[];%outline is the combination of midline and outer_edge
conversion{5,1}.midline=[]; 
conversion{5,1}.outer_edge=[];

handles.output = hObject;
set(handles.axes1,'visible', 'off');
set(handles.axes2,'visible', 'off');
set(handles.axes3,'visible', 'off');
% Update handles structure
guidata(hObject, handles);

% UIWAIT mamapping_para.map_stepes mapping wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = mapping_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in two_photon_40x.
function two_photon_40x_Callback(hObject, eventdata, handles)
% hObject    handle to two_photon_40x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
[filename1, pathname1] = uigetfile({'*.tif'},'File Selector');
mapping_para.two_photon_40x = imread(strcat(pathname1, filename1)); %color code in uint8
mapping_para.savepath=pathname1;
mapping_para.path1=strcat(pathname1, filename1);



% --- Executes on button press in two_photon_25x.
function two_photon_25x_Callback(hObject, eventdata, handles)
% hObject    handle to two_photon_25x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
[filename2, pathname2] = uigetfile({'*.tif'},'File Selector');
mapping_para.two_photon_25x = imread(strcat(pathname2, filename2)); %color code in uint8
mapping_para.path2=strcat(pathname2, filename2);



% --- Executes on button press in cranial_window.
function cranial_window_Callback(hObject, eventdata, handles)
% hObject    handle to cranial_window (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
[filename3, pathname3] = uigetfile({'*.tif'},'File Selector');
mapping_para.cranial_window = im2uint8(rgb2gray(imread(strcat(pathname3, filename3)))); %color code in uint8
mapping_para.path3=strcat(pathname3, filename3);


% --- Executes on button press in halfbrain_25x.
function halfbrain_25x_Callback(hObject, eventdata, handles)
% hObject    handle to halfbrain_25x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
[filename4, pathname4] = uigetfile({'*.tif'},'File Selector');
half_brain_25x = im2uint8(imread(strcat(pathname4, filename4))); %color code in uint8
%since blood vessel is red, green matrix will give the most contrast
mapping_para.half_brain_25x_green= half_brain_25x(:,:,2); 
mapping_para.path4=strcat(pathname4, filename4);


% --- Executes on button press in halfbrain_8x.
function halfbrain_8x_Callback(hObject, eventdata, handles)
% hObject    handle to halfbrain_8x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
global conversion
[filename5, pathname5] = uigetfile({'*.tif'},'File Selector');
half_brain_8x = im2uint8(imread(strcat(pathname5, filename5)));%color code in uint8
if isfile(strcat(pathname5, filename5(1:end-4),' - Copy.tif'))
    half_brain_8x_map=im2uint8(imread(strcat(pathname5, filename5(1:end-4),' - Copy.tif')));%get the orginial file
    mapping_para.half_brain_8x=half_brain_8x_map;
else
    mapping_para.half_brain_8x=half_brain_8x;
end

%resets outline matrixes if image change
if ~isempty(conversion{5,1}.outline) & ~strcmp(conversion{5,1}.img_path,strcat(pathname5, filename5))
    conversion{5,1}.outline=[];%outline is the combination of midline and outer_edge
    conversion{5,1}.midline=[]; 
    conversion{5,1}.outer_edge=[];
end

%since blood vessel is red, green matrix will give the most contrast
mapping_para.half_brain_8x_green= half_brain_8x(:,:,2);
mapping_para.path5=strcat(pathname5, filename5);



% --- Executes on button press in display1.
function display1_Callback(hObject, eventdata, handles)
% hObject    handle to display1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of display1

%only one display on
set(handles.display2,'Value',0);
set(handles.display3,'Value',0);
set(handles.display4,'Value',0);
set(handles.display5,'Value',0);

global mapping_para
global conversion

mapping_para.map_step=1;
mapping_para.img1 = mapping_para.two_photon_40x;
mapping_para.img2 =mapping_para.two_photon_25x;

mapping_para.img1 = (mapping_para.img1 - min(mapping_para.img1)) ./ (max(mapping_para.img1) - min(mapping_para.img1)) .* 255; %increase contrast
mapping_para.img2 = (mapping_para.img2 - min(mapping_para.img2)) ./ (max(mapping_para.img2) - min(mapping_para.img2)) .* 255; 

mapping_para.img1 = 255 - mapping_para.img1; %inverst color
mapping_para.R_img1 =  imref2d(size(mapping_para.img1));
mapping_para.img2 = 255 - mapping_para.img2;
mapping_para.R_img2 =  imref2d(size(mapping_para.img2));

%display values to gui
mapping_para.shift_step = 10;
mapping_para.angle_step = 5;
mapping_para.t = 0.1;
mapping_para.rect=[];
set(handles.shift_step,'String', num2str(mapping_para.shift_step));
set(handles.angle_step,'String',num2str(mapping_para.angle_step));
set(handles.waitPeriodSecs,'String',num2str(mapping_para.t));
set(handles.zoom,'String',num2str(conversion{mapping_para.map_step,1}.zoom));
set(handles. x_ratio,'String',num2str(conversion{mapping_para.map_step,1}.ratio(2,1)));
set(handles. y_ratio,'String',num2str(conversion{mapping_para.map_step,1}.ratio(1,1)));

img1_new=imrotate(mapping_para.img1,conversion{mapping_para.map_step,1}.angle,'bicubic','loose');
 %compensate for the image center change due to image size change during
 %rotation, so that the image center before and after rotation is the same
Center_shift=(size(img1_new)/2)'-(size(mapping_para.img1)/2)';
Center_shift=(Center_shift*conversion{mapping_para.map_step,1}.zoom).*conversion{mapping_para.map_step,1}.ratio;
numrow=round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(1,1)*size(img1_new,1)); %y
numcol = round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(2,1)*size(img1_new,2)); %x
%the left corner stays the same during resizing
img1_new=imresize(img1_new, [numrow,numcol]);
R_img1_new = imref2d(size(img1_new));
%changing WorldLimits change the start and end points along the axis 
R_img1_new.XWorldLimits=R_img1_new.XWorldLimits +conversion{mapping_para.map_step,1}.shift(2,1)-Center_shift(2,1);
R_img1_new.YWorldLimits=R_img1_new.YWorldLimits +conversion{mapping_para.map_step,1}.shift(1,1)-Center_shift(1,1);

[mapping_para.img,~] = imfuse(img1_new,R_img1_new,mapping_para.img2,mapping_para.R_img2,'falsecolor','Scaling','joint','ColorChannels', [1 2 0]);

axes(handles.axes1);
imshow(mapping_para.img);

dis_img1=uint8(zeros([size(mapping_para.img1),3]));
dis_img1(:,:,1)=mapping_para.img1;
axes(handles.axes2);
imshow(dis_img1);

dis_img2=uint8(zeros([size(mapping_para.img2),3]));
dis_img2(:,:,2)=mapping_para.img2;
axes(handles.axes3);
imshow(dis_img2);


% --- Executes on button press in display2.
function display2_Callback(hObject, eventdata, handles)
% hObject    handle to display2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%only one display is on
set(handles.display1,'Value',0);
set(handles.display3,'Value',0);
set(handles.display4,'Value',0);
set(handles.display5,'Value',0);

global mapping_para
global conversion

mapping_para.map_step=2;
mapping_para.img1 = mapping_para.two_photon_25x;
mapping_para.img2 =mapping_para.cranial_window;

mapping_para.img1 = (mapping_para.img1 - min(mapping_para.img1)) ./ (max(mapping_para.img1) - min(mapping_para.img1)) .* 255; %increase contrast
mapping_para.img2 = (mapping_para.img2 - min(mapping_para.img2)) ./ (max(mapping_para.img2) - min(mapping_para.img2)) .* 255; 

mapping_para.img1 = 255 - mapping_para.img1; %inverst color
mapping_para.R_img1 =  imref2d(size(mapping_para.img1));
mapping_para.img2 = 255 - mapping_para.img2;
mapping_para.R_img2 =  imref2d(size(mapping_para.img2));

%display values to gui
mapping_para.shift_step = 10;
mapping_para.angle_step = 5;
mapping_para.t = 0.1;
mapping_para.rect=[];
set(handles.shift_step,'String', num2str(mapping_para.shift_step));
set(handles.angle_step,'String',num2str(mapping_para.angle_step));
set(handles.waitPeriodSecs,'String',num2str(mapping_para.t));
set(handles.zoom,'String',num2str(conversion{mapping_para.map_step,1}.zoom));
set(handles. x_ratio,'String',num2str(conversion{mapping_para.map_step,1}.ratio(2,1)));
set(handles. y_ratio,'String',num2str(conversion{mapping_para.map_step,1}.ratio(1,1)));

img1_new=imrotate(mapping_para.img1,conversion{mapping_para.map_step,1}.angle,'bicubic','loose');
 %compensate for the image center change due to image size change during
 %rotation, so that the image center before and after rotation is the same
Center_shift=(size(img1_new)/2)'-(size(mapping_para.img1)/2)';
Center_shift=(Center_shift*conversion{mapping_para.map_step,1}.zoom).*conversion{mapping_para.map_step,1}.ratio;
numrow=round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(1,1)*size(img1_new,1)); %y
numcol = round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(2,1)*size(img1_new,2)); %x
%the left corner stays the same during resizing
img1_new=imresize(img1_new, [numrow,numcol]);
R_img1_new = imref2d(size(img1_new));
%changing WorldLimits change the start and end points along the axis 
R_img1_new.XWorldLimits=R_img1_new.XWorldLimits +conversion{mapping_para.map_step,1}.shift(2,1)-Center_shift(2,1);
R_img1_new.YWorldLimits=R_img1_new.YWorldLimits +conversion{mapping_para.map_step,1}.shift(1,1)-Center_shift(1,1);

[mapping_para.img,~] = imfuse(img1_new,R_img1_new,mapping_para.img2,mapping_para.R_img2,'falsecolor','Scaling','joint','ColorChannels', [1 2 0]);

axes(handles.axes1);
imshow(mapping_para.img);

dis_img1=uint8(zeros([size(mapping_para.img1),3]));
dis_img1(:,:,1)=mapping_para.img1;
axes(handles.axes2);
imshow(dis_img1);

dis_img2=uint8(zeros([size(mapping_para.img2),3]));
dis_img2(:,:,2)=mapping_para.img2;
axes(handles.axes3);
imshow(dis_img2);

% Hint: get(hObject,'Value') returns toggle state of display2


% --- Executes on button press in display3.
function display3_Callback(hObject, eventdata, handles)
% hObject    handle to display3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%only one display is on at a time
set(handles.display1,'Value',0);
set(handles.display2,'Value',0);
set(handles.display4,'Value',0);
set(handles.display5,'Value',0);

global mapping_para
global conversion

mapping_para.map_step=3;
mapping_para.img1 = mapping_para.cranial_window;
mapping_para.img2 =mapping_para.half_brain_25x_green;

mapping_para.img1 = (mapping_para.img1 - min(mapping_para.img1)) ./ (max(mapping_para.img1) - min(mapping_para.img1)) .* 255; %increase contrast
mapping_para.img2 = (mapping_para.img2 - min(mapping_para.img2)) ./ (max(mapping_para.img2) - min(mapping_para.img2)) .* 255; 

mapping_para.img1 = 255 - mapping_para.img1; %inverst color
mapping_para.R_img1 =  imref2d(size(mapping_para.img1));
mapping_para.img2 = 255 - mapping_para.img2;
mapping_para.R_img2 =  imref2d(size(mapping_para.img2));

%display values to gui
mapping_para.shift_step = 10;
mapping_para.angle_step = 5;
mapping_para.t = 0.1;
mapping_para.rect=[];
set(handles.shift_step,'String', num2str(mapping_para.shift_step));
set(handles.angle_step,'String',num2str(mapping_para.angle_step));
set(handles.waitPeriodSecs,'String',num2str(mapping_para.t));
set(handles.zoom,'String',num2str(conversion{mapping_para.map_step,1}.zoom));
set(handles. x_ratio,'String',num2str(conversion{mapping_para.map_step,1}.ratio(2,1)));
set(handles. y_ratio,'String',num2str(conversion{mapping_para.map_step,1}.ratio(1,1)));

img1_new=imrotate(mapping_para.img1,conversion{mapping_para.map_step,1}.angle,'bicubic','loose');
 %compensate for the image center change due to image size change during
 %rotation, so that the image center before and after rotation is the same
Center_shift=(size(img1_new)/2)'-(size(mapping_para.img1)/2)';
Center_shift=(Center_shift*conversion{mapping_para.map_step,1}.zoom).*conversion{mapping_para.map_step,1}.ratio;
numrow=round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(1,1)*size(img1_new,1)); %y
numcol = round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(2,1)*size(img1_new,2)); %x
%the left corner stays the same during resizing
img1_new=imresize(img1_new, [numrow,numcol]);
R_img1_new = imref2d(size(img1_new));
%changing WorldLimits change the start and end points along the axis 
R_img1_new.XWorldLimits=R_img1_new.XWorldLimits +conversion{mapping_para.map_step,1}.shift(2,1)-Center_shift(2,1);
R_img1_new.YWorldLimits=R_img1_new.YWorldLimits +conversion{mapping_para.map_step,1}.shift(1,1)-Center_shift(1,1);

[mapping_para.img,~] = imfuse(img1_new,R_img1_new,mapping_para.img2,mapping_para.R_img2,'falsecolor','Scaling','joint','ColorChannels', [1 2 0]);

axes(handles.axes1);
imshow(mapping_para.img);

dis_img1=uint8(zeros([size(mapping_para.img1),3]));
dis_img1(:,:,1)=mapping_para.img1;
axes(handles.axes2);
imshow(dis_img1);

dis_img2=uint8(zeros([size(mapping_para.img2),3]));
dis_img2(:,:,2)=mapping_para.img2;
axes(handles.axes3);
imshow(dis_img2);

% Hint: get(hObject,'Value') returns toggle state of display3


% --- Executes on button press in display4.
function display4_Callback(hObject, eventdata, handles)
% hObject    handle to display4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%only one display is on at a time
set(handles.display1,'Value',0);
set(handles.display2,'Value',0);
set(handles.display3,'Value',0);
set(handles.display5,'Value',0);

global mapping_para
global conversion

mapping_para.map_step=4;
mapping_para.img1 = mapping_para.half_brain_25x_green;
mapping_para.img2 =mapping_para.half_brain_8x_green;

mapping_para.img1 = (mapping_para.img1 - min(mapping_para.img1)) ./ (max(mapping_para.img1) - min(mapping_para.img1)) .* 255; %increase contrast
mapping_para.img2 = (mapping_para.img2 - min(mapping_para.img2)) ./ (max(mapping_para.img2) - min(mapping_para.img2)) .* 255; 

mapping_para.img1 = 255 - mapping_para.img1; %inverst color
mapping_para.R_img1 =  imref2d(size(mapping_para.img1));
mapping_para.img2 = 255 - mapping_para.img2;
mapping_para.R_img2 =  imref2d(size(mapping_para.img2));

%display values to gui
mapping_para.shift_step = 10;
mapping_para.angle_step = 5;
mapping_para.t = 0.1;
mapping_para.rect=[];
set(handles.shift_step,'String', num2str(mapping_para.shift_step));
set(handles.angle_step,'String',num2str(mapping_para.angle_step));
set(handles.waitPeriodSecs,'String',num2str(mapping_para.t));
set(handles.zoom,'String',num2str(conversion{mapping_para.map_step,1}.zoom));
set(handles. x_ratio,'String',num2str(conversion{mapping_para.map_step,1}.ratio(2,1)));
set(handles. y_ratio,'String',num2str(conversion{mapping_para.map_step,1}.ratio(1,1)));

img1_new=imrotate(mapping_para.img1,conversion{mapping_para.map_step,1}.angle,'bicubic','loose');
 %compensate for the image center change due to image size change during
 %rotation, so that the image center before and after rotation is the same
Center_shift=(size(img1_new)/2)'-(size(mapping_para.img1)/2)';
Center_shift=(Center_shift*conversion{mapping_para.map_step,1}.zoom).*conversion{mapping_para.map_step,1}.ratio;
numrow=round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(1,1)*size(img1_new,1)); %y
numcol = round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(2,1)*size(img1_new,2)); %x
%the left corner stays the same during resizing
img1_new=imresize(img1_new, [numrow,numcol]);
R_img1_new = imref2d(size(img1_new));
%changing WorldLimits change the start and end points along the axis 
R_img1_new.XWorldLimits=R_img1_new.XWorldLimits +conversion{mapping_para.map_step,1}.shift(2,1)-Center_shift(2,1);
R_img1_new.YWorldLimits=R_img1_new.YWorldLimits +conversion{mapping_para.map_step,1}.shift(1,1)-Center_shift(1,1);

[mapping_para.img,~] = imfuse(img1_new,R_img1_new,mapping_para.img2,mapping_para.R_img2,'falsecolor','Scaling','joint','ColorChannels', [1 2 0]);

axes(handles.axes1);
imshow(mapping_para.img);

dis_img1=uint8(zeros([size(mapping_para.img1),3]));
dis_img1(:,:,1)=mapping_para.img1;
axes(handles.axes2);
imshow(dis_img1);

dis_img2=uint8(zeros([size(mapping_para.img2),3]));
dis_img2(:,:,2)=mapping_para.img2;
axes(handles.axes3);
imshow(dis_img2);
% Hint: get(hObject,'Value') returns toggle state of display4

% --- Executes on button press in display5.
function display5_Callback(hObject, eventdata, handles)
% hObject    handle to display5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%only one display is on at a time
set(handles.display1,'Value',0);
set(handles.display2,'Value',0);
set(handles.display3,'Value',0);
set(handles.display4,'Value',0);

global mapping_para
global conversion 
global fighandle

mapping_para.map_step=5;

%display values to gui
mapping_para.angle_step = 5;
mapping_para.t = 0.1;
set(handles.angle_step,'String',num2str(mapping_para.angle_step))
set(handles.waitPeriodSecs,'String',num2str(mapping_para.t))

figure(fighandle);
set(fighandle,'position', [1300 -200 1200 1000]);
imshow((mapping_para.half_brain_8x));
if  ~isempty(conversion{5,1}.outline)
    outline=[conversion{5,1}.outline;conversion{5,1}.outline(1,:)];%make it an enclosed shape
    mapping_para.midline=conversion{5,1}.midline; 
    mapping_para.outer_edge=conversion{5,1}.outer_edge; 
    mapping_para.outline=conversion{5,1}.outline;
    hold on
    plot(outline(:,1), outline(:,2), '-x','Color','b')
    plot(mapping_para.midline(:,1), mapping_para.midline(:,2), '-x','Color','g')
    hold off
end
mapping_para.midline=conversion{5,1}.midline; 
mapping_para.outline=conversion{5,1}.outline;
mapping_para.outer_edge=conversion{5,1}.outer_edge;

mask=zeros(size(mapping_para.half_brain_8x));
mask=mask+255;
axes(handles.axes2);
imshow(mask);
axes(handles.axes3);
imshow(mask);

% Hint: get(hObject,'Value') returns toggle state of display5

% --- Executes on button press in load_conversion.
function load_conversion_Callback(hObject, eventdata, handles)
% hObject    handle to load_conversion (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
[filename, pathname] = uigetfile({'*.mat'},'File Selector');
temp= load(strcat(pathname, filename));

if strcmp(conversion{1,1}.img1_path,temp.conversion{1,1}.img1_path)
    set(handles.done1,'Value',temp.conversion{1,1}.done);
    conversion{1,1}.done=temp.conversion{1,1}.done;
    set(handles.done2,'Value',temp.conversion{2,1}.done);
    conversion{2,1}.done=temp.conversion{2,1}.done;
end
set(handles.done3,'Value',temp.conversion{3,1}.done);
conversion{3,1}.done=temp.conversion{3,1}.done;
set(handles.done4,'Value',temp.conversion{4,1}.done);
conversion{4,1}.done=temp.conversion{4,1}.done;

for i=1:4
    conversion{i,1}.shift=temp.conversion{i,1}.shift; %first y and then x
    conversion{i,1}.angle=temp.conversion{i,1}.angle;
    conversion{i,1}.ratio=temp.conversion{i,1}.ratio;
    conversion{i,1}.zoom=temp.conversion{i,1}.zoom;
end

if size(temp.conversion,1)==5
    conversion{5,1}.angle=temp.conversion{5,1}.angle;
    set(handles.done5,'Value',temp.conversion{5,1}.done);
    conversion{5,1}.done=temp.conversion{5,1}.done;
end



% --- Executes on button press in load_all.
function load_all_Callback(hObject, eventdata, handles)
% hObject    handle to load_all (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
global conversion
[filename, pathname] = uigetfile({'*.mat'},'File Selector');
temp= load(strcat(pathname, filename));

set(handles.done1,'Value',temp.conversion{1,1}.done);
conversion{1,1}.done=temp.conversion{1,1}.done;
set(handles.done2,'Value',temp.conversion{2,1}.done);
conversion{2,1}.done=temp.conversion{2,1}.done;
set(handles.done3,'Value',temp.conversion{3,1}.done);
conversion{3,1}.done=temp.conversion{3,1}.done;
set(handles.done4,'Value',temp.conversion{4,1}.done);
conversion{4,1}.done=temp.conversion{4,1}.done;

for i=1:4
    conversion{i,1}.shift=temp.conversion{i,1}.shift; %first y and then x
    conversion{i,1}.angle=temp.conversion{i,1}.angle;
    conversion{i,1}.ratio=temp.conversion{i,1}.ratio;
    conversion{i,1}.zoom=temp.conversion{i,1}.zoom;
end

mapping_para.two_photon_40x = temp.conversion{1,1}.img1; 
mapping_para.two_photon_25x = temp.conversion{2,1}.img1; 
mapping_para.cranial_window = temp.conversion{3,1}.img1;
mapping_para.half_brain_25x_green= temp.conversion{4,1}.img1; 
mapping_para.half_brain_8x_green= temp.conversion{4,1}.img2;
mapping_para.path1=temp.conversion{1,1}.img1_path;
mapping_para.path2=temp.conversion{2,1}.img1_path;
mapping_para.path3=temp.conversion{3,1}.img1_path;
mapping_para.path4=temp.conversion{4,1}.img1_path;
mapping_para.path5=temp.conversion{4,1}.img2_path;
savepath_ind=strfind(mapping_para.path1,'\');
mapping_para.savepath=mapping_para.path1(1:savepath_ind(end)-1);

if size(temp.conversion,1)==5
    conversion{5,1}.angle=temp.conversion{5,1}.angle;
    set(handles.done5,'Value',temp.conversion{5,1}.done);
    conversion{5,1}.done=temp.conversion{5,1}.done;
    mapping_para.half_brain_8x= temp.conversion{5,1}.img;  
    conversion{5,1}.midline=temp.conversion{5,1}.midline;
    conversion{5,1}.outer_edge=temp.conversion{5,1}.outer_edge;
    conversion{5,1}.outline=temp.conversion{5,1}.outline;
else
    if isfile(strcat(mapping_para.path5(1:end-4),' - Copy.tif'))
        half_brain_8x_map=im2uint8(imread(strcat(mapping_para.path5(1:end-4),' - Copy.tif')));%get the orginial file
        mapping_para.half_brain_8x=half_brain_8x_map;
    else
        mapping_para.half_brain_8x=im2uint8(imread(mapping_para.path5));
    end
end


% Hint: get(hObject,'Value') returns toggle state of load_all


% --- Executes on button press in done1.
function done1_Callback(hObject, eventdata, handles)
% hObject    handle to done1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
conversion{1,1}.done=get(handles.done1,'Value');


% Hint: get(hObject,'Value') returns toggle state of done1


% --- Executes on button press in done2.
function done2_Callback(hObject, eventdata, handles)
% hObject    handle to done2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
conversion{2,1}.done=get(handles.done2,'Value');
% Hint: get(hObject,'Value') returns toggle state of done2


% --- Executes on button press in done3.
function done3_Callback(hObject, eventdata, handles)
% hObject    handle to done3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
conversion{3,1}.done=get(handles.done3,'Value');
% Hint: get(hObject,'Value') returns toggle state of done3


% --- Executes on button press in done4.
function done4_Callback(hObject, eventdata, handles)
% hObject    handle to done4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
conversion{4,1}.done=get(handles.done4,'Value');
% Hint: get(hObject,'Value') returns toggle state of done4

% --- Executes on button press in done5.
function done5_Callback(hObject, eventdata, handles)
% hObject    handle to done5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
conversion{5,1}.done=get(handles.done5,'Value');
% Hint: get(hObject,'Value') returns toggle state of done5

function shift_step_Callback(hObject, eventdata, handles)
% hObject    handle to shift_step (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of shift_step as text
%        str2double(get(hObject,'String')) returns contents of shift_step as a double
global mapping_para
mapping_para.shift_step = str2double(get(handles.shift_step,'String'));



% --- Executes during object creation, after setting all properties.
function shift_step_CreateFcn(hObject, eventdata, handles)
% hObject    handle to shift_step (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white bacmapping_para.map_stepground on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function angle_step_Callback(hObject, eventdata, handles)
% hObject    handle to angle_step (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
mapping_para.angle_step= str2double(get(handles.angle_step,'String'));

% Hints: get(hObject,'String') returns contents of angle_step as text
%        str2double(get(hObject,'String')) returns contents of angle_step as a double


% --- Executes during object creation, after setting all properties.
function angle_step_CreateFcn(hObject, eventdata, handles)
% hObject    handle to angle_step (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white bacmapping_para.map_stepground on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function waitPeriodSecs_Callback(hObject, eventdata, handles)
% hObject    handle to waitPeriodSecs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
mapping_para.t= str2double(get(handles.waitPeriodSecs,'String'));

% Hints: get(hObject,'String') returns contents of waitPeriodSecs as text
%        str2double(get(hObject,'String')) returns contents of waitPeriodSecs as a double


% --- Executes during object creation, after setting all properties.
function waitPeriodSecs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to waitPeriodSecs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white bacmapping_para.map_stepground on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in zoom_in.
function zoom_in_Callback(hObject, eventdata, handles)
% hObject    handle to zoom_in (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
axes(handles.axes1)
[J,mapping_para.rect] = imcrop;
imshow(J)

% --- Executes on button press in reset.
function reset_Callback(hObject, eventdata, handles)
% hObject    handle to reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
mapping_para.rect = [];
imshow(mapping_para.img)


function zoom_Callback(hObject, eventdata, handles)
% hObject    handle to zoom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
global mapping_para

try
    zoom_temp = str2double(get(handles.zoom,'String'));
    conversion{mapping_para.map_step,1}.zoom = zoom_temp;
catch
     fprintf('warning: invalid zoom input \n')
end

if mapping_para.map_step <5
    img1_new=imrotate(mapping_para.img1,conversion{mapping_para.map_step,1}.angle,'bicubic','loose');
    Center_shift=(size(img1_new)/2)'-(size(mapping_para.img1)/2)';
    Center_shift=(Center_shift*conversion{mapping_para.map_step,1}.zoom).*conversion{mapping_para.map_step,1}.ratio;
    numrow=round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(1,1)*size(img1_new,1)); %y
    numcol = round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(2,1)*size(img1_new,2)); %x
    img1_new=imresize(img1_new, [numrow,numcol]);
    R_img1_new = imref2d(size(img1_new));
    R_img1_new.XWorldLimits=R_img1_new.XWorldLimits +conversion{mapping_para.map_step,1}.shift(2,1)-Center_shift(2,1);
    R_img1_new.YWorldLimits=R_img1_new.YWorldLimits +conversion{mapping_para.map_step,1}.shift(1,1)-Center_shift(1,1);

    [mapping_para.img,~] = imfuse(img1_new,R_img1_new,mapping_para.img2,mapping_para.R_img2,'falsecolor','Scaling','joint','ColorChannels', [1 2 0]);

    axes(handles.axes1);
    if isempty(mapping_para.rect)
        imshow(mapping_para.img);
    else
        imshow(imcrop(mapping_para.img,mapping_para.rect)) ;   
    end
end


% Hints: get(hObject,'String') returns contents of zoom as text
%        str2double(get(hObject,'String')) returns contents of zoom as a double


% --- Executes during object creation, after setting all properties.
function zoom_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zoom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white bacmapping_para.map_stepground on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function x_ratio_Callback(hObject, eventdata, handles)
% hObject    handle to x_ratio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
global mapping_para

try
    x_ratio_temp = str2double(get(handles.x_ratio,'String'));
    conversion{mapping_para.map_step,1}.ratio(2,1) =  x_ratio_temp;
catch
     fprintf('warning: x_ratio input \n')
end

if mapping_para.map_step<5
    img1_new=imrotate(mapping_para.img1,conversion{mapping_para.map_step,1}.angle,'bicubic','loose');
    Center_shift=(size(img1_new)/2)'-(size(mapping_para.img1)/2)';
    Center_shift=(Center_shift*conversion{mapping_para.map_step,1}.zoom).*conversion{mapping_para.map_step,1}.ratio;
    numrow=round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(1,1)*size(img1_new,1)); %y
    numcol = round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(2,1)*size(img1_new,2)); %x
    img1_new=imresize(img1_new, [numrow,numcol]);
    R_img1_new = imref2d(size(img1_new));
    R_img1_new.XWorldLimits=R_img1_new.XWorldLimits +conversion{mapping_para.map_step,1}.shift(2,1)-Center_shift(2,1);
    R_img1_new.YWorldLimits=R_img1_new.YWorldLimits +conversion{mapping_para.map_step,1}.shift(1,1)-Center_shift(1,1);

    [mapping_para.img,~] = imfuse(img1_new,R_img1_new,mapping_para.img2,mapping_para.R_img2,'falsecolor','Scaling','joint','ColorChannels', [1 2 0]);

    axes(handles.axes1);
    if isempty(mapping_para.rect)
        imshow(mapping_para.img);
    else
        imshow(imcrop(mapping_para.img,mapping_para.rect));   
    end
end

% Hints: get(hObject,'String') returns contents of x_ratio as text
%        str2double(get(hObject,'String')) returns contents of x_ratio as a double

% --- Executes during object creation, after setting all properties.
function x_ratio_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zoom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white bacmapping_para.map_stepground on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function y_ratio_Callback(hObject, eventdata, handles)
% hObject    handle to y_ratio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
global mapping_para

try
    y_ratio_temp = str2double(get(handles.y_ratio,'String'));
    conversion{mapping_para.map_step,1}.ratio(1,1) = y_ratio_temp;
catch
     fprintf('warning: x_ratio input \n')
end

if mapping_para.map_step <5
    img1_new=imrotate(mapping_para.img1,conversion{mapping_para.map_step,1}.angle,'bicubic','loose');
    Center_shift=(size(img1_new)/2)'-(size(mapping_para.img1)/2)';
    Center_shift=(Center_shift*conversion{mapping_para.map_step,1}.zoom).*conversion{mapping_para.map_step,1}.ratio;
    numrow=round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(1,1)*size(img1_new,1)); %y
    numcol = round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(2,1)*size(img1_new,2)); %x
    img1_new=imresize(img1_new, [numrow,numcol]);
    R_img1_new = imref2d(size(img1_new));
    R_img1_new.XWorldLimits=R_img1_new.XWorldLimits +conversion{mapping_para.map_step,1}.shift(2,1)-Center_shift(2,1);
    R_img1_new.YWorldLimits=R_img1_new.YWorldLimits +conversion{mapping_para.map_step,1}.shift(1,1)-Center_shift(1,1);

    [mapping_para.img,~] = imfuse(img1_new,R_img1_new,mapping_para.img2,mapping_para.R_img2,'falsecolor','Scaling','joint','ColorChannels', [1 2 0]);

    axes(handles.axes1)
    if isempty(mapping_para.rect)
        imshow(mapping_para.img);
    else
        imshow(imcrop(mapping_para.img,mapping_para.rect));    
    end
end

% Hints: get(hObject,'String') returns contents of y_ratio as text
%        str2double(get(hObject,'String')) returns contents of y_ratio as a double


% --- Executes during object creation, after setting all properties.
function y_ratio_CreateFcn(hObject, eventdata, handles)
% hObject    handle to y_ratio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white bacmapping_para.map_stepground on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in start_map.
function start_map_Callback(hObject, eventdata, handles)
% hObject    handle to start_map (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
global mapping_para

status = 1;
parameter_change=0; %initiate

if mapping_para.map_step<5
    while status
            pause (mapping_para.t);
            [~, keyCode, ~] = KbWait;
            try
                key=char(KbName(find(keyCode)));
            catch
                fprintf('warning: invalid key pressed \n')
            end
            switch key 
                case 'right' %right arrow
                    conversion{mapping_para.map_step,1}.shift(2,1) = conversion{mapping_para.map_step,1}.shift(2,1)+mapping_para.shift_step;%x
                    parameter_change=1;           
                case 'left' %left arrow
                    conversion{mapping_para.map_step,1}.shift(2,1) = conversion{mapping_para.map_step,1}.shift(2,1)-mapping_para.shift_step;
                    parameter_change=1;              
                case 'up'%uparrow
                   conversion{mapping_para.map_step,1}.shift(1,1) = conversion{mapping_para.map_step,1}.shift(1,1)-mapping_para.shift_step;%y
                    parameter_change=1;
                case 'down' %downarrow
                    conversion{mapping_para.map_step,1}.shift(1,1) = conversion{mapping_para.map_step,1}.shift(1,1)+mapping_para.shift_step;
                    parameter_change=1;
                case 'a' %rotate left  
                    conversion{mapping_para.map_step,1}.angle = conversion{mapping_para.map_step,1}.angle+mapping_para.angle_step;
                    parameter_change=1;
                case 'd' %rotate right
                     conversion{mapping_para.map_step,1}.angle = conversion{mapping_para.map_step,1}.angle-mapping_para.angle_step;
                     parameter_change=1;
                 case 'esc' %escape
                    status =0;               
            end     


            if parameter_change
                img1_new=imrotate(mapping_para.img1,conversion{mapping_para.map_step,1}.angle,'bicubic','loose');
                Center_shift=(size(img1_new)/2)'-(size(mapping_para.img1)/2)';
                Center_shift=(Center_shift*conversion{mapping_para.map_step,1}.zoom).*conversion{mapping_para.map_step,1}.ratio;
                numrow=round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(1,1)*size(img1_new,1)); %y
                numcol = round(conversion{mapping_para.map_step,1}.zoom*conversion{mapping_para.map_step,1}.ratio(2,1)*size(img1_new,2)); %x
                img1_new=imresize(img1_new, [numrow,numcol]);
                R_img1_new = imref2d(size(img1_new));
                R_img1_new.XWorldLimits=R_img1_new.XWorldLimits +conversion{mapping_para.map_step,1}.shift(2,1)-Center_shift(2,1);
                R_img1_new.YWorldLimits=R_img1_new.YWorldLimits +conversion{mapping_para.map_step,1}.shift(1,1)-Center_shift(1,1);

                [mapping_para.img,~] = imfuse(img1_new,R_img1_new,mapping_para.img2,mapping_para.R_img2,'falsecolor','Scaling','joint','ColorChannels', [1 2 0]);

                axes(handles.axes1);
                if isempty(mapping_para.rect)
                imshow(mapping_para.img);
                else
                imshow(imcrop(mapping_para.img,mapping_para.rect));   
                end

                parameter_change = 0;
            end
    end
end


% --- Executes on button press in midline.
function midline_Callback(hObject, eventdata, handles)
% hObject    handle to midline (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
global mapping_para
global fighandle

status=1;
figure(fighandle);
set(fighandle,'position', [1300 -200 1200 1000]);
if mapping_para.map_step==5
    while status
        pause (mapping_para.t);
        [x,y,button] = ginput(1);
        if button == 1 %left button on mouse
            mapping_para.midline=[mapping_para.midline;[x,y]];
        elseif button ==3 %right button on mouse
            mapping_para.midline=mapping_para.midline(1:(end-1),:);
        elseif button==2%middle button on mouse
            dis_temp=mapping_para.midline-[x,y];
            dis=sqrt(dis_temp(:,1).^2+dis_temp(:,2).^2);
            ind=find(dis==min(dis)); %find the closest point
            mapping_para.midline(ind,:)=[x y];
        else %any other key
            status=0;
        end
        
        imshow(mapping_para.half_brain_8x);
        hold on
        if isempty(mapping_para.outer_edge)
           plot(mapping_para.midline(:,1), mapping_para.midline(:,2),'-x','Color','g');
        else          
            plot([mapping_para.midline(1,1);mapping_para.outer_edge(:,1);mapping_para.midline(end,1)], [mapping_para.midline(1,2);mapping_para.outer_edge(:,2);mapping_para.midline(end,2)], '-x','Color','b');
            plot(mapping_para.midline(:,1), mapping_para.midline(:,2),'-x','Color','g');
        end
        hold off
    end
else
    fprintf('This step is for step5 only')
end

%%calculate the angle between midline and horizontal line using linear regression
p_linear=polyfit(mapping_para.midline(:,1),mapping_para.midline(:,2),1);
%p = polyfit(x,y,n) returns the coefficients for a polynomial p(x) of degree n 
%that is a best fit (in a least-squares sense) for the data in y. 
%The coefficients in p are in descending powers, and the length of p is n+1.
conversion{5,1}.angle=atand(p_linear(1));    
%slope of the line is the tangent value for the angle between the midline and horizontal line

mapping_para.outline=[flip(mapping_para.midline,1);mapping_para.outer_edge];%both outlining starts with left hand side
conversion{5,1}.midline=mapping_para.midline;
conversion{5,1}.outline=mapping_para.outline;


% --- Executes on button press in outer_line.
function outer_line_Callback(hObject, eventdata, handles)
% hObject    handle to outer_line (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
global mapping_para 
global fighandle

status=1;
figure(fighandle);
set(fighandle,'position', [1300 -200 1200 1000]);
if mapping_para.map_step==5
    while status
        %pause (mapping_para.t);
        [x,y,button] = ginput(1);
        if button == 1 %left button on mouse
            mapping_para.outer_edge=[mapping_para.outer_edge;[x,y]];
        elseif button ==3 %right button on mouse
            mapping_para.outer_edge=mapping_para.outer_edge(1:(end-1),:);
        elseif button==2%middle button on mouse
            dis_temp=mapping_para.outer_edge-[x,y];
            dis=sqrt(dis_temp(:,1).^2+dis_temp(:,2).^2);
            ind=find(dis==min(dis)); %find the closest point
            if length(ind)>1%if happens to be in the middle
                ind=ind(1); %always assgin to the first closet point
            end
            mapping_para.outer_edge(ind,:)=[x y];
        else %any button on keyboard
            status=0;
        end
                
        imshow(mapping_para.half_brain_8x);
        hold on;
        plot(mapping_para.outer_edge(:,1), mapping_para.outer_edge(:,2),'-x','Color','b');
        if ~isempty(mapping_para.midline)   
            plot([mapping_para.midline(1,1);mapping_para.outer_edge(:,1);mapping_para.midline(end,1)], [mapping_para.midline(1,2);mapping_para.outer_edge(:,2);mapping_para.midline(end,2)], '-x','Color','b');
            plot(mapping_para.midline(:,1), mapping_para.midline(:,2),'-x','Color','g');
        end
        hold off;
    end
else
    fprintf('This step is for step5 only');
end

mapping_para.outline=[flip(mapping_para.midline,1);mapping_para.outer_edge];%both outlining starts with left hand side
conversion{5,1}.outline=mapping_para.outline;%the saved boundaries don't have duplicated points
conversion{5,1}.outer_edge=mapping_para.outer_edge;


% --- Executes on button press in clear_all.
function clear_all_Callback(hObject, eventdata, handles)
% hObject    handle to clear_all (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mapping_para
global fighandle
figure(fighandle);
set(fighandle,'position', [1300 -200 1200 1000]);

if mapping_para.map_step==5
    mapping_para.midline=[]; 
    mapping_para.outline=[];
    mapping_para.outer_edge=[];
    axes(handles.axes1);
    imshow(mapping_para.half_brain_8x);
else
    fprintf('This step is for step5 only')
end


% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global conversion
global mapping_para

conversion{1,1}.img1_path=mapping_para.path1;
conversion{1,1}.img1=mapping_para.two_photon_40x;

conversion{1,1}.img2_path=mapping_para.path2;
conversion{2,1}.img1_path=mapping_para.path2;
conversion{1,1}.img2=mapping_para.two_photon_25x;
conversion{2,1}.img1=mapping_para.two_photon_25x;

conversion{2,1}.img2_path=mapping_para.path3;
conversion{3,1}.img1_path=mapping_para.path3;
conversion{2,1}.img2=mapping_para.cranial_window;
conversion{3,1}.img1=mapping_para.cranial_window;

conversion{3,1}.img2_path=mapping_para.path4;
conversion{4,1}.img1_path=mapping_para.path4;
conversion{3,1}.img2=mapping_para.half_brain_25x_green;
conversion{4,1}.img1=mapping_para.half_brain_25x_green;

conversion{4,1}.img2_path=mapping_para.path5;
conversion{5,1}.img_path=mapping_para.path5;
conversion{4,1}.img2=mapping_para.half_brain_8x_green;
conversion{5,1}.img=mapping_para.half_brain_8x;

cd(mapping_para.savepath)
if isfile('conversion.mat')
    delete('conversion.mat')
end
save ('conversion.mat', 'conversion') 


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fighandle
try  delete(fighandle); 
end
% Hint: delete(hObject) closes the figure
delete(hObject);

function surface_area(brain_layer)
%% input
%%brain_layer
%   5: use allenmap_layer5 as the standard area map
%   1: use allenmap_layer5 as the standard area map
if nargin<1
    brain_layer=5;
end

%% set parameters
%%cortex outline (left) image folder
if brain_layer==5
    outline_folder='E:\two-photon imaging\jiashu\data\retro_tracing\layer4_5';
    PL_folder='E:\two-photon imaging\jiashu\data\retro_tracing\PL';
end

%allenmap folder
allenmap_folder='E:\two-photon imaging\jiashu\data\blood vessel match\allen map';
%load in boundary map
if brain_layer==5
    load([allenmap_folder '\allenmap_layer5.mat']); %this should be the same unless you change the boudary image
else
    load([allenmap_folder '\allenmap_layer1.mat']); 
end
%first collum: area name
%second collum: boundary coordinates

%%grid_size: the length side length of each square grid under standard allen_map
ML_step=50; 
AP_step=100; %the allenmap slices are 100um thick

%% grab layer 5 outline image and excel
cd(outline_folder)
%obtain outline image matrix 
imgfiles = dir('*.jpg'); 
imglist=string({imgfiles(~[imgfiles.isdir]).name})';%the names for all jpg files

outline_struct=struct;
for i = 1:length(imglist)
    imgname=imglist{i};
    start_ind = strfind(imgname,'-')+1; %slice number start after the only '-' in the name
    end_ind = strfind(imgname,'.jpg')-1; %slice number end right before '.jpg'
    slice_temp=imgname(start_ind:end_ind);
    outline_struct.(['atlas' slice_temp])=imread(imglist{i});
end

midline_position=xlsread([outline_folder '\midline position.xlsx']);
%1st column: slice number
%2nd column: midline pixel
%3rd column: inner edge pixel (left)
%4th column: outer edge pixel (left)

%% calculate surface area
actual_area=cell(size(boundaries));
actual_area(:,1)=boundaries(:,1);
outline_length_per_slice=actual_area; 
actual_area(:,2)={0};
for i = 1: size(boundaries,1)
       boundary=boundaries{i,2};
       boundary_AP=unique(boundary(1,:));
       slice_num=[];
       slice_AP=[];
       %obtian the slice number from boundary 
       %      ----- some points are added to make the topview look better
       %      ----- the slice outline is assumed to be in the middle of the 100um
       %      slice (thus end with 50), and the length of each visual area 
       %      on each slice is used to calculate the approximal topview surface
       %      of the 100um slice. 
       %      ----- thus the points added 0-50um before/ after the
       %      first/last slice to improve display should be removed when
       %      calculting the surface area
       for j=1: length(boundary_AP)
           slice_temp=num2str(boundary_AP(j));
           if endsWith(slice_temp,'50')
               slice_AP=[slice_AP boundary_AP(j)];
               slice_num=[slice_num ((boundary_AP(j)-50)/100+19)];
           end
       end

        slice_length=zeros(length(slice_num),2);
        slice_length(:,1)=slice_num'; %2nd column will be corresponding length of outline for each slice
        
       %extract the tract length and calculate topview area on each slice 
       for j=1:length(slice_num)        
           %obtain slice image
            outline_img=outline_struct.(['atlas' num2str(slice_num(j))]);
            midline_pix=midline_position(midline_position(:,1)==slice_num(j),2);
            outline_img=outline_img(:,1:midline_pix);%get corresponding ouline the left hemisphere of the brain
            outline_img=flip(outline_img,2); %set midline to 0 pixel ----- midline is also 0 on the top-down view
            outline_ind=[];
            %first column is the outline row index, second column is the outline column index
            [outline_ind(:,1),outline_ind(:,2)]=find(outline_img<10); 
            
            %obtain ML medial-lateral start and end position
            boundary_ML=boundary(2,boundary(1,:)==slice_AP(j));
            ML_num=ceil((max(boundary_ML)-min(boundary_ML))/ML_step);%midline is set to 0
            
             %%when estimating legnth ---- linear regression (slope) & grid_size (cos) 
             for n = 1: ML_num
                 if n<ML_num
                    %%in coronal view, row is the depth and column is the medial-lateral position 
                    %the brain outline is continuous, however the mannual drawing may
                    %leave gaps between two pixel points on an outline
                    ML_medial=min(boundary_ML)+(n-1)*ML_step; 
                     [~, ML_medial_ind]=min(abs(outline_ind(:,2)-ML_medial)); %row ind  of outline ind           
                    ML_lateral=ML_medial+ML_step;
                    [~, ML_lateral_ind]=min(abs(outline_ind(:,2)-ML_lateral)); 

                    %use regression line between ML_medial and ML_lateral to calculate slope
                    [~,slope,~] = regression(outline_ind(ML_medial_ind:ML_lateral_ind,2)',outline_ind(ML_medial_ind:ML_lateral_ind,1)');
                    actual_area{i,2}=actual_area{i,2}+ML_step/cos(atan(slope))*AP_step; %%aggregate throughout the same visual area, thus i
                    slice_length(j,2)=slice_length(j,2)+ML_step/cos(atan(slope)); %%only aggregate per slice, thus j
                                        
                    %%assume the actual surface area to be rectangular 
                    %ML_step/cos(atan(slope)): for the actual medial - lateral length along the layer 5 cortex
                    %AP_step for anterior - posterior length 
                    %%assume the acutal surface length is a straight line in each grid,
                    %and is the hypotenuse of the right triangle formed by the lateral width of each grid (on the brain top-down view), and the depth
                    %difference of grid (the difference of depths of the two lateral edge of each grid in coronal slice view)
                 else
                    ML_medial=min(boundary_ML)+(n-1)*ML_step; 
                     [~, ML_medial_ind]=min(abs(outline_ind(:,2)-ML_medial)); %row ind  of outline ind           
                    ML_lateral=max(boundary_ML);
                    [~, ML_lateral_ind]=min(abs(outline_ind(:,2)-ML_lateral)); 
                    [~,slope,~] = regression(outline_ind(ML_medial_ind:ML_lateral_ind,2)',outline_ind(ML_medial_ind:ML_lateral_ind,1)');
                    actual_area{i,2}=actual_area{i,2}+(ML_lateral-ML_medial)/cos(atan(slope))*AP_step; %%aggregate throughout the same visual area, thus i
                    slice_length(j,2)=slice_length(j,2)+(ML_lateral-ML_medial)/cos(atan(slope)); %%only aggregate per slice, thus j
                 end
             end

       end
       outline_length_per_slice{i,2}=slice_length;
end
%% modify VISpl surface area,since its shape is quite different from the others
cd(PL_folder)
%obtain outline image matrix 
imgfiles_PL = dir('*.jpg'); 
imglist_PL=string({imgfiles_PL(~[imgfiles_PL.isdir]).name})';%the names for all .jpg files

PL_struct=struct;
PL_slice_num=[];
PL_slice_AP=[];
for i = 1:length(imglist_PL)
    imgname_PL=imglist_PL{i};
    start_ind = strfind(imgname_PL,'-')+1; %slice number start after the only '-' in the name
    end_ind = strfind(imgname_PL,'-PL')-1; %slice number end right before '-PL.jpg'
    slice_temp=imgname_PL(start_ind(1):end_ind); %character variable
    PL_struct.(['atlas' slice_temp])=imread(imglist_PL{i});
    PL_slice_num=[PL_slice_num str2num(slice_temp)];%obtain brain slice number for PL
    PL_slice_AP=[PL_slice_AP (str2num(slice_temp)-19)*100+50];%calculate brain slice AP coordinates
end

%calculate surface area
PL_outline_length_per_slice=zeros(length(PL_slice_num),2);
PL_outline_length_per_slice(:,1)=PL_slice_num';%2nd column is the outline length per slice
PL_actual_area=0;
%extract the tract length and calculate topview area on each slice 
for j=1:length(PL_slice_num)        
   %obtain slice image
    PL_img=PL_struct.(['atlas' num2str(PL_slice_num(j))]);
    midline_pix=midline_position(midline_position(:,1)==PL_slice_num(j),2);
    PL_img=PL_img(:,1:midline_pix);%get corresponding ouline the left hemisphere of the brain
    PL_img=flip(PL_img,2); %set midline to 0 pixel ----- midline is also 0 on the top-down view
    PL_outline_ind=[];
    %first column is the VISpl outline row index , second column is the VISpl outline column index (represent medial-lateral position)
    [PL_outline_ind(:,1),PL_outline_ind(:,2)]=find(PL_img<10); 

    %obtain ML medial-lateral start and end position for VISpl from image
    PL_boundary_ML= [min(PL_outline_ind(:,2)) max(PL_outline_ind(:,2))]; 
    PL_ML_num=ceil((max(PL_boundary_ML)-min(PL_boundary_ML))/ML_step);%midline is set to 0

     %%when estimating legnth ---- linear regression (slope) & grid_size (cos) 
    for n = 1: PL_ML_num
         if n<PL_ML_num
            %%in coronal view, row is the depth and column is the medial-lateral position 
            %the brain outline is continuous, however the mannual drawing may
            %leave gaps between two pixel points on an outline
            PL_ML_medial=min(PL_boundary_ML)+(n-1)*ML_step; 
             [~, PL_ML_medial_ind]=min(abs(PL_outline_ind(:,2)-PL_ML_medial)); %row ind  of outline ind           
            PL_ML_lateral=PL_ML_medial+ML_step;
            [~, PL_ML_lateral_ind]=min(abs(PL_outline_ind(:,2)-PL_ML_lateral)); 

            %use regression line between ML_medial and ML_lateral to calculate slope
            [~,slope,~] = regression(PL_outline_ind(PL_ML_medial_ind:PL_ML_lateral_ind,2)',PL_outline_ind(PL_ML_medial_ind:PL_ML_lateral_ind,1)');
            PL_actual_area=PL_actual_area+ML_step/cos(atan(slope))*AP_step;
            PL_outline_length_per_slice(j,2)= PL_outline_length_per_slice(j,2)+ML_step/cos(atan(slope));
            %%assume the actual surface area to be rectangular 
            %ML_step/cos(atan(slope)): for the actual medial - lateral length along the layer 5 cortex
            %AP_step for anterior - posterior length 
            %%assume the acutal surface length is a straight line in each grid,
            %and is the hypotenuse of the right triangle formed by the lateral width of each grid (on the brain top-down view), and the depth
            %difference of grid (the difference of depths of the two lateral edge of each grid in coronal slice view)
         else
            PL_ML_medial=min(PL_boundary_ML)+(n-1)*ML_step; 
             [~, PL_ML_medial_ind]=min(abs(PL_outline_ind(:,2)-PL_ML_medial)); %row ind  of outline ind           
            PL_ML_lateral=max(PL_boundary_ML);
            [~, PL_ML_lateral_ind]=min(abs(PL_outline_ind(:,2)-PL_ML_lateral)); 
            [~,slope,~] = regression(PL_outline_ind(PL_ML_medial_ind:PL_ML_lateral_ind,2)',PL_outline_ind(PL_ML_medial_ind:PL_ML_lateral_ind,1)');
            PL_actual_area=PL_actual_area+(PL_ML_lateral-PL_ML_medial)/cos(atan(slope))*AP_step;
            PL_outline_length_per_slice(j,2)= PL_outline_length_per_slice(j,2)+(PL_ML_lateral-PL_ML_medial)/cos(atan(slope));
         end
    end
end

%updated actual_area and length_per_slice, and save PL transformation
%matrix for further use
PL_ind=find(~cellfun(@isempty,strfind(boundaries(:,1),'VISpl')));%get VISpl boundary coordinate 
PL_trans_mat=struct;
PL_trans_mat.layer45boundary_lengths=outline_length_per_slice{PL_ind,2};
PL_trans_mat.layer45boundary_surfacearea=actual_area{PL_ind,2};
PL_trans_mat.actual_layer5boundary_lengths=PL_outline_length_per_slice;
PL_trans_mat.actual_layer5boundary_surfacearea=PL_actual_area;
PL_trans_mat.slice_AP=[PL_slice_num' PL_slice_AP'];

actual_area{PL_ind,2}=PL_actual_area;
outline_length_per_slice{PL_ind,2}=PL_outline_length_per_slice;

%% save
cd(allenmap_folder)
if brain_layer==5
    save('allenmap_layer5.mat', 'allenmap','table_map','boundaries','actual_area','outline_length_per_slice','PL_trans_mat')
else
    save('allenmap_layer1.mat', 'allenmap','table_map','boundaries','actual_area','outline_length_per_slice','PL_trans_mat')
end
end
function allenmap_topview(brain_layer)
%% set para
if nargin <1
    brain_layer=5;%the map of which brain layer
end
allenmap_folder='E:\two-photon imaging\jiashu\data\blood vessel match\allen map';
%% convert pixel value to distance to midline
if brain_layer ==1
    allenmap=xlsread('allenmap_layer1.xlsx','pixel value');
    table_map=table2cell(readtable('allenmap_layer1.xlsx'));
elseif brain_layer ==5
    allenmap=xlsread('allenmap_layer5.xlsx','pixel value');
    table_map=table2cell(readtable('allenmap_layer5.xlsx'));
end

visual_area={'VISal' 'VISrl'  'VISpor' 'VISpl' 'VISli'  'VISI'   'VISp'  'VISa'   'VISpm'  'VISam'};
arealist=table_map(4:2:end,1);%readtable won't read the first row in excel for some reason

allenmap(2:end,:) = allenmap(2,:) - allenmap(2:end,:);
%first row: slices
%second row: midline pixel value
%third row: left edge pixel value
%fourth row: inner edge pixel
%rest: start and end pixl value for each area

%% extract boundaries
tot_area=size(arealist,1);
boundaries=cell(tot_area,2);
for i = 1: tot_area
    visual_flag=cell2mat(strfind(visual_area,arealist{i}));
    if visual_flag
        boundaries{i,1}=arealist{i};
        area_temp=allenmap((2*i+3):(2*i+4),:);%area boundaries start from line 5 on allenmap excel
        ind_temp=find(isnan(area_temp(1,:))==0);
        ind_s=ind_temp(1);
        ind_e=ind_temp(end);
        area=[[(allenmap(1,ind_s:ind_e));area_temp(1,ind_s:ind_e)],[fliplr(allenmap(1,ind_s:ind_e)); fliplr(area_temp(2,ind_s:ind_e))]];
        %anterior_posterior zero is set to the start of cortex (50um before the first slice), which is the 19th slice
        %the first slice of cortex at 50um
        area(1,:)=(area(1,:)-19)*100+50;%x
        boundaries{i,2}=[area(1,:);area(2,:)];%x,y 
    end
end

%% mannually modified boundaries
%remove all empty rows in boundaries
remove_ind=[];
for i = 1: size(boundaries,1)
    if isempty(boundaries{i,2})
        remove_ind=[remove_ind i];
    end
end
boundaries(remove_ind,:)=[];        

if brain_layer==5
    %VISal
    boundaries{1,2}=[boundaries{1,2}(:,1:8) [6700;3276] boundaries{1,2}(:,9:end)];
    boundaries{1,2}=[boundaries{1,2}(:,1:10) [6591.5;3236.4] boundaries{1,2}(:,11:end)];
    boundaries{1,2}=[boundaries{1,2} [6088.20000000000,6100;3581,3650]];

    %VISrl
    boundaries{2,2}(2,20:end)=[2557.1 2570.9 2584.7 2598.6 2612.4];
    boundaries{2,2}=[boundaries{2,2}(:,1:12) [6591.5;3236.4] boundaries{2,2}(:,13:end)];
    boundaries{2,2}=[boundaries{2,2}(:,1:20) [5931.6;2551.7] boundaries{2,2}(:,21:end)];
    boundaries{2,2}=[boundaries{2,2}(:,1:7) [6088.20000000000;3581] boundaries{2,2}(:,8:end)];
    boundaries{2,2}=[boundaries{2,2} [5395.40000000000;2620]];

    %VISpor
    boundaries{3,2}(2,17)=3950;
    boundaries{3,2}(2,5)=4333.2;
    boundaries{3,2}(2,6)= 4242.5;
    boundaries{3,2}=[boundaries{3,2}(:,1:13) [7784.8;3642.4] boundaries{3,2}(:,14:end)];
    boundaries{3,2}=[boundaries{3,2}(:,1:9) [8193.60000000000;3723.10000000000] boundaries{3,2}(:,10:end)];
    boundaries{3,2}=[boundaries{3,2}(:,1:3) [7600;4450] boundaries{3,2}(:,4:end)];
    boundaries{3,2}=[boundaries{3,2} [7330;4030]];

    %VISpl
    boundaries{4,2}=[boundaries{4,2} [7784.8;3642.4]];
    boundaries{4,2}(:,6)=[8300;2.9770e+03];
    boundaries{4,2}=[boundaries{4,2}(:,1:4) [8193.60000000000;3723.10000000000] boundaries{4,2}(:,5:end)];
    

    %VISli
    boundaries{5,2}(2,5)=3965;
    boundaries{5,2}(2,7)=3950;
    boundaries{5,2}=[boundaries{5,2}(:,1:9) [7750;3690.95] boundaries{5,2}(:,10:end)];
    boundaries{5,2}=[[6750;3931] boundaries{5,2} [6750;3777.2]];

    %VISI
    boundaries{6,2}=[boundaries{6,2}(:,1:13) [8050;3290.03] boundaries{6,2}(:,14:end) [6700;3276]];
    boundaries{6,2}=[boundaries{6,2}(:,1) [6750;3777.2] boundaries{6,2}(:,2:end)];

    %VISp
    boundaries{7,2}(2,30)=1520;
    boundaries{7,2}(2,31)=1480;
    boundaries{7,2}(2,43)=1995;
    boundaries{7,2}=[boundaries{7,2} [5931.6;2551.7]];
    boundaries{7,2}(:,24)=[8300;2.9770e+03];

    %VISa
    boundaries{8,2}(2,5:9)=[2612.4 2598.6 2584.7 2570.9 2557.1];
    boundaries{8,2}=[boundaries{8,2}(:,1:9) [5931.6;2551.7] boundaries{8,2}(:,10:end)];
    boundaries{8,2}=[boundaries{8,2}(:,1:11) [6028.8;2279.7] boundaries{8,2}(:,12:end)];
    boundaries{8,2}=[boundaries{8,2}(:,1:4) [5395.40000000000;2620] boundaries{8,2}(:,5:end)];

    %VISpm
    boundaries{9,2}(2,5)=1995;
    boundaries{9,2}=[boundaries{9,2}(:,1:29) [6319.1;1370] boundaries{9,2}(:,30:end)];
    boundaries{9,2}=[boundaries{9,2} [6028.8;2279.7]];
    boundaries{9,2}(:,17)=[];
    boundaries{9,2}(2,17:18)=[1419.60000000000,1413.50000000000];


    %VISam
    boundaries{10,2}=[boundaries{10,2} [5350;1309.89]];
    boundaries{10,2}=[boundaries{10,2}(:,1:9) [6319.1;1370] boundaries{10,2}(:,10:end)];
    boundaries{10,2}=[boundaries{10,2}(:,1:6) [6028.8;2279.7] boundaries{10,2}(:,7:end)];
    boundaries{10,2}(2,20)=1315;
    
else %for layer 1
     %VISal
     boundaries{1,2}=[boundaries{1,2}(:,1:9) [6850;4100] boundaries{1,2}(:,10:end)];
     boundaries{1,2}=[boundaries{1,2}(:,1:7) [6850;4280] boundaries{1,2}(:,8:end)];
     boundaries{1,2}=[boundaries{1,2}(:,1:12) [6.7364e+03;3.5556e+03] boundaries{1,2}(:,13:end)];
     boundaries{1,2}=[boundaries{1,2}(:,1:14) [6.6368e+03;3.5129e+03] boundaries{1,2}(:,15:end)];
     boundaries{1,2}=[boundaries{1,2} [6068.10000000000,6065,6090,6100,6120;3899.90000000000,3950,4050,4080,4100]];
 
     %VISrl
     boundaries{2,2}=[boundaries{2,2}(:,1:13) [6.6368e+03;3.5129e+03] boundaries{2,2}(:,14:end)];
     boundaries{2,2}=[boundaries{2,2} [5.3222e+03;2.8222e+03]];
     boundaries{2,2}=[boundaries{2,2}(:,1:21) [5.8907e+03;2.7395e+03] boundaries{2,2}(:,22:end)];
     boundaries{2,2}=[boundaries{2,2}(:,1:8) [6068.10000000000;3899.90000000000] boundaries{2,2}(:,9:end)];

 
     %VISpor
     boundaries{3,2}=[boundaries{3,2}(:,1:16) [8000;3950] boundaries{3,2}(:,17:end)];
     boundaries{3,2}=[boundaries{3,2}(:,1:11) [8532.20000000000;3892.70000000000] boundaries{3,2}(:,12:end)];

     %VISpl
     boundaries{4,2}=[boundaries{4,2} [8000;3950]];
     boundaries{4,2}=[boundaries{4,2}(:,1:6) [8.5871e+03;3.0456e+03] boundaries{4,2}(:,7:end)];
     boundaries{4,2}=[boundaries{4,2}(:,1:5) [8532.20000000000;3892.70000000000] boundaries{4,2}(:,6:end)];
 
     %VISli
     boundaries{5,2}=[boundaries{5,2}(:,1:11) [7950;4020] boundaries{5,2}(:,12:end)];
 
     %VISI
     boundaries{6,2}=[boundaries{6,2} [6.7364e+03;3.5556e+03]];

     %VISp
     boundaries{7,2}=[boundaries{7,2} [5.8907e+03;2.7395e+03]];
     boundaries{7,2}=[boundaries{7,2}(:,1:27) [8587.10000000000,8585;3045.60000000000,3000] boundaries{7,2}(:,28:end)];
 
     %VISa
     boundaries{8,2}=[boundaries{8,2}(:,1:18) [5.2776e+03;1.3528e+03] boundaries{8,2}(:,19:end)];
     boundaries{8,2}=[boundaries{8,2}(:,1:10) [5.8907e+03;2.7395e+03] boundaries{8,2}(:,11:end)];
 
     %VISpm
     boundaries{9,2}=[boundaries{9,2}(:,1:18) [7850;1321] boundaries{9,2}(:,19:end)];
     boundaries{9,2}=[boundaries{9,2} [5950;2480]];
     boundaries{9,2}(2,29)=1.395200000000000e+03;
 
     %VISam
     boundaries{10,2}=[boundaries{10,2}(:,1:10) [6350;1440] boundaries{10,2}(:,11:end)];
     boundaries{10,2}=[boundaries{10,2} [5.2776e+03;1.3528e+03]];
     boundaries{10,2}=[boundaries{10,2}(:,1:7) [5950;2480] boundaries{10,2}(:,8:end)];
end

%% plot all areas
num_area=size(boundaries,1);
shape=cell(num_area,1);
figure
hold on
for i = 1: num_area
    shape{i} = polyshape(boundaries{i,2}(1,:)',boundaries{i,2}(2,:)');%x,y
    plot(shape{i})
end

%% save
cd(allenmap_folder)
if brain_layer==5
    save('allenmap_layer5.mat', 'allenmap','table_map','boundaries')
else
    save('allenmap_layer1.mat', 'allenmap','table_map','boundaries')
end
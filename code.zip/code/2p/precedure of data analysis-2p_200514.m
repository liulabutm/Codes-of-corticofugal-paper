%type sitename in file: 'E:\two-photon imaging\jiashu\data\site recording\recording.xlsx'
%type runsequence in file: 'E:\two-photon imaging\jiashu\data\matlab sortdata\RunFolderSeq.xlsx'
premoviepress(2, 0, 30, 5, 1, 1);   (premoviepress_comb_new)
suite2p, select cell    %note: data folder select: suite2p analyze based on the sequence of the selection of the folders, not the name of the folder
calFoutput=calFfromROI;  (calFfromROI_comb;)
automatic_data_analysis2P; (automatic_data_analysis2P_comb)  
rmout; %remove outlier
automatic_OS_tuning_plot;
'automatic_DS and OS distribution and cell selection_ave_peak' 

%vector sum
automatic_vector_sum_prefDir_prefOri_OSI_DSI;
plot_tuning_check_pref_calculation  %check tuning and decide which ROI is removed or use direction vector sum method to calculate prefdir
'Recalculate_DSI'  %manually assign the prefdir of the ROI that should use vector sum method to calculate, and remove the ROI 
DSI_threshold_test_basedori_vec_mix  % plot distribution
Extract_result % extract prefdir_mix, DSI, OSI, gDSI,gOSI.... of all responsive cells
Dir_distribution_of_individual_visual_areas
OSI_threshold_test;

%find neurons' location
% Prepare figures:
%    1) Draw blood vessel with Photoshop, create 512 x 512 pixel and save
%    as 8 bit gray.
%    2) adjust brightness of the cranial window (and maybe the half brain)
%    3) keep half brain -8x and -25x in RGB mode
mapping;
locate_neuron;
%summary;


Dir_distribution_of_individual_visual_areas  % use vector sum as prefdir
Dir_distribution_of_individual_visual_areas_coarse %use peak value as prefdir


% 2p plasticity
plasticity_bef_aft_amp_DSI

%plot direction distribution of individual visual areas

global calpath prefervectorpath preferpath
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
%plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
saveflag=1;
%outlier=1;
%ignorecell=1;
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq_DKRR.xlsx']));
runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\calFoutput.mat']);
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=size(sortdata.AVEpercFlu_amp,2);
    repnum=sortdata.repnum;
    
    

    %load in prefer orientation for plotting distribution
    if f==1
        prefdir_mix_load=[];
        ROIlocation={};
        ROIselect_load=[];
        removeflag_prefdir_load=[];
        DSI_load=[];
        gOSI_load=[];
        prefdir_vec_loadseq={sitename,1,ROInum,recordnum};
    else
    %load all the pref directions in an array
        load([prefervectorpath 'Direction\prefdir_mix_load.mat']);
        load([prefervectorpath 'Direction\prefdir_vec_loadseq.mat']);
        load([prefervectorpath 'Direction\ROIselect_load.mat']);
        load([prefervectorpath 'Direction\removeflag_prefdir_load.mat']);
        load([prefervectorpath 'Direction\DSI_load.mat']);
        load([prefervectorpath 'Direction\gOSI_load.mat']);
        load([prefervectorpath 'Direction\ROIlocation.mat']);
        ROIstart=prefdir_vec_loadseq{end,3}+1;
        ROIend=ROIstart+ROInum-1;
        prefdir_vec_loadseq(end+1,:)={sitename,ROIstart,ROIend,recordnum};
    end
    endnum=size(prefdir_mix_load,1);
    prefdir_mix_load(endnum+1:(endnum+ROInum),1)=sortdata.prefdir_mix;
%     DSI_load(endnum+1:(endnum+ROInum),1)=sortdata.DSI_new;
    DSI_load(endnum+1:(endnum+ROInum),1)=sortdata.DSI_new_abs;
    gOSI_load(endnum+1:(endnum+ROInum),1)=sortdata.globalOSI;
    ROIselect_load(endnum+1:(endnum+ROInum),1)=sortdata.selectROI_outlier;
    removeflag_prefdir_load(endnum+1:(endnum+ROInum),1)=sortdata.removeflag_prefdir;
    if isfield(sortdata,'neuron_location')
        ROIlocation(endnum+1:(endnum+ROInum))=sortdata.neuron_location;
    else
        ROIlocation(endnum+1:(endnum+ROInum))={'VIS'};
    end
    
    
    save([prefervectorpath 'Direction\prefdir_mix_load.mat'],'prefdir_mix_load');
    save([prefervectorpath 'Direction\prefdir_vec_loadseq.mat'],'prefdir_vec_loadseq');   
    save([prefervectorpath 'Direction\ROIselect_load.mat'],'ROIselect_load'); 
    save([prefervectorpath 'Direction\removeflag_prefdir_load.mat'],'removeflag_prefdir_load');  
    save([prefervectorpath 'Direction\DSI_load.mat'],'DSI_load');
    save([prefervectorpath 'Direction\gOSI_load.mat'],'gOSI_load'); 
    save([prefervectorpath 'Direction\ROIlocation.mat'],'ROIlocation');




    clearvars -except ampMethod baselinemethod saveflag calpath prefervectorpath preferpath RunFolderSeq RLBflag responsiveflag runind ;
    close all
end





load([prefervectorpath 'Direction\prefdir_mix_load.mat']);
load([prefervectorpath 'Direction\prefdir_vec_loadseq.mat']);
load([prefervectorpath 'Direction\ROIselect_load.mat']);
load([prefervectorpath 'Direction\removeflag_prefdir_load.mat']);
load([prefervectorpath 'Direction\DSI_load.mat']);
load([prefervectorpath 'Direction\gOSI_load.mat']);
load([prefervectorpath 'Direction\ROIlocation.mat']);

%%
global calpath prefervectorpath preferpath
globalpara;

plotmode= 'summary';  %'individual'  or 'ventral'  or 'all'  or 'summary'
DSIthre=0.1;
gOSIthre=0.1;

visual_areas_flag=table2cell(readtable([calpath 'visual_areas_flag.xlsx']));
ROInum=size(prefdir_mix_load,1);


binNumber_dir=8;
binInterval_dir=360/binNumber_dir;
%binResult_dir=zeros(ROInum,recordnum);
binDir=zeros(1,binNumber_dir);
for i=1:binNumber_dir
    binDir(i)=(i-1)*binInterval_dir;    
end
binhistcata_dir=[binDir-binInterval_dir/2 (binDir(end)-binInterval_dir/2+binInterval_dir)];
for i=1:ROInum        
    if ROIselect_load(i,1)==0 || removeflag_prefdir_load(i,1)==1 || (DSI_load(i,1) < DSIthre) || (gOSI_load(i,1) < gOSIthre)
        prefdir_mix_load(i,1)=-100;  %take the unselective cells out of range of category
    end
    if prefdir_mix_load(i,1)>=binhistcata_dir(end)
            prefdir_mix_load(i,1)= prefdir_mix_load(i,1)-360;
    end
end

visual_areas_flag_str=visual_areas_flag;
for i=1:10
    visual_areas_flag_str{i}=convertCharsToStrings(visual_areas_flag{i});
end
ROIlocation_str=ROIlocation;
for i=1:size(prefdir_mix_load,1)
    ROIlocation_str{i}=convertCharsToStrings(ROIlocation{i}); 
    if isempty(ROIlocation{i})
        ROIlocation_str{i}="outside";
    end
end
areaind=zeros(size(prefdir_mix_load,1),1);
for k=1:size(visual_areas_flag_str,1)  % ten visual areas
    for i=1:size(prefdir_mix_load,1)
        if ROIlocation_str{i}==visual_areas_flag_str{k,1}
            areaind(i,1)=k;
        end
    end
end

switch plotmode
    case 'individual'
        figure; hold on;
        for k=1:size(visual_areas_flag_str,1)
            temp=prefdir_mix_load(areaind(:,1)==k);
            prefdir_mix=temp(temp~=-100);

            subplot(3,4,k);
            histogram(prefdir_mix,binhistcata_dir,'Normalization','probability');
            title([visual_areas_flag_str{k}] );
            xticks(binDir)
            xticklabels({'0','45','90','135','180','225','270','315'})
        end
    case 'ventral'
        runind=strfind((cell2mat(visual_areas_flag(:,3)))',1);  %find which area is included           
      
        endnum=0;
        prefdir=[];
        for k=1:size(runind,2)
            
            temp=prefdir_mix_load(areaind(:,1)==runind(k));
            
            tempnum=size(temp,1);
            prefdir(endnum+1:endnum+tempnum,1)=temp;
            endnum=size(prefdir,1);
        end
        figure; 
        prefdir_mix=prefdir(prefdir~=-100);
        histogram(prefdir_mix,binhistcata_dir,'Normalization','probability');
        xticks(binDir)
        xticklabels({'0','45','90','135','180','225','270','315'})
        title('ventral stream');
    
    case 'dorsal'
        runind=strfind((cell2mat(visual_areas_flag(:,3)))',2);  %find which area is included           
      
        endnum=0;
        prefdir=[];
        for k=1:size(runind,2)
            
            temp=prefdir_mix_load(areaind(:,1)==runind(k));
            tempnum=size(temp,1);
            prefdir(endnum+1:endnum+tempnum,1)=temp;
            endnum=size(prefdir,1);
        end
        figure;
        prefdir_mix=prefdir(prefdir~=-100);

        histogram(prefdir_mix,binhistcata_dir,'Normalization','probability');
        xticks(binDir)
        xticklabels({'0','45','90','135','180','225','270','315'})
        title('dorsal stream');
        
    case 'all'
        figure; 
        prefdir_mix=prefdir_mix_load(prefdir_mix_load~=-100);

        histogram(prefdir_mix,binhistcata_dir,'Normalization','probability');
        xticks(binDir)
        xticklabels({'0','45','90','135','180','225','270','315'})
        title('all areas');
        
    case 'summary'
        figure; hold on;
        for k=1:(size(visual_areas_flag_str,1)+3)  % all individual areas plus ventral, dorsal, and all
            if k<=size(visual_areas_flag_str,1)   % individual areas
                temp=prefdir_mix_load(areaind(:,1)==k);
                prefdir_mix=temp(temp~=-100);
                subplot(3,5,k);
                histogram(prefdir_mix,binhistcata_dir,'Normalization','probability');
                ytix = get(gca, 'YTick'); % setting y in %
                set(gca, 'YTick',ytix, 'YTickLabel',ytix*100);% setting y in %
                title([visual_areas_flag_str{k}] );
                xticks(binDir)
                xticklabels({'0','45','90','135','180','225','270','315'})
                prefdir_projecting.prefdir_mix_indv_areas(1:size(prefdir_mix,1),k)=prefdir_mix;
            elseif k==size(visual_areas_flag_str,1)+1  % ventral stream
                runind=strfind((cell2mat(visual_areas_flag(:,3)))',1);  %find which area is included        
                endnum=0;
                prefdir=[];
                for m=1:size(runind,2)
                    temp=prefdir_mix_load(areaind(:,1)==runind(m));
                    tempnum=size(temp,1);
                    prefdir(endnum+1:endnum+tempnum,1)=temp;
                    endnum=size(prefdir,1);
                end
                subplot(3,5,k); 
                prefdir_mix=prefdir(prefdir~=-100);
                histogram(prefdir_mix,binhistcata_dir,'Normalization','probability');
                ytix = get(gca, 'YTick'); % setting y in %
                set(gca, 'YTick',ytix, 'YTickLabel',ytix*100);% setting y in %
                xticks(binDir)
                xticklabels({'0','45','90','135','180','225','270','315'})
                title('ventral stream');
                prefdir_projecting.prefdir_mix_ventral(1:size(prefdir_mix,1),1)=prefdir_mix;

            elseif k==size(visual_areas_flag_str,1)+2  % dorsal stream
                runind=strfind((cell2mat(visual_areas_flag(:,3)))',2);  %find which area is included           
                endnum=0;
                prefdir=[];
                for m=1:size(runind,2)

                    temp=prefdir_mix_load(areaind(:,1)==runind(m));
                    tempnum=size(temp,1);
                    prefdir(endnum+1:endnum+tempnum,1)=temp;
                    endnum=size(prefdir,1);
                end
                subplot(3,5,k);
                prefdir_mix=prefdir(prefdir~=-100);
                histogram(prefdir_mix,binhistcata_dir,'Normalization','probability');
                ytix = get(gca, 'YTick'); % setting y in %
                set(gca, 'YTick',ytix, 'YTickLabel',ytix*100);% setting y in %
                xticks(binDir)
                xticklabels({'0','45','90','135','180','225','270','315'})
                title('dorsal stream');
                prefdir_projecting.prefdir_mix_dorsal(1:size(prefdir_mix,1),1)=prefdir_mix;

            elseif k==size(visual_areas_flag_str,1)+3   % all
                subplot(3,5,k);
                prefdir_mix=prefdir_mix_load(prefdir_mix_load~=-100);
                histogram(prefdir_mix,binhistcata_dir,'Normalization','probability');
                ytix = get(gca, 'YTick'); % setting y in %
                set(gca, 'YTick',ytix, 'YTickLabel',ytix*100);% setting y in %
                xticks(binDir)
                xticklabels({'0','45','90','135','180','225','270','315'})
                title('all areas');
                prefdir_projecting.prefdir_mix_load(1:size(prefdir_mix,1),1)=prefdir_mix;

            end
        end
end






%%
DSI_sele=DSI_load(DSI_load)










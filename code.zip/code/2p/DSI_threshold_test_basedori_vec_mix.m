%%
clear all
global calpath prefervectorpath preferpath
globalpara;


selectmode='any';    %'all' or 'any'   %'all' means all recordings are selected; 'any' means as long as one of the recording is selected, it will be ploted
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         %good=1, bad=0, control=2
thre_test_level=1;  % how many thresholds need to test 
for i=1:thre_test_level
    DSI_thre_formula(i)=0.1+(i-1)*0.05;
end


ampMethod= 'peak';   %'peak' or 'integration'
%plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
saveflag=1;
%outlier=1;
%ignorecell=1;
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));
RemoveROI=table2cell(readtable([calpath 'ROI_change_prefdir.xlsx']));
runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\calFoutput.mat']);
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=size(sortdata.AVEpercFlu_amp,2);
    repnum=sortdata.repnum;
    
%     % remove ROI based on checking 
%     tempind = strfind(RemoveROI(:,2),sitename);
%     removeflag_prefdir=zeros(ROInum,recordnum);
%     for i=1:size(tempind,1)
%         if tempind{i}==1            
%             ROI_index=str2num(RemoveROI{i,2}((strfind(RemoveROI{14,2},'ROI')+4):end));
%             removeflag_prefdir(ROI_index,1)=1;
%         end
%     end
%     
%     sortdata.removeflag_prefdir=removeflag_prefdir;
    
    
    %DSI threshold test
    
    DS_ROI_test=zeros(ROInum,recordnum,thre_test_level);  
    DS_ROI_num_test=zeros(recordnum,thre_test_level);
   
    
    for j=1:thre_test_level
        DSIthre=DSI_thre_formula(j);  %set different thresholds (0.1,0.14,0.18,...0.58,0.63,0.66)
        for i=1:ROInum
            switch selectmode
                case'all'
                    if all(sortdata.selectROI_outlier(i,:))
                        selectROI=1;
                    else
                        selectROI=0;
                    end
                case 'any'
                    if any(sortdata.selectROI_outlier(i,:))
                        selectROI=1;
                    else
                        selectROI=0;
                    end
                
            end
            if selectROI && sortdata.removeflag_prefdir(i) ==0 % selected neurons but exclude the neurons that are removed based on tuning check
                for r=1:recordnum
                    if sortdata.DSI_new_abs(i,r) > DSIthre   %only neurons that pass gOSI threshold is Orientation Selective ROI
                        DS_ROI_test(i,r,j)=1;         
                    end
                end
             end                
        end
        DS_ROI_num_test(:,j)=sum(DS_ROI_test(:,:,j),1);       
    end
    sortdata.DS_ROI_test=DS_ROI_test; 
    sortdata.DS_ROI_num_test=DS_ROI_num_test;
   
    %load in prefer orientation for plotting distribution
    if f==1
        prefdir_vec_load=[];
        prefDir_peak_load=[];
        ROIselect_load=[];
        DS_ROI_load=[];       
        prefdir_vec_loadseq={sitename,1,ROInum,recordnum};
        DS_ROI_num_sum=zeros(recordnum,thre_test_level);        
        gOSI_load=[];
    else
    %load all the pref directions in an array
        load([prefervectorpath 'Direction\prefdir_vec_load.mat']);
        load([prefervectorpath 'Direction\prefDir_peak_load.mat']);
        load([prefervectorpath 'Direction\prefdir_vec_loadseq.mat']);
        load([prefervectorpath 'Direction\ROIselect_load.mat']);
        load([prefervectorpath 'Direction\DS_ROI_load.mat']);        
        load([prefervectorpath 'Direction\DS_ROI_num_sum.mat']);        
        load([prefervectorpath 'Direction\gOSI_load.mat']);
        ROIstart=prefdir_vec_loadseq{end,3}+1;
        ROIend=ROIstart+ROInum-1;
        prefdir_vec_loadseq(end+1,:)={sitename,ROIstart,ROIend,recordnum};
    end
    endnum=size(prefdir_vec_load,1);
    
    if repflag
        prefdir_vec_load(endnum+1:(endnum+ROInum),:)=sortdata.prefdir_mix;
        prefDir_peak_load(endnum+1:(endnum+ROInum),:)=sortdata.prefdir_ave_peak;
        ROIselect_load(endnum+1:(endnum+ROInum),:)=sortdata.selectROI_outlier;
        gOSI_load(endnum+1:(endnum+ROInum),:)=sortdata.globalOSI;
        for j=1:thre_test_level
            DS_ROI_load(endnum+1:(endnum+ROInum),:,j)=sortdata.DS_ROI_test(:,:,j);        
            DS_ROI_num_sum(:,j)=DS_ROI_num_sum(:,j)+sortdata.DS_ROI_num_test(:,j);                                                                        
        end
    else
        if VLflag
            prefdir_vec_load(endnum+1:(endnum+ROInum),1)=sortdata.prefdir_mix(:,1);
            prefDir_peak_load(endnum+1:(endnum+ROInum),1)=sortdata.prefdir_ave_peak(:,1);
            ROIselect_load(endnum+1:(endnum+ROInum),1)=sortdata.selectROI_outlier(:,1);
            gOSI_load(endnum+1:(endnum+ROInum),1)=sortdata.globalOSI(:,1);
            prefdir_vec_load(endnum+1:(endnum+ROInum),3)=sortdata.prefdir_mix(:,2);
            prefDir_peak_load(endnum+1:(endnum+ROInum),3)=sortdata.prefdir_ave_peak(:,2);
            ROIselect_load(endnum+1:(endnum+ROInum),3)=sortdata.selectROI_outlier(:,2);
            gOSI_load(endnum+1:(endnum+ROInum),3)=sortdata.globalOSI(:,2);
            prefdir_vec_load(endnum+1:(endnum+ROInum),2)=0;
            prefDir_peak_load(endnum+1:(endnum+ROInum),2)=0;
            ROIselect_load(endnum+1:(endnum+ROInum),2)=0;
            gOSI_load(endnum+1:(endnum+ROInum),2)=0;
            for j=1:thre_test_level
                DS_ROI_load(endnum+1:(endnum+ROInum),1,j)=sortdata.DS_ROI_test(:,1,j);        
                DS_ROI_num_sum(1,j)=DS_ROI_num_sum(1,j)+sortdata.DS_ROI_num_test(1,j);
                DS_ROI_load(endnum+1:(endnum+ROInum),3,j)=sortdata.DS_ROI_test(:,2,j);        
                DS_ROI_num_sum(3,j)=DS_ROI_num_sum(2,j)+sortdata.DS_ROI_num_test(2,j);
                DS_ROI_load(endnum+1:(endnum+ROInum),2,j)=0;        
                DS_ROI_num_sum(2,j)=DS_ROI_num_sum(2,j)+0;
                
            end
        else
            prefdir_vec_load(endnum+1:(endnum+ROInum),:)=sortdata.prefdir_mix;
            prefDir_peak_load(endnum+1:(endnum+ROInum),:)=sortdata.prefdir_ave_peak;
            ROIselect_load(endnum+1:(endnum+ROInum),:)=sortdata.selectROI_outlier;
            gOSI_load(endnum+1:(endnum+ROInum),:)=sortdata.globalOSI;
            for j=1:thre_test_level
                DS_ROI_load(endnum+1:(endnum+ROInum),:,j)=sortdata.DS_ROI_test(:,:,j);        
                DS_ROI_num_sum(:,j)=DS_ROI_num_sum(:,j)+sortdata.DS_ROI_num_test(:,j);                                                                        
            end
        end
    end     
    save([prefervectorpath 'Direction\prefdir_vec_load.mat'],'prefdir_vec_load');
    save([prefervectorpath 'Direction\prefDir_peak_load.mat'],'prefDir_peak_load');
    save([prefervectorpath 'Direction\prefdir_vec_loadseq.mat'],'prefdir_vec_loadseq');   
    save([prefervectorpath 'Direction\ROIselect_load.mat'],'ROIselect_load'); 
    save([prefervectorpath 'Direction\DS_ROI_load.mat'],'DS_ROI_load');   
    save([prefervectorpath 'Direction\DS_ROI_num_sum.mat'],'DS_ROI_num_sum');    
    save([prefervectorpath 'Direction\gOSI_load.mat'],'gOSI_load');
    save([prefervectorpath 'Direction\DSI_thre_formula.mat'],'DSI_thre_formula');
        
    if saveflag
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
        %save([calpath sitename '\' ampMethod '\calFoutput.mat'],'calFoutput');    
    end
    clearvars -except selectmode DSI_thre_formula thre_test_level ampMethod RemoveROI baselinemethod saveflag calpath prefervectorpath preferpath RunFolderSeq RLBflag responsiveflag runind ;
%     close all
end

%%
%plot the distribution of the pref. orientation for Orientation selective neurons
load([prefervectorpath 'Direction\prefdir_vec_load.mat']);
load([prefervectorpath 'Direction\prefDir_peak_load.mat']);
load([prefervectorpath 'Direction\prefdir_vec_loadseq.mat']);
load([prefervectorpath 'Direction\ROIselect_load.mat']);
load([prefervectorpath 'Direction\DS_ROI_load.mat']);
load([prefervectorpath 'Direction\DS_ROI_num_sum.mat']);
load([prefervectorpath 'Direction\gOSI_load.mat']);
load([prefervectorpath 'Direction\DSI_thre_formula.mat']);


%%
global calpath prefervectorpath preferpath
globalpara;


selecellflag=1;  % 1=only distribute the cells that are responsive and reliable. 0 means show all the cells
%removeflag=1;  % 1= remove ROI based on tuning check
DS_ROI_flag=1;    %1=only distribute the cells that are responsive and reliable and OS.
gOSIthre =0.1;
%DS_ROI_correct_flag=1;   %1=only distribute the cells that are responsive and reliable and OS_correct.

binNumber_dir=8;
binInterval_dir=360/binNumber_dir;
%binResult_dir=zeros(ROInum,recordnum);
binOri=zeros(1,binNumber_dir);
for i=1:binNumber_dir
    binOri(i)=(i-1)*binInterval_dir;    
end
binhistcata_dir=[binOri-binInterval_dir/2 (binOri(end)-binInterval_dir/2+binInterval_dir)];



ROInum=size(prefdir_vec_load,1);
recordnum=size(prefdir_vec_load,2);
if selecellflag
    temp1=prefdir_vec_load;
    temp0=prefDir_peak_load;
    for i=1:ROInum
        for r=1:recordnum
            if ROIselect_load(i,r)==0  
                 temp1(i,r)=-100;  %take the unselective cells out of range of category
                 temp0(i,r)=-100;
            end
            if temp1(i,r)>=binhistcata_dir(end)
                    temp1(i,r)= temp1(i,r)-360;
            end
        end
    end
end
for j=1:size(DS_ROI_load,3)    
    if DS_ROI_flag
        temp2=prefdir_vec_load;
        for i=1:ROInum
            for r=1:recordnum
                if DS_ROI_load(i,r,j)==0
                    temp2(i,r)=-100;  %take the unselective cells out of range of category
                end
                if temp2(i,r)>=binhistcata_dir(end)
                        temp2(i,r)= temp2(i,r)-360;
                end
            end
        end
    end
    temp3=temp2;  % remove ROI that has gOSI < 0.1
    for i=1:ROInum
        for r=1:recordnum
            if gOSI_load(i,r) < gOSIthre
                temp3(i,r)=-100;
            end
        end
    end
    for r=1:recordnum
        if r==1
            recordname='bef';
        elseif r==2
            recordname='rep';
        elseif r==3
            recordname='aft';
        end
        figure;hold on;

        subplot(1,4,1);
        histogram(temp0(:,r),binhistcata_dir);
        title(['prefDir peak value / selectROI / DSI_thre' num2str(DSI_thre_formula(j))] );
        subplot(1,4,2);
        histogram(temp1(:,r),binhistcata_dir);
        title('prefDir mix / selectROI ' );
        subplot(1,4,3);
        histogram(temp2(:,r),binhistcata_dir);
        title('prefDir mix / selectROI + DS');
        subplot(1,4,4);
        histogram(temp3(:,r),binhistcata_dir);
        title(['prefDir mix / selectROI + DS ' num2str(gOSI_thre_formula(j)) ' + gOS' num2str(gOSIthre) '/ rec ' recordname ]);
        xticks([0 90 180 270])
        xticklabels({'0','90','180','270'})
    end
%     savefig([prefervectorpath '\threshold ' num2str(0.01+(j-1)*0.01)]);
%     saveas(gcf,[prefervectorpath '\threshold ' num2str(0.01+(j-1)*0.01)], 'tiff');
    
end



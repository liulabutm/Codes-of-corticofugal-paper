function varargout = responseviewer(varargin)
% RESPONSEVIEWER MATLAB code for responseviewer.fig
%      RESPONSEVIEWER, by itself, creates a new RESPONSEVIEWER or raises the existing
%      singleton*.
%
%      H = RESPONSEVIEWER returns the handle to a new RESPONSEVIEWER or the handle to
%      the existing singleton*.
%
%      RESPONSEVIEWER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RESPONSEVIEWER.M with the given input arguments.
%
%      RESPONSEVIEWER('Property','Value',...) creates a new RESPONSEVIEWER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before responseviewer_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to responseviewer_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help responseviewer

% Last Modified by GUIDE v2.5 09-Nov-2019 15:45:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @responseviewer_OpeningFcn, ...
                   'gui_OutputFcn',  @responseviewer_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before responseviewer is made visible.
function responseviewer_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to responseviewer (see VARARGIN)

% Choose default command line output for responseviewer
global fighandles sortdata

fighandles.tracefig1=figure;
set(fighandles.tracefig1,'Name','responses');
set(fighandles.tracefig1, 'Position', [20 0 1500 280]);
fighandles.responseaxes=handles.responseaxes;
fighandles.tuningaxes=handles.tuningaxes;
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes responseviewer wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = responseviewer_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
movegui(hObject,'north');

% --- Executes on button press in inputdatapushbutton.
function inputdatapushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to inputdatapushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sortdata datapath fighandles peak_amp

initpath=get(handles.filepathedit,'String');
cd(initpath);
[newfile, path]=uigetfile('*.mat', 'pick up a sortdata mat file');
datapath=[];
if ischar(newfile)
    pos_backslash=strfind(path,'\');
    set(handles.messageedit, 'string', path(pos_backslash(5)+1:pos_backslash(6)-1));
    datapath=fullfile(path,newfile);
    temp=load(datapath);
    if isfield(temp, 'sortdata')
        sortdata=temp.sortdata; 
        pretrigframe=sortdata.pretrigframe;
        actualframerate=sortdata.actualframerate;
        stimtime=sortdata.stimtime;
        stimendframe=pretrigframe+actualframerate*stimtime+str2num(get(handles.frameoffset_end,'String'));
        if ~isfield(sortdata, 'ROIindex')
%             backslashpos=strfind(path, '\');
%             sitename=path(1:backslashpos(end-1));
%             temp=load([sitename 'calFoutput.mat']);
%             calFoutput=temp.calFoutput;
            sortdata.ROIindex=find(sortdata.iscell(:,1));            
        end
        ROImax=length(sortdata.ROIindex);
        ROImin=1;
        set(handles.ROIslider, 'Max', ROImax, 'Min', ROImin, 'Value', 1, 'SliderStep', [1/(ROImax-ROImin) 1]);
        set(handles.ROIedit, 'String', num2str(1,'%d'));
        STMmax=sortdata.uniquestimnum;
%         STMmax=size(sortdata.percFlu_amp,3); 
        STMmin=1;  
        set(handles.STMslider, 'Max', STMmax, 'Min', STMmin, 'Value', 1, 'SliderStep', [1/(STMmax-STMmin) 1]);
        set(handles.STMedit, 'String', num2str(1,'%d'));
%         RECmax=size(sortdata.AVEpercFlu_amp,2); 
        RECmax=sortdata.recordnum;
        RECmin=1;
        if RECmax>RECmin
            set(handles.recordingslider, 'Max', RECmax, 'Min', RECmin, 'Value', 1, 'SliderStep', [1/(RECmax-RECmin) 1]);
        else
            set(handles.recordingslider, 'Max', RECmax, 'Min', RECmin, 'Value', 1, 'SliderStep', [1 1]);
        end
        set(handles.recordingedit, 'String', num2str(1,'%d'));
        
        if ~isfield(sortdata, 'outlierflag') % if outlierflag doesnot exist, create one
            % outlierflag should have the same dimenstionality as the sortdata.percFlu_amp
            
            peak_amp=permute(squeeze(max(sortdata.percFlu(pretrigframe+1:stimendframe,:,:,:),[],1)),[2,1,3]);% ROi,rep,STM
            outlierflag=zeros(size(peak_amp));
%             repnum=size(sortdata.percFlu,2)/RECmax;
            repnum=sortdata.repnum;
            for i=1:sortdata.uniquestimnum %STM
                for j=1:size(peak_amp,1) % ROI
                    for k=1:RECmax
                        outlierflag(j,1+(k-1)*repnum:k*repnum,i)=isoutlier(peak_amp(j,1+(k-1)*repnum:k*repnum,i),'quartiles');
                    end
                end
            end
            sortdata.outlierflag=outlierflag; % ROI,Rep,STM
        else
            peak_amp=permute(squeeze(max(sortdata.percFlu(pretrigframe+1:stimendframe,:,:,:),[],1)),[2,1,3]);% ROi,rep,STM
%             repnum=size(sortdata.percFlu,2)/RECmax;
            repnum=sortdata.repnum;
        end
        
        if ~isfield(sortdata, 'ignoreflag')
            sortdata.ignoreflag=zeros(size(sortdata.ONE_WAY_ANOVA));
            set(handles.ignoreROI, 'value', sortdata.ignoreflag(1,1));
        else
            set(handles.ignoreROI, 'value', sortdata.ignoreflag(1,1));
        end
        if ~isfield(sortdata, 'virusExp')
            sortdata.virusExp=1; % 0,bad expression; 1,good expression
            set(handles.badprep, 'value', ~sortdata.virusExp);
        else
            set(handles.badprep, 'value', ~sortdata.virusExp);
        end
        % plot the response map of first ROI in fighandles.tracefig1
         %plot outliner in dotted lines
%          xtime=1:size(sortdata.percFlu,1); %in frames
         xtime=1:sortdata.actualnumimgsperstim;  %in frames
         figure(fighandles.tracefig1);
         for p=1:sortdata.uniquestimnum % STM
            subplot(1,sortdata.uniquestimnum,p);
            hold off;
            for q=1:repnum
                if q>1
                    hold on;
                end
                temppercFlu=sortdata.percFlu(:,q,1,p);
                if sortdata.outlierflag(1,q,p)
                    plot(xtime,temppercFlu,'--');
                else
                    plot(xtime,temppercFlu);
                end
            end
            %plot(1:actualnumimgsperstim,(mean(sortdata.percFlu(:,1+(j-1)*repnum:j*repnum,i,p),2))','LineWidth',2);
            if sortdata.INDofpref(1,1)==p-1
                title([' stim' num2str(p-1,'%d') ' pref  p= ' num2str(sortdata.ONE_WAY_ANOVA(1,1),'%f')]);
            else 
                title([' stim' num2str(p-1,'%d')]);
            end
            legend('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15');
            legend('off');
         end

        % plot the responses of first ROI & first STM in fighandles.responseaxes
         %plot outliner in dotted lines
         axes(fighandles.responseaxes);
         hold off;
         for q=1:repnum
            if q>1
                hold on;
            end
            temppercFlu=sortdata.percFlu(:,q,1,1);
            if sortdata.outlierflag(1,q,1)
                plot(xtime,temppercFlu,'--');
            else
                plot(xtime,temppercFlu);
            end
         end
        hold on;
        maxvalue=max(max(sortdata.percFlu(:,:,1,1)));
        minvalue=min(min(sortdata.percFlu(:,:,1,1)));
        plot([pretrigframe+1 pretrigframe+1], [minvalue  maxvalue], '--r', 'linewidth', 1); 
        plot([stimendframe stimendframe], [minvalue  maxvalue], '--r', 'linewidth', 1);
        % plot the tuning of first ROI in fighandles.tuningaxes; plot a line at the
        % current STM
        tuning=zeros(1,sortdata.uniquestimnum);
        for i=1:sortdata.uniquestimnum
            outlierflag_stim=squeeze(sortdata.outlierflag(1,1:repnum,i)); % only the first recording
%             percFlu_amp_stim=squeeze(sortdata.percFlu_amp(1,1:repnum,i));
            %use sortdata.percFlu to calculate amp to replace the following
            %line
            percFlu_ave=mean(sortdata.percFlu(pretrigframe+1:stimendframe,~outlierflag_stim,1,i),2); % frames
            tuning(i)=max(percFlu_ave); %%%new strategy % only the first recording recordings
            %        tuning(i)= mean(percFlu_amp_stim(~outlierflag_stim),2);% roi, rep, stm
        end
        axes(fighandles.tuningaxes);
        hold off;
        if sortdata.blankflag
            xvalue=(1:length(tuning))-1;
        else
            xvalue=1:length(tuning);
        end
        plot(xvalue,tuning);
        hold on;
        plot([xvalue(1) xvalue(1)],[min(tuning), max(tuning)],'linewidth', 2);


        % display value in the outlierlistbox and set the outlierlistbox for ROI1 & STM1
%         peak_amp(:,:,:)=max(sortdata.percFlu(7:end,:,:,:),[],1); 
        amplitude=[(1:repnum)' squeeze(peak_amp(1,1:repnum,1))'];
        [temp,sortedseq]=sort(amplitude(:,2),1,'descend');
        amplitude_sort=amplitude(sortedseq,:); % first colume is the trial#; second is the sorted amp
        amplitude_sort_cell = cellstr(num2str(amplitude_sort));
        outlierflag_sort=squeeze(sortdata.outlierflag(1,sortedseq,1)); % outlierflag: ROI,Rep,STM
        set(handles.outlierlistbox, 'Max', size(amplitude_sort,1));
        set(handles.outlierlistbox, 'String', amplitude_sort_cell);
        set(handles.outlierlistbox, 'value', find(outlierflag_sort));
    else
        set(handles.messageedit, 'String', 'No data exist');
    end
end



function filepathedit_Callback(hObject, eventdata, handles)
% hObject    handle to filepathedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filepathedit as text
%        str2double(get(hObject,'String')) returns contents of filepathedit as a double


% --- Executes during object creation, after setting all properties.
function filepathedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filepathedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in outlierlistbox.
function outlierlistbox_Callback(hObject, eventdata, handles)
% hObject    handle to outlierlistbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns outlierlistbox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from outlierlistbox
global sortdata datapath fighandles
pretrigframe=sortdata.pretrigframe;
actualframerate=sortdata.actualframerate;
stimtime=sortdata.stimtime;
stimendframe=pretrigframe+actualframerate*stimtime+str2num(get(handles.frameoffset_end,'String'));

repnum=sortdata.repnum;
outlierpicked=get(hObject, 'Value');
currentROI=get(handles.ROIslider, 'Value');
currentSTM=get(handles.STMslider, 'Value');
currentREC=get(handles.recordingslider, 'Value');
amplitude_sort_cell=get(handles.outlierlistbox, 'String');
amplitude_sort=str2num(char(amplitude_sort_cell));
sortedseq=amplitude_sort(:,1); % 1st colume: sorted sequence
outlierflag=squeeze(sortdata.outlierflag(currentROI,1+(currentREC-1)*repnum:repnum*currentREC,currentSTM));
outlierflag_sort=outlierflag(sortedseq);
outlierflag_sort(outlierpicked)=~outlierflag_sort(outlierpicked);
set(handles.outlierlistbox, 'value', find(outlierflag_sort));
[temp, newseq]=sort(sortedseq);
outlierflag=outlierflag_sort(newseq);
sortdata.outlierflag(currentROI,1+(currentREC-1)*repnum:repnum*currentREC,currentSTM)=outlierflag;


xtime=1:sortdata.actualnumimgsperstim;  %in frames
% figure(fighandles.tracefig1);
% for p=1:sortdata.uniquestimnum % STM
%     subplot(1,sortdata.uniquestimnum,p);
%     hold off;
%     for q=1:repnum
%         if q>1
%             hold on;
%         end
%         temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,p);
%         if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),p)
%             plot(xtime,temppercFlu,'--');
%         else
%             plot(xtime,temppercFlu);
%         end
%     end
%     %plot(1:actualnumimgsperstim,(mean(sortdata.percFlu(:,1+(j-1)*repnum:j*repnum,i,p),2))','LineWidth',2);
%     if sortdata.INDofpref(currentROI,currentREC)==p
%         title([' stim' num2str(p,'%d') '   p= ' num2str(sortdata.ONE_WAY_ANOVA(currentROI,currentREC),'%f')]);
%     else 
%         title([' stim' num2str(p,'%d')]);
%     end
%     legend('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15');
%     legend('off');
% end

% plot the responses of first ROI & first STM in fighandles.responseaxes
 %plot outliner in dotted lines
axes(fighandles.responseaxes);
hold off;
for q=1:repnum
    if q>1
        hold on;
    end
    temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,currentSTM);
    if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),currentSTM)
        plot(xtime,temppercFlu,'--');
    else
        plot(xtime,temppercFlu);
    end
end
hold on;
maxvalue=max(max(sortdata.percFlu(:,:,currentROI,currentSTM)));
minvalue=min(min(sortdata.percFlu(:,:,currentROI,currentSTM)));
plot([pretrigframe+1 pretrigframe+1], [minvalue  maxvalue], '--r', 'linewidth', 1); 
plot([stimendframe stimendframe], [minvalue  maxvalue], '--r', 'linewidth', 1);
% plot the tuning of first ROI in fighandles.tuningaxes; plot a line at the
% current STM
tuning=zeros(1,sortdata.uniquestimnum);
for i=1:sortdata.uniquestimnum
    outlierflag_stim=squeeze(sortdata.outlierflag(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
%     percFlu_amp_stim=squeeze(sortdata.percFlu_amp(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
    percFlu_temp=sortdata.percFlu(:,1+repnum*(currentREC-1):repnum*currentREC,:,:);
    percFlu_ave=mean(percFlu_temp(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames
    tuning(i)=max(percFlu_ave); %%%new strategy
%     tuning(i)= mean(percFlu_amp_stim(~outlierflag_stim),2);% roi, rep, stm
end
axes(fighandles.tuningaxes);
hold off;
if sortdata.blankflag
    xvalue=(1:length(tuning))-1;
else
    xvalue=1:length(tuning);
end
plot(xvalue,tuning);
hold on;
plot([xvalue(currentSTM) xvalue(currentSTM)],[min(tuning), max(tuning)],'linewidth', 2);




% --- Executes during object creation, after setting all properties.
function outlierlistbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to outlierlistbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in savepushbutton.
function savepushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to savepushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sortdata datapath fighandles
if ~isempty(datapath)
    save(datapath, 'sortdata');
end

% --- Executes on slider movement.
function ROIslider_Callback(hObject, eventdata, handles)
% hObject    handle to ROIslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global sortdata datapath fighandles
pretrigframe=sortdata.pretrigframe;
actualframerate=sortdata.actualframerate;
stimtime=sortdata.stimtime;
stimendframe=pretrigframe+actualframerate*stimtime+str2num(get(handles.frameoffset_end,'String'));

ROIpointer=get(hObject, 'Value');
ROIpointer=fix(ROIpointer);
set(hObject, 'Value', ROIpointer);
set(handles.ROIedit, 'String', num2str(ROIpointer, '%d'));
set(handles.ROIINDedit, 'String', num2str(sortdata.ROIindex(ROIpointer), '%d')); % ROI in 2psuite

currentROI=get(handles.ROIslider, 'Value');
currentSTM=get(handles.STMslider, 'Value');
currentREC=get(handles.recordingslider, 'Value');
set(handles.ignoreROI, 'value', sortdata.ignoreflag(currentROI,currentREC));
% plot the response map of first ROI in fighandles.tracefig1
 %plot outliner in dotted lines
repnum=sortdata.repnum;
xtime=1:sortdata.actualnumimgsperstim;  %in frames
figure(fighandles.tracefig1);
for p=1:sortdata.uniquestimnum % STM
    subplot(1,sortdata.uniquestimnum,p);
    hold off;
    for q=1:repnum
        if q>1
            hold on;
        end
        temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,p);
        if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),p)
            plot(xtime,temppercFlu,'--');
        else
            plot(xtime,temppercFlu);
        end
    end
    %plot(1:actualnumimgsperstim,(mean(sortdata.percFlu(:,1+(j-1)*repnum:j*repnum,i,p),2))','LineWidth',2);
    if sortdata.INDofpref(currentROI,currentREC)==p-1
        title([' stim' num2str(p-1,'%d') '   p= ' num2str(sortdata.ONE_WAY_ANOVA(currentROI,currentREC),'%f')]);
    else 
        title([' stim' num2str(p-1,'%d')]);
    end
    legend('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15');
    legend('off');
end

% plot the responses of first ROI & first STM in fighandles.responseaxes
 %plot outliner in dotted lines
axes(fighandles.responseaxes);
hold off;
for q=1:repnum
    if q>1
        hold on;
    end
    temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,currentSTM);
    if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),currentSTM)
        plot(xtime,temppercFlu,'--');
    else
        plot(xtime,temppercFlu);
    end
end
hold on;
maxvalue=max(max(sortdata.percFlu(:,:,currentROI,currentSTM)));
minvalue=min(min(sortdata.percFlu(:,:,currentROI,currentSTM)));
plot([pretrigframe+1 pretrigframe+1], [minvalue  maxvalue], '--r', 'linewidth', 1); 
plot([stimendframe stimendframe], [minvalue  maxvalue], '--r', 'linewidth', 1);

% plot the tuning of first ROI in fighandles.tuningaxes; plot a line at the
% current STM
tuning=zeros(1,sortdata.uniquestimnum);
for i=1:sortdata.uniquestimnum
    outlierflag_stim=squeeze(sortdata.outlierflag(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
%     percFlu_amp_stim=squeeze(sortdata.percFlu_amp(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
    percFlu_temp=sortdata.percFlu(:,1+repnum*(currentREC-1):repnum*currentREC,:,:);
    percFlu_ave=mean(percFlu_temp(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames
    %percFlu_ave=mean(sortdata.percFlu(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2);
    tuning(i)=max(percFlu_ave); %%%new strategy
    %     tuning(i)= mean(percFlu_amp_stim(~outlierflag_stim),2);% roi, rep, stm
end
axes(fighandles.tuningaxes);
hold off;
if sortdata.blankflag
    xvalue=(1:length(tuning))-1;
else
    xvalue=1:length(tuning);
end
plot(xvalue,tuning);
hold on;
plot([xvalue(currentSTM) xvalue(currentSTM)],[min(tuning), max(tuning)],'linewidth', 2);

% display value in the outlierlistbox and set the outlierlistbox for ROI1 & STM1
peak_amp=permute(squeeze(max(sortdata.percFlu(pretrigframe+1:stimendframe,:,:,:),[],1)),[2,1,3]);% ROi,rep,STM
amplitude=[(1:repnum)' squeeze(peak_amp(currentROI,1+(currentREC-1)*repnum:currentREC*repnum,currentSTM))'];
[temp,sortedseq]=sort(amplitude(:,2),1,'descend');
amplitude_sort=amplitude(sortedseq,:); % first colume is the trial#; second is the sorted amp
amplitude_sort_cell = cellstr(num2str(amplitude_sort));
outlierflag_sort=squeeze(sortdata.outlierflag(currentROI,sortedseq+(currentREC-1)*repnum,currentSTM)); % outlierflag: ROI,Rep,STM
set(handles.outlierlistbox, 'Max', size(amplitude_sort,1));
set(handles.outlierlistbox, 'String', amplitude_sort_cell);
set(handles.outlierlistbox, 'value', find(outlierflag_sort));


% --- Executes during object creation, after setting all properties.
function ROIslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ROIslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function ROIedit_Callback(hObject, eventdata, handles)
% hObject    handle to ROIedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ROIedit as text
%        str2double(get(hObject,'String')) returns contents of ROIedit as a double
global sortdata datapath fighandles
pretrigframe=sortdata.pretrigframe;
actualframerate=sortdata.actualframerate;
stimtime=sortdata.stimtime;
stimendframe=pretrigframe+actualframerate*stimtime+str2num(get(handles.frameoffset_end,'String'));

ROIpointer=fix(str2num(get(hObject, 'String')));
ROImax=get(handles.ROIslider, 'Max');
ROImin=get(handles.ROIslider, 'Min');
if ROIpointer>ROImax
    ROIpointer=ROImax;
    set(hObject, 'String', num2str(ROIpointer, '%d'));
end
if ROIpointer<ROImin
    ROIpointer=ROImin;
    set(hObject, 'String', num2str(ROIpointer, '%d'));
end
set(handles.ROIslider, 'Value', ROIpointer);
set(handles.ROIINDedit, 'String', num2str(sortdata.ROIindex(ROIpointer), '%d')); %ROI in 2psuite

%%%%%%%%%%%%%%%%%%%%%%%%%%%?????????????????????????????
currentROI=get(handles.ROIslider, 'Value');
currentSTM=get(handles.STMslider, 'Value');
currentREC=get(handles.recordingslider, 'Value');
set(handles.ignoreROI, 'value', sortdata.ignoreflag(currentROI,currentREC));
% plot the response map of first ROI in fighandles.tracefig1
 %plot outliner in dotted lines
repnum=sortdata.repnum;
xtime=1:sortdata.actualnumimgsperstim;  %in frames
figure(fighandles.tracefig1);
for p=1:sortdata.uniquestimnum % STM
    subplot(1,sortdata.uniquestimnum,p);
    hold off;
    for q=1:repnum
        if q>1
            hold on;
        end
        temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,p);
        if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),p)
            plot(xtime,temppercFlu,'--');
        else
            plot(xtime,temppercFlu);
        end
    end
    %plot(1:actualnumimgsperstim,(mean(sortdata.percFlu(:,1+(j-1)*repnum:j*repnum,i,p),2))','LineWidth',2);
    if sortdata.INDofpref(currentROI,currentREC)==p-1
        title([' stim' num2str(p-1,'%d') '   p= ' num2str(sortdata.ONE_WAY_ANOVA(currentROI,currentREC),'%f')]);
    else 
        title([' stim' num2str(p-1,'%d')]);
    end
    legend('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15');
    legend('off');
end

% plot the responses of first ROI & first STM in fighandles.responseaxes
 %plot outliner in dotted lines
axes(fighandles.responseaxes);
hold off;
for q=1:repnum
    if q>1
        hold on;
    end
    temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,currentSTM);
    if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),currentSTM)
        plot(xtime,temppercFlu,'--');
    else
        plot(xtime,temppercFlu);
    end
end
hold on;
maxvalue=max(max(sortdata.percFlu(:,:,currentROI,currentSTM)));
minvalue=min(min(sortdata.percFlu(:,:,currentROI,currentSTM)));
plot([pretrigframe+1 pretrigframe+1], [minvalue  maxvalue], '--r', 'linewidth', 1); 
plot([stimendframe stimendframe], [minvalue  maxvalue], '--r', 'linewidth', 1);

% plot the tuning of first ROI in fighandles.tuningaxes; plot a line at the
% current STM
tuning=zeros(1,sortdata.uniquestimnum);
for i=1:sortdata.uniquestimnum
    outlierflag_stim=squeeze(sortdata.outlierflag(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
%     percFlu_amp_stim=squeeze(sortdata.percFlu_amp(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
    percFlu_temp=sortdata.percFlu(:,1+repnum*(currentREC-1):repnum*currentREC,:,:);
    percFlu_ave=mean(percFlu_temp(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames  
    %percFlu_ave=mean(sortdata.percFlu(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames
    tuning(i)=max(percFlu_ave); %%%new strategy
%     tuning(i)= mean(percFlu_amp_stim(~outlierflag_stim),2);% roi, rep, stm
end
axes(fighandles.tuningaxes);
hold off;
if sortdata.blankflag
    xvalue=(1:length(tuning))-1;
else
    xvalue=1:length(tuning);
end
plot(xvalue,tuning);
hold on;
plot([xvalue(currentSTM) xvalue(currentSTM)],[min(tuning), max(tuning)],'linewidth', 2);

% display value in the outlierlistbox and set the outlierlistbox for ROI1 & STM1
peak_amp=permute(squeeze(max(sortdata.percFlu(pretrigframe+1:stimendframe,:,:,:),[],1)),[2,1,3]);% ROi,rep,STM
amplitude=[(1:repnum)' squeeze(peak_amp(currentROI,1+(currentREC-1)*repnum:currentREC*repnum,currentSTM))'];
[temp,sortedseq]=sort(amplitude(:,2),1,'descend');
amplitude_sort=amplitude(sortedseq,:); % first colume is the trial#; second is the sorted amp
amplitude_sort_cell = cellstr(num2str(amplitude_sort));
outlierflag_sort=squeeze(sortdata.outlierflag(currentROI,sortedseq+(currentREC-1)*repnum,currentSTM)); % outlierflag: ROI,Rep,STM
set(handles.outlierlistbox, 'Max', size(amplitude_sort,1));
set(handles.outlierlistbox, 'String', amplitude_sort_cell);
set(handles.outlierlistbox, 'value', find(outlierflag_sort));



% --- Executes during object creation, after setting all properties.
function ROIedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ROIedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function STMslider_Callback(hObject, eventdata, handles)
% hObject    handle to STMslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global sortdata datapath fighandles
pretrigframe=sortdata.pretrigframe;
actualframerate=sortdata.actualframerate;
stimtime=sortdata.stimtime;
stimendframe=pretrigframe+actualframerate*stimtime+str2num(get(handles.frameoffset_end,'String'));

STMpointer=get(hObject, 'Value');
STMpointer=fix(STMpointer);
set(hObject, 'Value', STMpointer);
set(handles.STMedit, 'String', num2str(STMpointer, '%d'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%?????????????????????????????
currentROI=get(handles.ROIslider, 'Value');
currentSTM=get(handles.STMslider, 'Value');
currentREC=get(handles.recordingslider, 'Value');

% plot the responses of first ROI & first STM in fighandles.responseaxes
 %plot outliner in dotted lines
repnum=sortdata.repnum;
xtime=1:sortdata.actualnumimgsperstim;  %in frames
axes(fighandles.responseaxes);
hold off;
for q=1:repnum
    if q>1
        hold on;
    end
    temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,currentSTM);
    if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),currentSTM)
        plot(xtime,temppercFlu,'--');
    else
        plot(xtime,temppercFlu);
    end
end
hold on;
maxvalue=max(max(sortdata.percFlu(:,:,currentROI,currentSTM)));
minvalue=min(min(sortdata.percFlu(:,:,currentROI,currentSTM)));
plot([pretrigframe+1 pretrigframe+1], [minvalue  maxvalue], '--r', 'linewidth', 1); 
plot([stimendframe stimendframe], [minvalue  maxvalue], '--r', 'linewidth', 1);

% plot the tuning of first ROI in fighandles.tuningaxes; plot a line at the
% current STM
tuning=zeros(1,sortdata.uniquestimnum);
for i=1:sortdata.uniquestimnum
    outlierflag_stim=squeeze(sortdata.outlierflag(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
%     percFlu_amp_stim=squeeze(sortdata.percFlu_amp(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
    percFlu_temp=sortdata.percFlu(:,1+repnum*(currentREC-1):repnum*currentREC,:,:);
    percFlu_ave=mean(percFlu_temp(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames   
    %percFlu_ave=mean(sortdata.percFlu(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames
    tuning(i)=max(percFlu_ave); %%%new strategy
%     tuning(i)= mean(percFlu_amp_stim(~outlierflag_stim),2);% roi, rep, stm
end
axes(fighandles.tuningaxes);
hold off;
if sortdata.blankflag
    xvalue=(1:length(tuning))-1;
else
    xvalue=1:length(tuning);
end
plot(xvalue,tuning);
hold on;
plot([xvalue(currentSTM) xvalue(currentSTM)],[min(tuning), max(tuning)],'linewidth', 2);

 
% display value in the outlierlistbox and set the outlierlistbox for ROI1 & STM1
peak_amp=permute(squeeze(max(sortdata.percFlu(pretrigframe+1:stimendframe,:,:,:),[],1)),[2,1,3]);% ROi,rep,STM
amplitude=[(1:repnum)' squeeze(peak_amp(currentROI,1+(currentREC-1)*repnum:currentREC*repnum,currentSTM))'];
[temp,sortedseq]=sort(amplitude(:,2),1,'descend');
amplitude_sort=amplitude(sortedseq,:); % first colume is the trial#; second is the sorted amp
amplitude_sort_cell = cellstr(num2str(amplitude_sort));
outlierflag_sort=squeeze(sortdata.outlierflag(currentROI,sortedseq+(currentREC-1)*repnum,currentSTM)); % outlierflag: ROI,Rep,STM
set(handles.outlierlistbox, 'Max', size(amplitude_sort,1));
set(handles.outlierlistbox, 'String', amplitude_sort_cell);
set(handles.outlierlistbox, 'value', find(outlierflag_sort));

% --- Executes during object creation, after setting all properties.
function STMslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to STMslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function STMedit_Callback(hObject, eventdata, handles)
% hObject    handle to STMedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of STMedit as text
%        str2double(get(hObject,'String')) returns contents of STMedit as a double
global sortdata datapath fighandles
pretrigframe=sortdata.pretrigframe;
actualframerate=sortdata.actualframerate;
stimtime=sortdata.stimtime;
stimendframe=pretrigframe+actualframerate*stimtime+str2num(get(handles.frameoffset_end,'String'));

STMpointer=fix(str2num(get(hObject, 'String')));
STMmax=get(handles.STMslider, 'Max');
STMmin=get(handles.STMslider, 'Min');
if STMpointer>STMmax
    STMpointer=STMmax;
    set(hObject, 'String', num2str(STMpointer, '%d'));
end
if STMpointer<STMmin
    STMpointer=STMmin;
    set(hObject, 'String', num2str(STMpointer, '%d'));
end
set(handles.STMslider, 'Value', STMpointer);

%%%%%%%%%%%%%%%%%%%%%%%%%%%?????????????????????????????
currentROI=get(handles.ROIslider, 'Value');
currentSTM=get(handles.STMslider, 'Value');
currentREC=get(handles.recordingslider, 'Value');

% plot the responses of first ROI & first STM in fighandles.responseaxes
 %plot outliner in dotted lines
repnum=sortdata.repnum;
xtime=1:sortdata.actualnumimgsperstim;  %in frames
axes(fighandles.responseaxes);
hold off;
for q=1:repnum
    if q>1
        hold on;
    end
    temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,currentSTM);
    if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),currentSTM)
        plot(xtime,temppercFlu,'--');
    else
        plot(xtime,temppercFlu);
    end
end
hold on;
maxvalue=max(max(sortdata.percFlu(:,:,currentROI,currentSTM)));
minvalue=min(min(sortdata.percFlu(:,:,currentROI,currentSTM)));
plot([pretrigframe+1 pretrigframe+1], [minvalue  maxvalue], '--r', 'linewidth', 1); 
plot([stimendframe stimendframe], [minvalue  maxvalue], '--r', 'linewidth', 1);

% plot the tuning of first ROI in fighandles.tuningaxes; plot a line at the
% current STM
tuning=zeros(1,sortdata.uniquestimnum);
for i=1:sortdata.uniquestimnum
    outlierflag_stim=squeeze(sortdata.outlierflag(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
%     percFlu_amp_stim=squeeze(sortdata.percFlu_amp(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
    percFlu_temp=sortdata.percFlu(:,1+repnum*(currentREC-1):repnum*currentREC,:,:);
    percFlu_ave=mean(percFlu_temp(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames    
    %percFlu_ave=mean(sortdata.percFlu(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames
    tuning(i)=max(percFlu_ave); %%%new strategy
%     tuning(i)= mean(percFlu_amp_stim(~outlierflag_stim),2);% roi, rep, stm
end
axes(fighandles.tuningaxes);
hold off;
if sortdata.blankflag
    xvalue=(1:length(tuning))-1;
else
    xvalue=1:length(tuning);
end
plot(xvalue,tuning);
hold on;
plot([xvalue(currentSTM) xvalue(currentSTM)],[min(tuning), max(tuning)],'linewidth', 2);
 
% display value in the outlierlistbox and set the outlierlistbox for ROI1 & STM1
peak_amp=permute(squeeze(max(sortdata.percFlu(pretrigframe+1:stimendframe,:,:,:),[],1)),[2,1,3]);% ROi,rep,STM
amplitude=[(1:repnum)' squeeze(peak_amp(currentROI,1+(currentREC-1)*repnum:currentREC*repnum,currentSTM))'];
[temp,sortedseq]=sort(amplitude(:,2),1,'descend');
amplitude_sort=amplitude(sortedseq,:); % first colume is the trial#; second is the sorted amp
amplitude_sort_cell = cellstr(num2str(amplitude_sort));
outlierflag_sort=squeeze(sortdata.outlierflag(currentROI,sortedseq+(currentREC-1)*repnum,currentSTM)); % outlierflag: ROI,Rep,STM
set(handles.outlierlistbox, 'Max', size(amplitude_sort,1));
set(handles.outlierlistbox, 'String', amplitude_sort_cell);
set(handles.outlierlistbox, 'value', find(outlierflag_sort));

% --- Executes during object creation, after setting all properties.
function STMedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to STMedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ROIINDedit_Callback(hObject, eventdata, handles)
% hObject    handle to ROIINDedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ROIINDedit as text
%        str2double(get(hObject,'String')) returns contents of ROIINDedit as a double


% --- Executes during object creation, after setting all properties.
function ROIINDedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ROIINDedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sortdata datapath fighandles
try  delete(fighandles.tracefig1); end
% Hint: delete(hObject) closes the figure
delete(hObject);
clear all;



function messageedit_Callback(hObject, eventdata, handles)
% hObject    handle to messageedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of messageedit as text
%        str2double(get(hObject,'String')) returns contents of messageedit as a double


% --- Executes during object creation, after setting all properties.
function messageedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to messageedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function recordingslider_Callback(hObject, eventdata, handles)
% hObject    handle to ROIslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global sortdata datapath fighandles
pretrigframe=sortdata.pretrigframe;
actualframerate=sortdata.actualframerate;
stimtime=sortdata.stimtime;
stimendframe=pretrigframe+actualframerate*stimtime+str2num(get(handles.frameoffset_end,'String'));

RECpointer=get(hObject, 'Value');
RECpointer=fix(RECpointer);
set(hObject, 'Value', RECpointer);
set(handles.recordingedit, 'String', num2str(RECpointer, '%d'));
%set(handles.ROIINDedit, 'String', num2str(sortdata.ROIindex(ROIpointer), '%d')); % ROI in 2psuite
%%%%%%%%%%%%%%%%%%%%%%%%%%%?????????????????????????????
currentROI=get(handles.ROIslider, 'Value');
currentSTM=get(handles.STMslider, 'Value');
currentREC=get(handles.recordingslider, 'Value');
set(handles.ignoreROI, 'value', sortdata.ignoreflag(currentROI,currentREC));
% plot the response map of first ROI in fighandles.tracefig1
 %plot outliner in dotted lines
repnum=sortdata.repnum;
xtime=1:sortdata.actualnumimgsperstim;  %in frames
figure(fighandles.tracefig1);
for p=1:sortdata.uniquestimnum % STM
    subplot(1,sortdata.uniquestimnum,p);
    hold off;
    for q=1:repnum
        if q>1
            hold on;
        end
        temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,p);
        if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),p)
            plot(xtime,temppercFlu,'--');
        else
            plot(xtime,temppercFlu);
        end
    end
    %plot(1:actualnumimgsperstim,(mean(sortdata.percFlu(:,1+(j-1)*repnum:j*repnum,i,p),2))','LineWidth',2);
    if sortdata.INDofpref(currentROI,currentREC)==p-1
        title([' stim' num2str(p-1,'%d') '   p= ' num2str(sortdata.ONE_WAY_ANOVA(currentROI,currentREC),'%f')]);
    else 
        title([' stim' num2str(p-1,'%d')]);
    end
    legend('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15');
    legend('off');
end

% plot the responses of first ROI & first STM in fighandles.responseaxes
 %plot outliner in dotted lines
axes(fighandles.responseaxes);
hold off;
for q=1:repnum
    if q>1
        hold on;
    end
    temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,currentSTM);
    if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),currentSTM)
        plot(xtime,temppercFlu,'--');
    else
        plot(xtime,temppercFlu);
    end
end
hold on;
maxvalue=max(max(sortdata.percFlu(:,:,currentROI,currentSTM)));
minvalue=min(min(sortdata.percFlu(:,:,currentROI,currentSTM)));
plot([pretrigframe+1 pretrigframe+1], [minvalue  maxvalue], '--r', 'linewidth', 1); 
plot([stimendframe stimendframe], [minvalue  maxvalue], '--r', 'linewidth', 1);
% plot the tuning of first ROI in fighandles.tuningaxes; plot a line at the
% current STM
tuning=zeros(1,sortdata.uniquestimnum);
for i=1:sortdata.uniquestimnum
    outlierflag_stim=squeeze(sortdata.outlierflag(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
%     percFlu_amp_stim=squeeze(sortdata.percFlu_amp(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
    percFlu_temp=sortdata.percFlu(:,1+repnum*(currentREC-1):repnum*currentREC,:,:);
    percFlu_ave=mean(percFlu_temp(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames    
    %percFlu_ave=mean(sortdata.percFlu(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames
    tuning(i)=max(percFlu_ave); %%%new strategy
%     tuning(i)= mean(percFlu_amp_stim(~outlierflag_stim),2);% roi, rep, stm
end
axes(fighandles.tuningaxes);
hold off;
if sortdata.blankflag
    xvalue=(1:length(tuning))-1;
else
    xvalue=1:length(tuning);
end
plot(xvalue,tuning);
hold on;
plot([xvalue(currentSTM) xvalue(currentSTM)],[min(tuning), max(tuning)],'linewidth', 2);


% display value in the outlierlistbox and set the outlierlistbox for ROI1 & STM1
peak_amp=permute(squeeze(max(sortdata.percFlu(pretrigframe+1:stimendframe,:,:,:),[],1)),[2,1,3]);% ROi,rep,STM
amplitude=[(1:repnum)' squeeze(peak_amp(currentROI,1+(currentREC-1)*repnum:currentREC*repnum,currentSTM))'];
[temp,sortedseq]=sort(amplitude(:,2),1,'descend');
amplitude_sort=amplitude(sortedseq,:); % first colume is the trial#; second is the sorted amp
amplitude_sort_cell = cellstr(num2str(amplitude_sort));
outlierflag_sort=squeeze(sortdata.outlierflag(currentROI,sortedseq+(currentREC-1)*repnum,currentSTM)); % outlierflag: ROI,Rep,STM
set(handles.outlierlistbox, 'Max', size(amplitude_sort,1));
set(handles.outlierlistbox, 'String', amplitude_sort_cell);
set(handles.outlierlistbox, 'value', find(outlierflag_sort));


% --- Executes during object creation, after setting all properties.
function recordingslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to recordingslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


function recordingedit_Callback(hObject, eventdata, handles)
% hObject    handle to ROIedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ROIedit as text
%        str2double(get(hObject,'String')) returns contents of ROIedit as a double
global sortdata datapath fighandles
pretrigframe=sortdata.pretrigframe;
actualframerate=sortdata.actualframerate;
stimtime=sortdata.stimtime;
stimendframe=pretrigframe+actualframerate*stimtime+str2num(get(handles.frameoffset_end,'String'));

RECpointer=fix(str2num(get(hObject, 'String')));
RECmax=get(handles.recordingedit, 'Max');
RECmin=get(handles.recordingedit, 'Min');
if RECpointer>RECmax
    RECpointer=RECmax;
    set(hObject, 'String', num2str(RECpointer, '%d'));
end
if RECpointer<RECmin
    RECpointer=RECmin;
    set(hObject, 'String', num2str(RECpointer, '%d'));
end
set(handles.ROIslider, 'Value', RECpointer);
set(handles.ROIINDedit, 'String', num2str(sortdata.ROIindex(RECpointer), '%d')); %ROI in 2psuite


currentROI=get(handles.ROIslider, 'Value');
currentSTM=get(handles.STMslider, 'Value');
currentREC=get(handles.recordingslider, 'Value');
set(handles.ignoreROI, 'value', sortdata.ignoreflag(currentROI,currentREC));
% plot the response map of first ROI in fighandles.tracefig1
 %plot outliner in dotted lines
repnum=sortdata.repnum;
xtime=1:sortdata.actualnumimgsperstim;  %in frames
figure(fighandles.tracefig1);
for p=1:sortdata.uniquestimnum % STM
    subplot(1,sortdata.uniquestimnum,p);
    hold off;
    for q=1:repnum
        if q>1
            hold on;
        end
        temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,p);
        if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),p)
            plot(xtime,temppercFlu,'--');
        else
            plot(xtime,temppercFlu);
        end
    end
    %plot(1:actualnumimgsperstim,(mean(sortdata.percFlu(:,1+(j-1)*repnum:j*repnum,i,p),2))','LineWidth',2);
    if sortdata.INDofpref(currentROI,currentREC)==p-1
        title([' stim' num2str(p-1,'%d') '   p= ' num2str(sortdata.ONE_WAY_ANOVA(currentROI,currentREC),'%f')]);
    else 
        title([' stim' num2str(p-1,'%d')]);
    end
    legend('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15');
    legend('off');
end

% plot the responses of first ROI & first STM in fighandles.responseaxes
 %plot outliner in dotted lines
axes(fighandles.responseaxes);
hold off;
for q=1:repnum
    if q>1
        hold on;
    end
    temppercFlu=sortdata.percFlu(:,q+repnum*(currentREC-1),currentROI,currentSTM);
    if sortdata.outlierflag(currentROI,q+repnum*(currentREC-1),currentSTM)
        plot(xtime,temppercFlu,'--');
    else
        plot(xtime,temppercFlu);
    end
end
hold on;
maxvalue=max(max(sortdata.percFlu(:,:,currentROI,currentSTM)));
minvalue=min(min(sortdata.percFlu(:,:,currentROI,currentSTM)));
plot([pretrigframe+1 pretrigframe+1], [minvalue  maxvalue], '--r', 'linewidth', 1); 
plot([stimendframe stimendframe], [minvalue  maxvalue], '--r', 'linewidth', 1);

% plot the tuning of first ROI in fighandles.tuningaxes; plot a line at the
% current STM
tuning=zeros(1,sortdata.uniquestimnum);
for i=1:sortdata.uniquestimnum
    outlierflag_stim=squeeze(sortdata.outlierflag(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
%     percFlu_amp_stim=squeeze(sortdata.percFlu_amp(currentROI,1+repnum*(currentREC-1):repnum*currentREC,i));
    percFlu_temp=sortdata.percFlu(:,1+repnum*(currentREC-1):repnum*currentREC,:,:);
    percFlu_ave=mean(percFlu_temp(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames    
    %percFlu_ave=mean(sortdata.percFlu(pretrigframe+1:stimendframe,~outlierflag_stim,currentROI,i),2); % frames
    tuning(i)=max(percFlu_ave); %%%new strategy
%     tuning(i)= mean(percFlu_amp_stim(~outlierflag_stim),2);% roi, rep, stm
end
axes(fighandles.tuningaxes);
hold off;
if sortdata.blankflag
    xvalue=(1:length(tuning))-1;
else
    xvalue=1:length(tuning);
end
plot(xvalue,tuning);
hold on;
plot([xvalue(currentSTM) xvalue(currentSTM)],[min(tuning), max(tuning)],'linewidth', 2);

% display value in the outlierlistbox and set the outlierlistbox for ROI1 & STM1
peak_amp=permute(squeeze(max(sortdata.percFlu(pretrigframe+1:stimendframe,:,:,:),[],1)),[2,1,3]);% ROi,rep,STM
amplitude=[(1:repnum)' squeeze(peak_amp(currentROI,1+(currentREC-1)*repnum:currentREC*repnum,currentSTM))'];
[temp,sortedseq]=sort(amplitude(:,2),1,'descend');
amplitude_sort=amplitude(sortedseq,:); % first colume is the trial#; second is the sorted amp
amplitude_sort_cell = cellstr(num2str(amplitude_sort));
outlierflag_sort=squeeze(sortdata.outlierflag(currentROI,sortedseq+(currentREC-1)*repnum,currentSTM)); % outlierflag: ROI,Rep,STM
set(handles.outlierlistbox, 'Max', size(amplitude_sort,1));
set(handles.outlierlistbox, 'String', amplitude_sort_cell);
set(handles.outlierlistbox, 'value', find(outlierflag_sort));



% --- Executes during object creation, after setting all properties.
function recordingedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ROIedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ignoreROI.
function ignoreROI_Callback(hObject, eventdata, handles)
% hObject    handle to ignoreROI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sortdata
currentROI=get(handles.ROIslider, 'Value');
currentREC=get(handles.recordingslider, 'Value');
sortdata.ignoreflag(currentROI,currentREC)=~sortdata.ignoreflag(currentROI,currentREC);
set(handles.ignoreROI, 'value', sortdata.ignoreflag(currentROI,currentREC));


% --- Executes on button press in badprep.
function badprep_Callback(hObject, eventdata, handles)
% hObject    handle to badprep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sortdata
sortdata.virusExp=~sortdata.virusExp; % 0, bad; 1, good expression
set(handles.badprep, 'value',~sortdata.virusExp); 
% Hint: get(hObject,'Value') returns toggle state of badprep



function frameoffset_end_Callback(hObject, eventdata, handles)
% hObject    handle to frameoffset_end (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of frameoffset_end as text
%        str2double(get(hObject,'String')) returns contents of frameoffset_end as a double


% --- Executes during object creation, after setting all properties.
function frameoffset_end_CreateFcn(hObject, eventdata, handles)
% hObject    handle to frameoffset_end (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

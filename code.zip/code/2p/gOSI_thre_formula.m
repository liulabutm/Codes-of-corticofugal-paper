function gOSI_thre_test=gOSI_thre_formula(j)
    gOSI_thre_test=0.01+(j-1)*0.01;

end

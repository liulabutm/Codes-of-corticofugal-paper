opt_area.err        = 'std';
opt_area.FaceAlpha  = 0.5;
opt_area.Color      = [128 193 219;
                       243 169 114]./255;
opt_lines.LineWidth = 2;
opt_lines.LineStyle = '-';
opt_lines.Marker    = 'none';
opt_lines.Labels    = true;
opt_lines.Legend    = {'dataA','dataB'};
opt_lines.Color     = [ 52 148 186;
                      236 112  22]./255;
                  
opt_axes.Background = 'w';
opt_axes.Labels     = {'lbl1','lbl2','lbl3','lbl4','lbl5'};
    
d_ex = [2 3; 1 0; 0.1 3; -1 7; -0.2 0.9];
data = cat(3,d_ex-0.5,d_ex,d_ex+0.7);

polygonplot(data,opt_axes,opt_lines,opt_area);
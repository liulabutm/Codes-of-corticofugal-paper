clear all
%load amp for each trial
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath
globalpara;

saveflag=1;
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         %good=1, bad=0, control=2
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end

ampMethod= 'peak';   %'peak' or 'integration'

for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repeatflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\peak\sortdata.mat']);
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=sortdata.recordnum;
    repnum=sortdata.repnum;
    
    %calculate DSI/gOSI
    if blankflag
        respn=sortdata.AVE_peak_perc(:,:,2:end);  %direction response
        uniquestim=sortdata.uniquestim(2:end);
    else
        respn=sortdata.AVE_peak_perc;
        uniquestim=sortdata.uniquestim;
    end
    
    respn_ori=zeros(size(respn,1),size(respn,2),size(respn,3)/2);
    for k=1:size(uniquestim,1)/2
        respn_ori(:,:,k)=(respn(:,:,k)+respn(:,:,k+size(respn,3)/2))/2;
    end  
    
    
    for k=1:ROInum
        for p=1:recordnum
            [amp(k,p),prefdirind(k,p)]=max(respn(k,p,:));
            if prefdirind(k,p)<= size(uniquestim,1)/2
                oppo_dir_ind(k,p)= prefdirind(k,p)+size(uniquestim,1)/2;
            else 
                oppo_dir_ind(k,p)= prefdirind(k,p)-size(uniquestim,1)/2;
            end
            [amp(k,p),preforiind(k,p)]=max(respn_ori(k,p,:));
            if preforiind(k,p)<= size(respn_ori,3)/2
                orth_ori_ind(k,p)= preforiind(k,p)+size(respn_ori,3)/2;
            else 
                orth_ori_ind(k,p)= preforiind(k,p)-size(respn_ori,3)/2;
            end
        end
    end  
    uniquestim_radian=uniquestim*pi/180;
    DSI = zeros(ROInum,recordnum);
    OSI = zeros(ROInum,recordnum);
    globalOSI = zeros(ROInum,recordnum);
    globalDSI = zeros(ROInum,recordnum);
    for k=1:ROInum
        for p=1:recordnum           
            DSI(k,p)= (respn(k,p,prefdirind(k,p)) - respn(k,p,oppo_dir_ind(k,p)) ) / (respn(k,p,prefdirind(k,p)) + respn(k,p,oppo_dir_ind(k,p)) );
            OSI(k,p)= (respn_ori(k,p,preforiind(k,p)) - respn_ori(k,p,orth_ori_ind(k,p)) ) / (respn_ori(k,p,preforiind(k,p)) + respn_ori(k,p,orth_ori_ind(k,p)) );
            globalOSI(k,p)=gOSI(squeeze(respn(k,p,:)));
            globalDSI(k,p)=gDSI(squeeze(respn(k,p,:)));            
        end
    end  
    sortdata.DSI=DSI;
    sortdata.OSI=OSI;
    sortdata.globalDSI=globalDSI;
    sortdata.globalOSI=globalOSI;
    if saveflag
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
        %save([calpath sitename '\' ampMethod '\calFoutput.mat'],'calFoutput');    
    end
    
    
    
    % load amplitude, DSI, OSI, selectROI
    if blankflag
        AVEpercFlu_amp_temp=sortdata.AVE_peak_perc(:,:,2:end);
    else
        AVEpercFlu_amp_temp=sortdata.AVE_peak_perc;
    end
    if f==1
        if repeatflag
            ampload_ave_peak=AVEpercFlu_amp_temp;
            prefdir_peak_load=sortdata.prefdir_ave_peak;
            selectROI_load=sortdata.selectROI_outlier;
            DSI_load=sortdata.DSI;
            gOSI_load=sortdata.globalOSI;
        else
            if VLflag
                ampload_ave_peak(:,1,:)=AVEpercFlu_amp_temp(:,1,:);
                ampload_ave_peak(:,3,:)=AVEpercFlu_amp_temp(:,2,:);
                prefdir_peak_load(:,1)=sortdata.prefdir_ave_peak(:,1);
                prefdir_peak_load(:,3)=sortdata.prefdir_ave_peak(:,2);
                selectROI_load(:,1)=sortdata.selectROI_outlier(:,1);
                selectROI_load(:,3)=sortdata.selectROI_outlier(:,2);
                DSI_load(:,1)=sortdata.DSI(:,1);
                DSI_load(:,3)=sortdata.DSI(:,2);
                gOSI_load(:,1)=sortdata.globalOSI(:,1);
                gOSI_load(:,3)=sortdata.globalOSI(:,2);
            else
                ampload_ave_peak=zeros(ROInum,3,size(uniquestim,1));
                prefdir_peak_load=zeros(ROInum,3);
                selectROI_load=zeros(ROInum,3);
                DSI_load=zeros(ROInum,3);
                gOSI_load=zeros(ROInum,3);
                ampload_ave_peak(:,1,:)=AVEpercFlu_amp_temp;
                prefdir_peak_load(:,1)=sortdata.prefdir_ave_peak;
                selectROI_load(:,1)=sortdata.selectROI_outlier;
                DSI_load(:,1)=sortdata.DSI;
                gOSI_load(:,1)=sortdata.globalOSI;

            end
        end        
        amploadseq_ave_peak={};
        ROIstart=1;
        ROIend=ROIstart+ROInum-1;
        amploadseq_ave_peak(1,:)={sitename,ROIstart,ROIend,recordnum};
        
        save('E:\two-photon imaging\jiashu\data\plasticity\amploadseq_ave_peak.mat','amploadseq_ave_peak');
        save('E:\two-photon imaging\jiashu\data\plasticity\ampload_ave_peak.mat','ampload_ave_peak');
        save('E:\two-photon imaging\jiashu\data\plasticity\prefdir_peak_load.mat','prefdir_peak_load');
        save('E:\two-photon imaging\jiashu\data\plasticity\selectROI_load.mat','selectROI_load');
        save('E:\two-photon imaging\jiashu\data\plasticity\DSI_load.mat','DSI_load');
        save('E:\two-photon imaging\jiashu\data\plasticity\gOSI_load.mat','gOSI_load');

        
    else
        load('E:\two-photon imaging\jiashu\data\plasticity\amploadseq_ave_peak.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\ampload_ave_peak.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\prefdir_peak_load.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\selectROI_load.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\DSI_load.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\gOSI_load.mat');
      
        if repeatflag
            endnum=size(ampload_ave_peak,1);
            ampload_ave_peak(end+1:(endnum+ROInum),:,:)=AVEpercFlu_amp_temp;  
            prefdir_peak_load(end+1:(endnum+ROInum),:,:)=sortdata.prefdir_ave_peak;
            selectROI_load(end+1:(endnum+ROInum),:,:)=sortdata.selectROI_outlier;
            DSI_load(end+1:(endnum+ROInum),:,:)=sortdata.DSI;
            gOSI_load(end+1:(endnum+ROInum),:,:)=sortdata.globalOSI;

        else
            if VLflag
                endnum=size(ampload_ave_peak,1);
                ampload_ave_peak(endnum+1:(endnum+ROInum),1,:)=AVEpercFlu_amp_temp(:,1,:);
                ampload_ave_peak(endnum+1:(endnum+ROInum),3,:)=AVEpercFlu_amp_temp(:,2,:);
                prefdir_peak_load(endnum+1:(endnum+ROInum),1,:)=sortdata.prefdir_ave_peak(:,1,:);
                prefdir_peak_load(endnum+1:(endnum+ROInum),3,:)=sortdata.prefdir_ave_peak(:,2,:);
                selectROI_load(endnum+1:(endnum+ROInum),1,:)=sortdata.selectROI_outlier(:,1,:);
                selectROI_load(endnum+1:(endnum+ROInum),3,:)=sortdata.selectROI_outlier(:,2,:);
                DSI_load(endnum+1:(endnum+ROInum),1,:)=sortdata.DSI(:,1,:);
                DSI_load(endnum+1:(endnum+ROInum),3,:)=sortdata.DSI(:,2,:);
                gOSI_load(endnum+1:(endnum+ROInum),1,:)=sortdata.globalOSI(:,1,:);
                gOSI_load(endnum+1:(endnum+ROInum),3,:)=sortdata.globalOSI(:,2,:);
            else
                endnum=size(ampload_ave_peak,1);
                ampload_ave_peak(endnum+1:(endnum+ROInum),1,:)=AVEpercFlu_amp_temp(:,:,:);
                prefdir_peak_load(endnum+1:(endnum+ROInum),1,:)=sortdata.prefdir_ave_peak(:,:,:);
                selectROI_load(endnum+1:(endnum+ROInum),1,:)=sortdata.selectROI_outlier(:,:,:);
                DSI_load(endnum+1:(endnum+ROInum),1,:)=sortdata.DSI(:,:,:);
                gOSI_load(endnum+1:(endnum+ROInum),1,:)=sortdata.globalOSI(:,:,:);
            end           
        end        
        ROIstart=amploadseq_ave_peak{end,3}+1;
        ROIend=ROIstart+ROInum-1;        
        amploadseq_ave_peak(end+1,:)={sitename,ROIstart,ROIend,recordnum};
    end
    if saveflag
        save('E:\two-photon imaging\jiashu\data\plasticity\amploadseq_ave_peak.mat','amploadseq_ave_peak');
        save('E:\two-photon imaging\jiashu\data\plasticity\ampload_ave_peak.mat','ampload_ave_peak');
        save('E:\two-photon imaging\jiashu\data\plasticity\prefdir_peak_load.mat','prefdir_peak_load');
        save('E:\two-photon imaging\jiashu\data\plasticity\selectROI_load.mat','selectROI_load');
        save('E:\two-photon imaging\jiashu\data\plasticity\DSI_load.mat','DSI_load');
        save('E:\two-photon imaging\jiashu\data\plasticity\gOSI_load.mat','gOSI_load');
    end
    clearvars -except  ampMethod  calpath moviedataparentpath NPYdataparentpath RunFolderSeq runind saveflag vsparaparentpath 
    close all
end

%%
load('E:\two-photon imaging\jiashu\data\plasticity\amploadseq_ave_peak.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\ampload_ave_peak.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\prefdir_peak_load.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\selectROI_load.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\DSI_load.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\gOSI_load.mat');


%%
%compare plasticity index at TN direction before VL and after VL
seleMethod='both';  % 'both' or 'either' or 'mix'    -> 'mix' means both+only responsive to after



% for i=1:size(ampload_ave_peak,1)
%     temp(i,1,1)=ampload_ave_peak(i,3,1)/ampload_ave_peak(i,1,1);
% end
% [a,b]=min(temp);
% selectROI 4th column=select neuron as long as either before or after is selected
selectROI_load(:,4)=selectROI_load(:,1)|selectROI_load(:,3);
% selectROI 5th column=select neuron when both before or after are selected
selectROI_load(:,5)=selectROI_load(:,1)&selectROI_load(:,3);
% selectROI 6th column=select neuron as long as neuron is selected after plasticity
selectROI_load(:,6)=selectROI_load(:,3);

switch seleMethod
    case 'both'        
        amp=ampload_ave_peak(selectROI_load(:,4)==1,:,:);
    case 'either'
        amp=ampload_ave_peak(selectROI_load(:,5)==1,:,:);
    case 'mix'
        amp=ampload_ave_peak(selectROI_load(:,6)==1,:,:);
end


% TN biasing neurons, how amplitude change in TN direction
figure
for i=1:size(amp,1)
   plst_index(i,:)= (abs(amp(i,3,:))-abs(amp(i,1,:)))./(abs(amp(i,3,:))+abs(amp(i,1,:)));
   plot([1:4],plst_index(i,:),'-o')
   hold on
end


figure
errorbar(1:4,mean(plst_index,1),std(plst_index,1)/sqrt(15))

[temp,prefdirind]=max(squeeze(amp(:,1,:)),[],2);
plst_index_TNbias=[];
plst_index_NTbias=[];
plst_index_UPbias=[];
plst_index_DNbias=[];
plst_index_HORbias=[];
plst_index_VERbias=[];
for i=1:size(plst_index,1)
    if prefdirind(i,1)==1
        plst_index_TNbias(end+1,:)=squeeze(plst_index(i,:));
    elseif prefdirind(i,1)==2
        plst_index_UPbias(end+1,:)=squeeze(plst_index(i,:));
    elseif prefdirind(i,1)==3
        plst_index_NTbias(end+1,:)=squeeze(plst_index(i,:));
    elseif prefdirind(i,1)==4
        plst_index_DNbias(end+1,:)=squeeze(plst_index(i,:));
        
    end
    
end
for i=1:size(plst_index,1)
    if prefdirind(i,1)==1 || prefdirind(i,1)==3
        plst_index_HORbias(end+1,:)=squeeze(plst_index(i,:));
    elseif prefdirind(i,1)==2 || prefdirind(i,1)==4
        plst_index_VERbias(end+1,:)=squeeze(plst_index(i,:));
    end
end
mean(plst_index_TNbias,1)
mean(plst_index_NTbias,1)
mean(plst_index_UPbias,1)
mean(plst_index_DNbias,1)
mean(plst_index_HORbias,1)
mean(plst_index_VERbias,1)

figure
errorbar([1,2,3,4],[mean(plst_index_HORbias(:,1),1),mean(plst_index_VERbias(:,1),1),mean(plst_index_TNbias(:,1),1),mean(plst_index_NTbias(:,1),1)],[std(plst_index_HORbias(:,1))/sqrt(size(plst_index_HORbias,1)),std(plst_index_VERbias(:,1))/sqrt(size(plst_index_VERbias,1)),std(plst_index_TNbias(:,1))/sqrt(size(plst_index_TNbias,1)),std(plst_index_NTbias(:,1))/sqrt(size(plst_index_NTbias,1))])
xlim([0,5])
ylim([-0.25,0.5])

%how amplitude percentage change in TN direction

for i=1:size(amp,1)
   perc_change(i,:)= (amp(i,3,:)-amp(i,1,:))./amp(i,1,:);
   
end



perc_TNbias=[];
perc_NTbias_old=[];
perc_UPbias_old=[];
perc_DNbias_old=[];
perc_HORbias=[];
perc_VERbias=[];
for i=1:size(perc_change,1)
    if prefdirind(i,1)==1
        perc_TNbias(end+1,:)=squeeze(perc_change(i,:));
    elseif prefdirind(i,1)==2
        perc_UPbias_old(end+1,:)=squeeze(perc_change(i,:));
    elseif prefdirind(i,1)==3
        perc_NTbias_old(end+1,:)=squeeze(perc_change(i,:));
    elseif prefdirind(i,1)==4
        perc_DNbias_old(end+1,:)=squeeze(perc_change(i,:));
        
    end
    
end
NT_outlier=[12,30,32];
UP_outlier=29;
DN_outlier=[13,23,26,31,38];

perc_UPbias=perc_UPbias_old([1:28,30:41],:);
perc_NTbias=perc_NTbias_old([1:11,13:29,31,33:43],:);
perc_DNbias=perc_DNbias_old([1:12,14:22,24:25,27:30,32:37,39:end],:);

perc_HORbias=[perc_TNbias;perc_NTbias];
perc_VERbias=[perc_UPbias;perc_DNbias];
figure
errorbar([1,2,3,4],[mean(perc_TNbias(:,1),1),mean(perc_UPbias(:,1),1),mean(perc_NTbias(:,1),1),mean(perc_DNbias(:,1),1)],[std(perc_TNbias(:,1))/sqrt(size(perc_TNbias,1)),std(perc_UPbias(:,1))/sqrt(size(perc_UPbias,1)),std(perc_NTbias(:,1))/sqrt(size(perc_NTbias,1)),std(perc_DNbias(:,1))/sqrt(size(perc_DNbias,1))])
xlim([0,5])

figure
errorbar([1,2,3,4],[mean(plst_index_TNbias(:,2),1),mean(plst_index_UPbias(:,2),1),mean(plst_index_NTbias(:,2),1),mean(plst_index_DNbias(:,2),1)],[std(plst_index_TNbias(:,2))/sqrt(size(plst_index_TNbias,1)),std(plst_index_UPbias(:,2))/sqrt(size(plst_index_UPbias,1)),std(plst_index_NTbias(:,2))/sqrt(size(plst_index_NTbias,1)),std(plst_index_DNbias(:,2))/sqrt(size(plst_index_DNbias,1))])
xlim([0,5])
ylim([-0.25,0.5])
title('UP direction plst index of diff bias populations')

figure
errorbar([1,2,3,4],[mean(plst_index_TNbias(:,4),1),mean(plst_index_UPbias(:,4),1),mean(plst_index_NTbias(:,4),1),mean(plst_index_DNbias(:,4),1)],[std(plst_index_TNbias(:,4))/sqrt(size(plst_index_TNbias,1)),std(plst_index_UPbias(:,4))/sqrt(size(plst_index_UPbias,1)),std(plst_index_NTbias(:,4))/sqrt(size(plst_index_NTbias,1)),std(plst_index_DNbias(:,4))/sqrt(size(plst_index_DNbias,1))])
xlim([0,5])
ylim([-0.25,0.5])
title('DOWN direction plst index of diff bias populations')
%%
%compare before VL and after VL
seleMethod='mix';  % 'both' or 'either' or 'mix'    -> 'mix' means both+only responsive to after



for i=1:size(ampload_ave_peak,1)
    temp(i,1,1)=ampload_ave_peak(i,3,1)/ampload_ave_peak(i,1,1);
end
[a,b]=min(temp);
% selectROI 4th column=select neuron as long as either before or after is selected
selectROI_load(:,4)=selectROI_load(:,1)|selectROI_load(:,3);
% selectROI 5th column=select neuron when both before or after are selected
selectROI_load(:,5)=selectROI_load(:,1)&selectROI_load(:,3);
% selectROI 6th column=select neuron as long as neuron is selected after plasticity
selectROI_load(:,6)=selectROI_load(:,3);

switch seleMethod
    case 'both'        
        amp=ampload_ave_peak(selectROI_load(:,4)==1,:,:);
    case 'either'
        amp=ampload_ave_peak(selectROI_load(:,5)==1,:,:);
    case 'mix'
        amp=ampload_ave_peak(selectROI_load(:,6)==1,:,:);
end

 % average 8 orientations and compare the AVEamp
AVEamp=mean(amp,3);
ampcomp_ave_peak.VL.AVEamp=AVEamp;
ampcomp_ave_peak.VL.selectROI=selectROI_load;


% only compare amp of 0 direction
hrz_amp=amp(:,:,1);
ampcomp_ave_peak.VL.hrzamp=hrz_amp;

% only compare amp of 180 direction
NT_amp=amp(:,:,3);
ampcomp_ave_peak.VL.NTamp=NT_amp;

% compare pref direction
prefdir_peak_load_sele=prefdir_peak_load(selectROI_load(:,6)==1,:);
pref_amp=AVEamp;
for i=1:size(pref_amp,1)
    for j=1:size(pref_amp,2)
        %pref_amp(i,j)=amp(i,j,PrefDir(i,j)/45+1);  % no plasticity
        pref_amp(i,j)=amp(i,j,prefdir_peak_load_sele(i,3)/90+1);  % plasticity
    end
end
ampcomp_ave_peak.VL.pref=pref_amp;
save('E:\two-photon imaging\jiashu\data\plasticity\ampcomp_ave_peak.mat','ampcomp_ave_peak');


% plot
%before and after VL
normflag=1;
load('E:\two-photon imaging\jiashu\data\plasticity\ampcomp_ave_peak.mat');
% selectROI 4th column=select neuron as long as either before or after is selected

tempampcomp=ampcomp_ave_peak;
%plot comparison figures

if normflag
    %normalize the amp
    for i=1:size(tempampcomp.VL.AVEamp,1)
        tempampcomp.VL.AVEamp(i,:)=tempampcomp.VL.AVEamp(i,:)/tempampcomp.VL.AVEamp(i,1);
    end

    for i=1:size(tempampcomp.VL.hrzamp,1)
        tempampcomp.VL.hrzamp(i,:)=tempampcomp.VL.hrzamp(i,:)/tempampcomp.VL.hrzamp(i,1);
    end
    
    for i=1:size(tempampcomp.VL.NTamp,1)
        tempampcomp.VL.NTamp(i,:)=tempampcomp.VL.NTamp(i,:)/tempampcomp.VL.NTamp(i,1);
    end
    for i=1:size(tempampcomp.VL.pref,1)
        tempampcomp.VL.pref(i,:)=abs(tempampcomp.VL.pref(i,:))/abs(tempampcomp.VL.pref(i,1));
    end    
    yave=tempampcomp.VL.AVEamp;
    yhorizonori=tempampcomp.VL.hrzamp;
    yNTdir=tempampcomp.VL.NTamp;    
    yprefori=tempampcomp.VL.pref;
else
    yave=ampcomp_ave_peak.VL.AVEamp;
    yhorizonori=ampcomp_ave_peak.VL.hrzamp;
    yNTdir=ampcomp_ave_peak.VL.NTamp;

    yprefori=ampcomp_ave_peak.VL.pref;
end
%average 8 oris
figure;
x=[1;2];
for i=1:size(yave,1)
    plot(x,[yave(i,1),yave(i,3)],'-o');
     hold on;
end
xlim([0,3])
xticks([0 1 2 3])
xticklabels({' ','before','after',' '})
title(['amp changes/ave 8 dir/bef aft ']);
AVE_yave_aft=mean(yave(:,3));
SEM_yave_aft=std(yave(:,3))/sqrt(size(yave,1));
errorbar([0.5,2.5],[1 AVE_yave_aft],[0 SEM_yave_aft]);
%0 direction
figure;
x=[1;2];
for i=1:size(yhorizonori,1)
    plot(x,[yhorizonori(i,1),yhorizonori(i,3)],'-o'); 
     hold on;
end
xlim([0,3])
xticks([0 1 2 3])
xticklabels({' ','before','after',' '})
title(['amp changes/hrz dir/bef aft  ' ]);

%180 direction
figure;
x=[1;2];
for i=1:size(yNTdir,1)
    plot(x,[yNTdir(i,1),yNTdir(i,3)],'-o'); 
     hold on;
end
xlim([0,3])
xticks([0 1 2 3])
xticklabels({' ','before','after',' '})
title(['amp changes/180 dir/bef aft  ' ]);

%pref direction
figure;
x=[1;2];
for i=1:size(yprefori,1)
    plot(x,[yprefori(i,1),yprefori(i,3)],'-o');    
     hold on;
end
xlim([0,3])
%ylim([0,5])
xticks([0 1 2 3])
xticklabels({' ','before','after',' '})
title(['amp changes/pref dir/bef aft  ' ]);
AVE_yprefori_aft=mean(yprefori(:,3));
SEM_yprefori_aft=std(yprefori(:,3))/sqrt(size(yprefori,1));
errorbar([0.5,2.5],[1 AVE_yprefori_aft],[0 SEM_yprefori_aft]);

%log plot of pref direction
figure;
x=[1;2];
for i=1:size(yprefori,1)
    if yprefori(i,3)<80        
        yprefori_log(i,3)=log10(yprefori(i,3));
        plot(x,[0,yprefori_log(i,3)],'-o');    
        hold on;
    
    end
    
end
xlim([0,3])
%ylim([0,5])
xticks([0 1 2 3])
xticklabels({' ','before','after',' '})
title(['amp changes/pref dir/bef aft  ' ]);
temp=yprefori_log(yprefori_log(:,3)<80,3);
AVE_yprefori_aft=mean(temp);
SEM_yprefori_aft=std(temp)/sqrt(size(temp,1));
errorbar([0.5,2.5],[log10(1) AVE_yprefori_aft],[0 SEM_yprefori_aft]);
% yticks([log10([0.1,0.3,1,2,5,10,30,60])])
% yticklabels({'0,1','0.3','1','2','5','10','30','60'})
% ylim([-1,1.8])
yticks([log10([0.1,0.3,1,2,5,10,30,60])])
yticklabels({'0,1','0.3','1','2','5','10','30','60'})
ylim([-1,1.8])

% save at 'E:\two-photon imaging\jiashu\data\paper figures\plasticity\amp_change_prefdir\projecting amp change'
% t test 
yave=ampcomp_ave_peak.VL.AVEamp;
yhorizonori=ampcomp_ave_peak.VL.hrzamp;
yNTdir=ampcomp_ave_peak.VL.NTamp;

yprefori=ampcomp_ave_peak.VL.pref;
[h_aveaft,p_aveaft] = ttest(yave(:,1),yave(:,3),'Tail','left');
[h_hriaft,p_hriaft] = ttest(yhorizonori(:,1),yhorizonori(:,3),'Tail','left');
[h_NTaft,p_NTaft] = ttest(yNTdir(:,1),yNTdir(:,3),'Tail','left');
[h_prefaft,p_prefaft] = ttest(yprefori(:,1),yprefori(:,3),'Tail','left');

%% divide neurons into TN-preferred group and Non-TN-preferred group, the preference is the one in the after recording
% then check in individual group, how the amplitude changed in all directions

ampload_ave_peak_sele=ampload_ave_peak(selectROI_load(:,3)==1,:,:); % select neurons that are responsive at the after recording
prefdir_sele=prefdir_peak_load(selectROI_load(:,3)==1,:);

% calculate percentage change of amplitude in individual directions
% formula 1 = (aft-bef)/(aft+bef)
% formula 2 = (aft-bef)/ bef
for i=1:size(ampload_ave_peak_sele,1)
    for k=1:size(ampload_ave_peak_sele,3)
        amp_PerChange_formula1(i,k)=(ampload_ave_peak_sele(i,3,k)-ampload_ave_peak_sele(i,1,k))/(abs(ampload_ave_peak_sele(i,3,k))+abs(ampload_ave_peak_sele(i,1,k)));
        %amp_PerChange_formula2(i,k)=(ampload_ave_peak_sele(i,3,k)-ampload_ave_peak_sele(i,1,k))/ampload_ave_peak_sele(i,1,k);

    end
end

% sort neurons based on preferred direction (prefer TN or nonTN)
amp_PerChange_formula1_TN=[];
amp_PerChange_formula1_nonTN=[];
% amp_PerChange_formula2_TN=[];
% amp_PerChange_formula2_nonTN=[];

for i=1:size(prefdir_sele,1)
   if prefdir_sele(i,3)==0 ||  prefdir_sele(i,3)==180
       amp_PerChange_formula1_TN(end+1,:)=amp_PerChange_formula1(i,:);
%        amp_PerChange_formula2_TN(end+1,:)=amp_PerChange_formula2(i,:);
   else
       amp_PerChange_formula1_nonTN(end+1,:)=amp_PerChange_formula1(i,:);
%         amp_PerChange_formula2_nonTN(end+1,:)=amp_PerChange_formula2(i,:);
   end
end

% sort neurons based on preferred direction (prefer 0,90,180,270)
amp_PerChange_formula1_0=[];
amp_PerChange_formula1_90=[];
amp_PerChange_formula1_180=[];
amp_PerChange_formula1_270=[];

% amp_PerChange_formula2_0=[];
% amp_PerChange_formula2_90=[];
% amp_PerChange_formula2_180=[];
% amp_PerChange_formula2_270=[];

for i=1:size(prefdir_sele,1)
   if prefdir_sele(i,3)==0
       amp_PerChange_formula1_0(end+1,:)=amp_PerChange_formula1(i,:);
%        amp_PerChange_formula2_0(end+1,:)=amp_PerChange_formula2(i,:);
   elseif prefdir_sele(i,3)==90
       amp_PerChange_formula1_90(end+1,:)=amp_PerChange_formula1(i,:);
%        amp_PerChange_formula2_90(end+1,:)=amp_PerChange_formula2(i,:);
  elseif prefdir_sele(i,3)==180
       amp_PerChange_formula1_180(end+1,:)=amp_PerChange_formula1(i,:);
%        amp_PerChange_formula2_180(end+1,:)=amp_PerChange_formula2(i,:);
  elseif prefdir_sele(i,3)==270
       amp_PerChange_formula1_270(end+1,:)=amp_PerChange_formula1(i,:);
%        amp_PerChange_formula2_270(end+1,:)=amp_PerChange_formula2(i,:);

   end
end

%ttest one sample compare to 0
[h_pref0,p_pref0]=ttest(amp_PerChange_formula1_0);
[h_pref90,p_pref90]=ttest(amp_PerChange_formula1_90);
[h_pref180,p_pref180]=ttest(amp_PerChange_formula1_180);
[h_pref270,p_pref270]=ttest(amp_PerChange_formula1_270);
[h_prefHor,p_prefHor]=ttest(amp_PerChange_formula1_TN);
[h_prefVer,p_prefVer]=ttest(amp_PerChange_formula1_nonTN);

% plot  formula 1, pref 0
ave_amp_PerChange_formula1_0=mean(amp_PerChange_formula1_0,1);
sem_amp_PerChange_formula1_0=std(amp_PerChange_formula1_0,1)/sqrt(size(amp_PerChange_formula1_0,1));

figure
for j=1:size(amp_PerChange_formula1_0,2)
    for i=1:size(amp_PerChange_formula1_0,1)    
        plot(j,amp_PerChange_formula1_0(i,j),'-o','Color','k')
        hold on
    end
    errorbar(j,ave_amp_PerChange_formula1_0(1,j),sem_amp_PerChange_formula1_0(1,j),'^','MarkerSize',10,'Color','b')
end
ylim([-0.4,0.4])
title('pref 0 Percent = -/+')

% plot formula 1, pref 90
ave_amp_PerChange_formula1_90=mean(amp_PerChange_formula1_90,1);
sem_amp_PerChange_formula1_90=std(amp_PerChange_formula1_90,1)/sqrt(size(amp_PerChange_formula1_90,1));

figure
for j=1:size(amp_PerChange_formula1_90,2)
    for i=1:size(amp_PerChange_formula1_90,1)    
        plot(j,amp_PerChange_formula1_90(i,j),'-o','Color','k')
        hold on
    end
    errorbar(j,ave_amp_PerChange_formula1_90(1,j),sem_amp_PerChange_formula1_90(1,j),'^','MarkerSize',10,'Color','b')
end
ylim([-0.4,0.4])

title('pref 90 Percent = -/+')

% plot formula 1, pref 180
ave_amp_PerChange_formula1_180=mean(amp_PerChange_formula1_180,1);
sem_amp_PerChange_formula1_180=std(amp_PerChange_formula1_180,1)/sqrt(size(amp_PerChange_formula1_180,1));

figure
for j=1:size(amp_PerChange_formula1_180,2)
    for i=1:size(amp_PerChange_formula1_180,1)    
        plot(j,amp_PerChange_formula1_180(i,j),'-o','Color','k')
        hold on
    end
    errorbar(j,ave_amp_PerChange_formula1_180(1,j),sem_amp_PerChange_formula1_180(1,j),'^','MarkerSize',10,'Color','b')
end
ylim([-0.4,0.4])

title('pref 180 Percent = -/+')


% plot formula 1, pref 270
ave_amp_PerChange_formula1_270=mean(amp_PerChange_formula1_270,1);
sem_amp_PerChange_formula1_270=std(amp_PerChange_formula1_270,1)/sqrt(size(amp_PerChange_formula1_270,1));

figure
for j=1:size(amp_PerChange_formula1_270,2)
    for i=1:size(amp_PerChange_formula1_270,1)    
        plot(j,amp_PerChange_formula1_270(i,j),'-o','Color','k')
        hold on
    end
    errorbar(j,ave_amp_PerChange_formula1_270(1,j),sem_amp_PerChange_formula1_270(1,j),'^','MarkerSize',10,'Color','b')
end
ylim([-0.4,0.4])

title('pref 270 Percent = -/+')

% plot 0 degree amp change only for all groups
figure
for i=1:size(amp_PerChange_formula1_0,1)
    plot(1,amp_PerChange_formula1_0(i,1),'-o','Color','k')
    hold on    
end
errorbar(1,ave_amp_PerChange_formula1_0(1,1),sem_amp_PerChange_formula1_0(1,1),'^','MarkerSize',10,'Color','b')
hold on
for i=1:size(amp_PerChange_formula1_90,1)
    plot(2,amp_PerChange_formula1_90(i,1),'-o','Color','k')
    hold on    
end
errorbar(2,ave_amp_PerChange_formula1_90(1,1),sem_amp_PerChange_formula1_90(1,1),'^','MarkerSize',10,'Color','b')
hold on
for i=1:size(amp_PerChange_formula1_180,1)
    plot(3,amp_PerChange_formula1_180(i,1),'-o','Color','k')
    hold on    
end
errorbar(3,ave_amp_PerChange_formula1_180(1,1),sem_amp_PerChange_formula1_180(1,1),'^','MarkerSize',10,'Color','b')
hold on
for i=1:size(amp_PerChange_formula1_270,1)
    plot(4,amp_PerChange_formula1_270(i,1),'-o','Color','k')
    hold on    
end
errorbar(4,ave_amp_PerChange_formula1_270(1,1),sem_amp_PerChange_formula1_270(1,1),'^','MarkerSize',10,'Color','b')
hold on
xlim([0.5 4.5])
xticks([ 1 2 3 4 ])
xticklabels({ '0','90','180','270'})
title('all neuron in TN amp change')
% % plot  formula 2, pref 0
% ave_amp_PerChange_formula2_0=mean(amp_PerChange_formula2_0,1);
% sem_amp_PerChange_formula2_0=std(amp_PerChange_formula2_0,1)/sqrt(size(amp_PerChange_formula2_0,1));
% 
% figure
% for j=1:size(amp_PerChange_formula2_0,2)
%     for i=1:size(amp_PerChange_formula2_0,1)    
%         plot(j,amp_PerChange_formula2_0(i,j),'-o','Color','k')
%         hold on
%     end
%     errorbar(j,ave_amp_PerChange_formula2_0(1,j),sem_amp_PerChange_formula2_0(1,j),'^','MarkerSize',10,'Color','b')
% end
% title('pref 0 Percent = -/bef')
% 
% % plot formula 2, pref 90
% ave_amp_PerChange_formula2_90=mean(amp_PerChange_formula2_90,1);
% sem_amp_PerChange_formula2_90=std(amp_PerChange_formula2_90,1)/sqrt(size(amp_PerChange_formula2_90,1));
% 
% figure
% for j=1:size(amp_PerChange_formula2_90,2)
%     for i=1:size(amp_PerChange_formula2_90,1)    
%         plot(j,amp_PerChange_formula2_90(i,j),'-o','Color','k')
%         hold on
%     end
%     errorbar(j,ave_amp_PerChange_formula2_90(1,j),sem_amp_PerChange_formula2_90(1,j),'^','MarkerSize',10,'Color','b')
% end
% title('pref 90 Percent = -/bef')
% 
% % plot formula 2, pref 180
% ave_amp_PerChange_formula2_180=mean(amp_PerChange_formula2_180,1);
% sem_amp_PerChange_formula2_180=std(amp_PerChange_formula2_180,1)/sqrt(size(amp_PerChange_formula2_180,1));
% 
% figure
% for j=1:size(amp_PerChange_formula2_180,2)
%     for i=1:size(amp_PerChange_formula2_180,1)    
%         plot(j,amp_PerChange_formula2_180(i,j),'-o','Color','k')
%         hold on
%     end
%     errorbar(j,ave_amp_PerChange_formula2_180(1,j),sem_amp_PerChange_formula2_180(1,j),'^','MarkerSize',10,'Color','b')
% end
% title('pref 180 Percent = -/bef')
% 
% 
% % plot formula 2, pref 270
% ave_amp_PerChange_formula2_270=mean(amp_PerChange_formula2_270,1);
% sem_amp_PerChange_formula2_270=std(amp_PerChange_formula2_270,1)/sqrt(size(amp_PerChange_formula2_270,1));
% 
% figure
% for j=1:size(amp_PerChange_formula2_270,2)
%     for i=1:size(amp_PerChange_formula2_270,1)    
%         plot(j,amp_PerChange_formula2_270(i,j),'-o','Color','k')
%         hold on
%     end
%     errorbar(j,ave_amp_PerChange_formula2_270(1,j),sem_amp_PerChange_formula2_270(1,j),'^','MarkerSize',10,'Color','b')
% end
% title('pref 270 Percent = -/bef')


% plot  formula 1, pref horizontal
ave_amp_PerChange_formula1_TN=mean(amp_PerChange_formula1_TN,1);
sem_amp_PerChange_formula1_TN=std(amp_PerChange_formula1_TN,1)/sqrt(size(amp_PerChange_formula1_TN,1));

figure
for j=1:size(amp_PerChange_formula1_TN,2)
    for i=1:size(amp_PerChange_formula1_TN,1)    
        plot(j,amp_PerChange_formula1_TN(i,j),'-o','Color','k')
        hold on
    end
    errorbar(j,ave_amp_PerChange_formula1_TN(1,j),sem_amp_PerChange_formula1_TN(1,j),'^','MarkerSize',10,'Color','b')
end
title('pref TN Percent = -/+')

% plot  formula 1, pref vertical
ave_amp_PerChange_formula1_nonTN=mean(amp_PerChange_formula1_nonTN,1);
sem_amp_PerChange_formula1_nonTN=std(amp_PerChange_formula1_nonTN,1)/sqrt(size(amp_PerChange_formula1_nonTN,1));

figure
for j=1:size(amp_PerChange_formula1_nonTN,2)
    for i=1:size(amp_PerChange_formula1_nonTN,1)    
        plot(j,amp_PerChange_formula1_nonTN(i,j),'-o','Color','k')
        hold on
    end
    errorbar(j,ave_amp_PerChange_formula1_nonTN(1,j),sem_amp_PerChange_formula1_nonTN(1,j),'^','MarkerSize',10,'Color','b')
end
title('pref nonTN Percent = -/+')

% 
% % plot  formula 2, pref TN
% ave_amp_PerChange_formula2_TN=mean(amp_PerChange_formula2_TN,1);
% sem_amp_PerChange_formula2_TN=std(amp_PerChange_formula2_TN,1)/sqrt(size(amp_PerChange_formula2_TN,1));
% 
% figure
% for j=1:size(amp_PerChange_formula2_TN,2)
%     for i=1:size(amp_PerChange_formula2_TN,1)    
%         plot(j,amp_PerChange_formula2_TN(i,j),'-o','Color','k')
%         hold on
%     end
%     errorbar(j,ave_amp_PerChange_formula2_TN(1,j),sem_amp_PerChange_formula2_TN(1,j),'^','MarkerSize',10,'Color','b')
% end
% title('pref TN Percent = -/bef')
% 
% % plot  formula 2, pref nonTN
% ave_amp_PerChange_formula2_nonTN=mean(amp_PerChange_formula2_nonTN,1);
% sem_amp_PerChange_formula2_nonTN=std(amp_PerChange_formula2_nonTN,1)/sqrt(size(amp_PerChange_formula2_nonTN,1));
% 
% figure
% for j=1:size(amp_PerChange_formula2_nonTN,2)
%     for i=1:size(amp_PerChange_formula2_nonTN,1)    
%         plot(j,amp_PerChange_formula2_nonTN(i,j),'-o','Color','k')
%         hold on
%     end
%     errorbar(j,ave_amp_PerChange_formula2_nonTN(1,j),sem_amp_PerChange_formula2_nonTN(1,j),'^','MarkerSize',10,'Color','b')
% end
% title('pref nonTN Percent = -/bef')

%% Wilcoxon signed rank test to test horizontal and vertical pref. PNs different to 0

[p_Hor,h_Hor] = signrank(amp_PerChange_formula1_TN(:,1),0,'Tail','right');
[p_Ver,h_Ver] = signrank(amp_PerChange_formula1_nonTN(:,1),0,'Tail','right');

[p_TNvsNT,h_TNvsNT] = ranksum(amp_PerChange_formula1_0(:,1),amp_PerChange_formula1_180(:,1),'Tail','right');

%% plot bef and aft prefer direction

seleMethod='mix';  % 'both' or 'either' or 'mix'    -> 'mix' means both+only responsive to after
% selectROI 4th column=select neuron as long as either before or after is selected
selectROI_load(:,4)=selectROI_load(:,1)|selectROI_load(:,3);
% selectROI 5th column=select neuron when both before or after are selected
selectROI_load(:,5)=selectROI_load(:,1)&selectROI_load(:,3);
% selectROI 6th column=select neuron as long as neuron is selected after plasticity
selectROI_load(:,6)=selectROI_load(:,3);


switch seleMethod
    case 'both'
        prefdir_select_ind=prefdir_peak_load(selectROI_load(:,4)==1,:)/90+1;
    case 'mix'
        prefdir_select_ind=prefdir_peak_load(selectROI_load(:,6)==1,:)/90+1;

    case 'either'
        prefdir_select_ind=prefdir_peak_load(selectROI_load(:,5)==1,:)/90+1;
       
end
randomvaluex=rand(size(prefdir_select_ind,1),1)/5-0.05;
randomvaluey=rand(size(prefdir_select_ind,1),1)/5-0.05;

figure
for i=1:size(prefdir_select_ind,1)
    plot (prefdir_select_ind(i,1)+randomvaluex(i,1),prefdir_select_ind(i,3)+randomvaluey(i,1),'-o','Color','k')
    hold on
end
xticks([0 1 2 3 4 5])
xticklabels({' ', '0','90','180','270',' '})
xlabel('prefer dir before')
yticks([0 1 2 3 4 5])
yticklabels({' ', '0','90','180','270',' '})
ylabel('prefer dir after')

% histgram
binhistcata_dir=[0.5 1.5 2.5 3.5 4.5];
figure;
histogram(prefdir_select_ind(:,1),binhistcata_dir,'Normalization', 'probability');
title('before')
xticks([0 90 180 270])
figure;
histogram(prefdir_select_ind(:,3),binhistcata_dir,'Normalization', 'probability');
title('after')
xticks([0 90 180 270])


%% correlation of OKR plasticity and Amp change (averaged by each recording)
clear all
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath
globalpara;

seleMethod='mix';  % 'both' or 'either' or 'mix'    -> 'mix' means both+only responsive to after
percMethod=1;  % 1= (aft-bef)/(abs(aft)+abs(bef))   2= (aft-bef)/abs(bef)
saveflag=1;
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         %good=1, bad=0, control=2
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq_final.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end

ampMethod= 'peak';   %'peak' or 'integration'

for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repeatflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\peak\sortdata.mat']);
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=sortdata.recordnum;
    repnum=sortdata.repnum;

    if blankflag
        AVEpercFlu_amp_temp=sortdata.AVE_peak_perc(:,:,2:end);
        uniquestim=sortdata.uniquestim(2:end);
    else
        AVEpercFlu_amp_temp=sortdata.AVE_peak_perc;
        uniquestim=sortdata.uniquestim;
    end
    
    for i=1:ROInum        
        for k=1:size(AVEpercFlu_amp_temp,3)
            if percMethod==1
                Amp_PercChange(i,k)=(AVEpercFlu_amp_temp(i,end,k)-AVEpercFlu_amp_temp(i,1,k))/(abs(AVEpercFlu_amp_temp(i,end,k))+abs(AVEpercFlu_amp_temp(i,1,k)));
            elseif percMethod==2
                Amp_PercChange(i,k)=(AVEpercFlu_amp_temp(i,end,k)-AVEpercFlu_amp_temp(i,1,k))/abs(AVEpercFlu_amp_temp(i,1,k));
            end
        end        
    end
    

    selectROI_outlier=sortdata.selectROI_outlier;
    % selectROI 4th column=select neuron as long as either before or after is selected
    selectROI_outlier(:,4)=selectROI_outlier(:,1)|selectROI_outlier(:,2);
    % selectROI 5th column=select neuron when both before or after are selected
    selectROI_outlier(:,5)=selectROI_outlier(:,1)&selectROI_outlier(:,2);
    % selectROI 6th column=select neuron as long as neuron is selected after plasticity
    selectROI_outlier(:,6)=selectROI_outlier(:,2);
    tempAmpPerc=[];
    switch seleMethod
        case 'both'
            for i=1:ROInum
                if selectROI_outlier(i,5)==1 && sortdata.DSI(i,1)>=0.1 && sortdata.DSI(i,2)>=0.1
                    tempAmpPerc(end+1,:)=Amp_PercChange(i,:);                   
                end
            end
        case 'either'
            for i=1:ROInum
                if selectROI_outlier(i,4)==1 && (sortdata.DSI(i,1)>=0.1 || sortdata.DSI(i,2)>=0.1)
                    tempAmpPerc(end+1,:)=Amp_PercChange(i,:);
                end
             end
        case 'mix'
            for i=1:ROInum
                if selectROI_outlier(i,6)==1 && sortdata.DSI(i,2)>=0.1 
                    tempAmpPerc(end+1,:)=Amp_PercChange(i,:);
                end
            end
    end
    
    amp_rm_outlier = isoutlier(tempAmpPerc,'quartiles');
    temp=sum(amp_rm_outlier,2);
    amp_rm_outlierflag=zeros(size(amp_rm_outlier,1),1);
    for i=1:size(amp_rm_outlier,1)
        if temp(i,1)~=0
            amp_rm_outlierflag(i,1)=1;
        end
    end
    %Ave_Amp_PercChange=mean(tempAmpPerc,1);
    Ave_Amp_PercChange=mean(tempAmpPerc(~amp_rm_outlierflag,:),1);
    sortdata.Ave_Amp_PercChange=Ave_Amp_PercChange;
    if saveflag
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
        %save([calpath sitename '\' ampMethod '\calFoutput.mat'],'calFoutput');    
    end
    OKR_plst=sortdata.OKR_plst;
    
    if f==1
       
        OKR_plst_load(f,1)=OKR_plst;
        Ave_Amp_PercChange_load(f,:)=Ave_Amp_PercChange;
        correlation_loadseq={};
        ROIstart=1;
        ROIend=ROIstart+ROInum-1;
        correlation_loadseq(1,:)={sitename,ROIstart,ROIend,recordnum};
        
        save('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat','correlation_loadseq');
        save('E:\two-photon imaging\jiashu\data\plasticity\Ave_Amp_PercChange_load.mat','Ave_Amp_PercChange_load');
        save('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat','OKR_plst_load');
       

        
    else
        load('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\Ave_Amp_PercChange_load.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat');
             
       
        OKR_plst_load(f,1)=OKR_plst;
        Ave_Amp_PercChange_load(f,1:4)=Ave_Amp_PercChange;
        ROIstart=correlation_loadseq{end,3}+1;
        ROIend=ROIstart+ROInum-1;        
        correlation_loadseq(end+1,:)={sitename,ROIstart,ROIend,recordnum};
    end
    
    save('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat','correlation_loadseq');
    save('E:\two-photon imaging\jiashu\data\plasticity\Ave_Amp_PercChange_load.mat','Ave_Amp_PercChange_load');
    save('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat','OKR_plst_load');

    clearvars -except percMethod uniquestim seleMethod ampMethod  calpath moviedataparentpath NPYdataparentpath RunFolderSeq runind saveflag vsparaparentpath 

end

%
load('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\Ave_Amp_PercChange_load.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat');

%
b=correlation_loadseq(:,1)';

for k=1:size(Ave_Amp_PercChange_load,2)
   figure
   for i=1:size(Ave_Amp_PercChange_load,1)
       if i>size(Ave_Amp_PercChange_load,1)-9
           plot(Ave_Amp_PercChange_load(i,k),OKR_plst_load(i,1),'-o','Color','b')
       else
           plot(Ave_Amp_PercChange_load(i,k),OKR_plst_load(i,1),'-o','Color','k')
       end
      hold on
      text(Ave_Amp_PercChange_load(i,k)+0.01,OKR_plst_load(i,1)+0.01,num2str(i),'FontSize', 10)
   end
   xlabel( 'Amp change' )
   ylabel('OKR plasticity')
   title(['dir ' num2str(uniquestim(k))])
   legend(b)
   legend off
end

for k=1:size(Ave_Amp_PercChange_load,2)
    
   figure
    temp(:,2)=Ave_Amp_PercChange_load(:,k);
   temp(:,1)=OKR_plst_load(:,1);
   [R,PValue]=corrplot(temp);
   R_load(k,1)=R(1,2);
   PValue_load(k,1)=PValue(1,2);

end

% 
OKR_large=[];
OKR_small=[];
Ave_Amp_PercChange_large=[];
Ave_Amp_PercChange_small=[];
for i=1:size(OKR_plst_load,1)
   if  OKR_plst_load(i,1) >=0.1
      OKR_large(end+1,1)= OKR_plst_load(i,1);
      Ave_Amp_PercChange_large(end+1,1)=Ave_Amp_PercChange_load(i,1);
   else
      OKR_small(end+1,1)= OKR_plst_load(i,1);
      Ave_Amp_PercChange_small(end+1,1)=Ave_Amp_PercChange_load(i,1);
       
   end
end
[h,p]=ttest2(Ave_Amp_PercChange_large,Ave_Amp_PercChange_small,'Tail','Right');
p1=ranksum(Ave_Amp_PercChange_large,Ave_Amp_PercChange_small,'Tail','Right');

% average with error bar for plst or blank group
% 1-17: plasticity; 18-26: blank

% plasticity
mean_PI_plst=mean(Ave_Amp_PercChange_load(1:16,1));
sem_PI_plst=std(Ave_Amp_PercChange_load(1:16,1))/sqrt(16);
mean_OKR_plst=mean(OKR_plst_load(1:16,1));
sem_OKR_plst=std(OKR_plst_load(1:16,1))/sqrt(16);
figure
errorbar(mean_OKR_plst,mean_PI_plst,sem_PI_plst)
title('PI-plst')
xlim([-0.1,0.4])
ylim([-0.2,0.4])
figure
errorbar(mean_PI_plst,mean_OKR_plst,sem_OKR_plst)
title('OKR-plst')
xlim([-0.2,0.4])
ylim([-0.1,0.4])


% blank
mean_PI_blank=mean(Ave_Amp_PercChange_load(17:end,1));
sem_PI_blank=std(Ave_Amp_PercChange_load(17:end,1))/sqrt(9);
mean_OKR_blank=mean(OKR_plst_load(17:end,1));
sem_OKR_blank=std(OKR_plst_load(17:end,1))/sqrt(9);
figure
errorbar(mean_OKR_blank,mean_PI_blank,sem_PI_blank)
title('PI-blank')
xlim([-0.1,0.4])
ylim([-0.2,0.4])
figure
errorbar(mean_PI_blank,mean_OKR_blank,sem_OKR_blank)
title('OKR-blank')
xlim([-0.2,0.4])
ylim([-0.1,0.4])



%% correlation of OKR plasticity and Amp change in neurons that prefer TN (or other directions) (averaged by each recording)
clear all
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath
globalpara;


prefdir_choose=270;


seleMethod='mix';  % 'both' or 'either' or 'mix'    -> 'mix' means both+only responsive to after
saveflag=1;
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         %good=1, bad=0, control=2
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq_final.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end

ampMethod= 'peak';   %'peak' or 'integration'

for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repeatflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\peak\sortdata.mat']);
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=sortdata.recordnum;
    repnum=sortdata.repnum;

    if blankflag
        AVEpercFlu_amp_temp=sortdata.AVE_peak_perc(:,:,2:end);
        uniquestim=sortdata.uniquestim(2:end);
    else
        AVEpercFlu_amp_temp=sortdata.AVE_peak_perc;
        uniquestim=sortdata.uniquestim;
    end
    
    for i=1:ROInum        
        for k=1:size(AVEpercFlu_amp_temp,3)
            Amp_PercChange(i,k)=(AVEpercFlu_amp_temp(i,end,k)-AVEpercFlu_amp_temp(i,1,k))/(abs(AVEpercFlu_amp_temp(i,end,k))+abs(AVEpercFlu_amp_temp(i,1,k)));
        end        
    end
    

    selectROI_outlier=sortdata.selectROI_outlier;
    % selectROI 4th column=select neuron as long as either before or after is selected
    selectROI_outlier(:,4)=selectROI_outlier(:,1)|selectROI_outlier(:,2);
    % selectROI 5th column=select neuron when both before or after are selected
    selectROI_outlier(:,5)=selectROI_outlier(:,1)&selectROI_outlier(:,2);
    % selectROI 6th column=select neuron as long as neuron is selected after plasticity
    selectROI_outlier(:,6)=selectROI_outlier(:,2);
    tempAmpPerc=[];
    switch seleMethod
        case 'both'
            for i=1:ROInum
                if sortdata.prefdir_ave_peak(i,1)==prefdir_choose && selectROI_outlier(i,5)==1 && sortdata.DSI(i,1)>=0.1 && sortdata.DSI(i,2)>=0.1
                    tempAmpPerc(end+1,:)=Amp_PercChange(i,:);                   
                end
            end
        case 'either'
            for i=1:ROInum
                if sortdata.prefdir_ave_peak(i,1)==prefdir_choose && selectROI_outlier(i,4)==1 && (sortdata.DSI(i,1)>=0.1 || sortdata.DSI(i,2)>=0.1)
                    tempAmpPerc(end+1,:)=Amp_PercChange(i,:);
                end
             end
        case 'mix'
            for i=1:ROInum
                if sortdata.prefdir_ave_peak(i,1)==prefdir_choose && selectROI_outlier(i,6)==1 && sortdata.DSI(i,2)>=0.1 
                    tempAmpPerc(end+1,:)=Amp_PercChange(i,:);
                end
            end
    end
    if size(tempAmpPerc,1)~=0
        amp_rm_outlier = isoutlier(tempAmpPerc,'quartiles');
        temp=sum(amp_rm_outlier,2);
        amp_rm_outlierflag=zeros(size(amp_rm_outlier,1),1);
        for i=1:size(amp_rm_outlier,1)
            if temp(i,1)~=0
                amp_rm_outlierflag(i,1)=1;
            end
        end
        %Ave_Amp_PercChange=mean(tempAmpPerc,1);
        Ave_Amp_PercChange=mean(tempAmpPerc(~amp_rm_outlierflag,:),1);

        
    else
        Ave_Amp_PercChange=nan;
        
    end
    sortdata.Ave_Amp_PercChange=Ave_Amp_PercChange;
    if saveflag
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
        %save([calpath sitename '\' ampMethod '\calFoutput.mat'],'calFoutput');    
    end
    OKR_plst=sortdata.OKR_plst;
    
    if f==1
       
        OKR_plst_load(f,1)=OKR_plst;
        Ave_Amp_PercChange_load(f,:)=Ave_Amp_PercChange;
        correlation_loadseq={};
        ROIstart=1;
        ROIend=ROIstart+ROInum-1;
        correlation_loadseq(1,:)={sitename,ROIstart,ROIend,recordnum};
        
        save('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat','correlation_loadseq');
        save('E:\two-photon imaging\jiashu\data\plasticity\Ave_Amp_PercChange_load.mat','Ave_Amp_PercChange_load');
        save('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat','OKR_plst_load');
       

        
    else
        load('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\Ave_Amp_PercChange_load.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat');
             
       
        OKR_plst_load(f,1)=OKR_plst;
        Ave_Amp_PercChange_load(f,1:4)=Ave_Amp_PercChange;
        ROIstart=correlation_loadseq{end,3}+1;
        ROIend=ROIstart+ROInum-1;        
        correlation_loadseq(end+1,:)={sitename,ROIstart,ROIend,recordnum};
    end
    
    save('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat','correlation_loadseq');
    save('E:\two-photon imaging\jiashu\data\plasticity\Ave_Amp_PercChange_load.mat','Ave_Amp_PercChange_load');
    save('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat','OKR_plst_load');

    clearvars -except prefdir_choose uniquestim seleMethod ampMethod  calpath moviedataparentpath NPYdataparentpath RunFolderSeq runind saveflag vsparaparentpath 

end

%
load('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\Ave_Amp_PercChange_load.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat');

%
%b=correlation_loadseq(:,1)';
Ave_Amp_PercChange_load_nonan=[];
OKR_plst_load_nonan=[];
correlation_loadseq_nonan={};
for i=1:size(Ave_Amp_PercChange_load,1)
   if ~isnan(Ave_Amp_PercChange_load(i,1))
       Ave_Amp_PercChange_load_nonan(end+1,:)=Ave_Amp_PercChange_load(i,:);
       OKR_plst_load_nonan(end+1,:)=OKR_plst_load(i,:);
       correlation_loadseq_nonan(end+1,1)=correlation_loadseq(i,1);
   end
end
%Ave_Amp_PercChange_load_nonan(:,:)=Ave_Amp_PercChange_load(~isnan(Ave_Amp_PercChange_load(:,1)),:);

for k=1:size(Ave_Amp_PercChange_load_nonan,2)
   figure
   for i=1:size(Ave_Amp_PercChange_load_nonan,1)
       if i>size(Ave_Amp_PercChange_load_nonan,1)-5
           plot(Ave_Amp_PercChange_load_nonan(i,k),OKR_plst_load_nonan(i,1),'-o','Color','b')
       else
           plot(Ave_Amp_PercChange_load_nonan(i,k),OKR_plst_load_nonan(i,1),'-o','Color','k')
       end
      hold on
      text(Ave_Amp_PercChange_load_nonan(i,k)+0.01,OKR_plst_load_nonan(i,1)+0.01,num2str(i),'FontSize', 10)
   end
   xlabel( 'Amp change' )
   ylabel('OKR plasticity')
   title(['dir ' num2str(uniquestim(k))])
   legend(correlation_loadseq_nonan)
   legend off
end

for k=1:size(Ave_Amp_PercChange_load_nonan,2)
    
   figure
    temp(:,2)=Ave_Amp_PercChange_load_nonan(:,k);
   temp(:,1)=OKR_plst_load_nonan(:,1);
   [R,PValue]=corrplot(temp);
   R_load(k,1)=R(1,2);
   PValue_load(k,1)=PValue(1,2);

end

% 
OKR_large=[];
OKR_small=[];
Ave_Amp_PercChange_large=[];
Ave_Amp_PercChange_small=[];
for i=1:size(OKR_plst_load_nonan,1)
   if  OKR_plst_load_nonan(i,1) >=0.1
      OKR_large(end+1,1)= OKR_plst_load_nonan(i,1);
      Ave_Amp_PercChange_large(end+1,1)=Ave_Amp_PercChange_load_nonan(i,1);
   else
      OKR_small(end+1,1)= OKR_plst_load_nonan(i,1);
      Ave_Amp_PercChange_small(end+1,1)=Ave_Amp_PercChange_load_nonan(i,1);
       
   end
end
[h,p]=ttest2(Ave_Amp_PercChange_large,Ave_Amp_PercChange_small,'Tail','Right');
p1=ranksum(Ave_Amp_PercChange_large,Ave_Amp_PercChange_small,'Tail','Right');


%% correlation of OKR plasticity and DSI change (averaged by each recording)
clear all
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath
globalpara;
DSIthre=0.1;
seleMethod='mix';  % 'both' or 'either' or 'mix'    -> 'mix' means both+only responsive to after
saveflag=1;
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         %good=1, bad=0, control=2
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end

ampMethod= 'peak';   %'peak' or 'integration'

for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repeatflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\peak\sortdata.mat']);
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=sortdata.recordnum;
    repnum=sortdata.repnum;

    if blankflag
        uniquestim=sortdata.uniquestim(2:end);
    else
        uniquestim=sortdata.uniquestim;
    end
        DSI=sortdata.DSI;
        prefdir=sortdata.prefdir_ave_peak(:,end);
    for i=1:ROInum        
        DSI_Change(i,1)=DSI(i,2)-DSI(i,1);
    end


    selectROI_outlier=sortdata.selectROI_outlier;
    % selectROI 4th column=select neuron as long as either before or after is selected
    selectROI_outlier(:,4)=selectROI_outlier(:,1)|selectROI_outlier(:,2);
    % selectROI 5th column=select neuron when both before or after are selected
    selectROI_outlier(:,5)=selectROI_outlier(:,1)&selectROI_outlier(:,2);
    % selectROI 6th column=select neuron as long as neuron is selected after plasticity
    selectROI_outlier(:,6)=selectROI_outlier(:,2);
    tempDSI_Change=[];
    temp_prefdir=[];
    switch seleMethod
        case 'both'
            for i=1:ROInum
                if selectROI_outlier(i,5)==1 && sortdata.DSI(i,1)>=DSIthre && sortdata.DSI(i,2)>=DSIthre
                    tempDSI_Change(end+1,:)=DSI_Change(i,:);                   
                    temp_prefdir(end+1,:)=prefdir(i,:);                   

                end
            end
        case 'either'
            for i=1:ROInum
                if selectROI_outlier(i,4)==1 && (sortdata.DSI(i,1)>=DSIthre || sortdata.DSI(i,2)>=DSIthre)
                    tempDSI_Change(end+1,:)=DSI_Change(i,:);
                    temp_prefdir(end+1,:)=prefdir(i,:);
                end
             end
        case 'mix'
            for i=1:ROInum
                if selectROI_outlier(i,6)==1 && sortdata.DSI(i,2)>=DSIthre 
                    tempDSI_Change(end+1,:)=DSI_Change(i,:);
                    temp_prefdir(end+1,:)=prefdir(i,:);
                end
            end
    end
    
    for k=1:size(uniquestim,1)
        temp=0;
        j=1;
        for i=1:size(temp_prefdir,1)
            if temp_prefdir(i,1)/90+1==k
                temp=temp+tempDSI_Change(i,1);
                j=j+1;
            end
        end
        Ave_DSI_Change(1,k)=temp/(j-1);
    end
    
    
    
    OKR_plst=sortdata.OKR_plst;
    
    if f==1
        DSI_Change_load=[];
        %prefdir_load=[];
        OKR_plst_load=[];
        OKR_plst_load(f,1)=OKR_plst;
        DSI_Change_load(f,:)=Ave_DSI_Change;
       %prefdir_load(end+1:(end+size(tempDSI_Change,1)),:)=temp_prefdir;
        correlation_loadseq={};
        ROIstart=1;
        ROIend=ROIstart+ROInum-1;
        correlation_loadseq(1,:)={sitename,ROIstart,ROIend,recordnum};
        
        save('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat','correlation_loadseq');
        save('E:\two-photon imaging\jiashu\data\plasticity\DSI_Change_load.mat','DSI_Change_load');
       % save('E:\two-photon imaging\jiashu\data\plasticity\prefdir_load.mat','prefdir_load');
        save('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat','OKR_plst_load');
       

        
    else
        load('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat');
       % load('E:\two-photon imaging\jiashu\data\plasticity\prefdir_load.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\DSI_Change_load.mat');
        load('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat');
             
       
        OKR_plst_load(f,1)=OKR_plst;
        DSI_Change_load(f,:)=Ave_DSI_Change;
        %prefdir_load(end+1:(end+size(tempDSI_Change,1)),:)=temp_prefdir;
        ROIstart=correlation_loadseq{end,3}+1;
        ROIend=ROIstart+ROInum-1;        
        correlation_loadseq(end+1,:)={sitename,ROIstart,ROIend,recordnum};
       
        save('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat','correlation_loadseq');
        save('E:\two-photon imaging\jiashu\data\plasticity\DSI_Change_load.mat','DSI_Change_load');
        %save('E:\two-photon imaging\jiashu\data\plasticity\prefdir_load.mat','prefdir_load');
        save('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat','OKR_plst_load');

    end
    


        
    clearvars -except DSIthre uniquestim seleMethod ampMethod  calpath moviedataparentpath NPYdataparentpath RunFolderSeq runind saveflag vsparaparentpath 

end

%
load('E:\two-photon imaging\jiashu\data\plasticity\correlation_loadseq.mat');
%load('E:\two-photon imaging\jiashu\data\plasticity\prefdir_load.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\DSI_Change_load.mat');
load('E:\two-photon imaging\jiashu\data\plasticity\OKR_plst_load.mat');


%
for k=1:size(DSI_Change_load,2)
   figure
   
   for i=1:size(DSI_Change_load,1) 
       if ~isnan(DSI_Change_load(i,k))
           plot(DSI_Change_load(i,k),OKR_plst_load(i,1),'-o','Color','k')
       end
       hold on
   end
   
  
   xlabel( 'DSI change' )
   ylabel('OKR plasticity')
   title(['prefdir ' num2str(uniquestim(k))])
   
end
for k=1:size(DSI_Change_load,2)
    figure   
    temp=[];
    for i=1:size(DSI_Change_load,1) 
       if ~isnan(DSI_Change_load(i,k))
           temp(end+1,1)=DSI_Change_load(i,k);
           temp(end,2)=OKR_plst_load(i,1);
       end
      
   end
    
   [R,PValue]=corrplot(temp);
   R_load(k,1)=R(1,2);
   PValue_load(k,1)=PValue(1,2);
end

%% t-test between plst group and blank group

% amp_PerChange_formula1_0_plst_projecting=amp_PerChange_formula1_0;
% amp_PerChange_formula1_180_plst_projecting=amp_PerChange_formula1_180;
% amp_PerChange_formula1_270_plst_projecting=amp_PerChange_formula1_270;
% amp_PerChange_formula1_90_plst_projecting=amp_PerChange_formula1_90;
% amp_PerChange_formula1_nonTN_plst_projecting=amp_PerChange_formula1_nonTN;
% amp_PerChange_formula1_TN_plst_projecting=amp_PerChange_formula1_TN;
% 
% 
% 
% amp_PerChange_formula1_0_plst_control=amp_PerChange_formula1_0;
% amp_PerChange_formula1_180_plst_control=amp_PerChange_formula1_180;
% amp_PerChange_formula1_270_plst_control=amp_PerChange_formula1_270;
% amp_PerChange_formula1_90_plst_control=amp_PerChange_formula1_90;
% amp_PerChange_formula1_nonTN_plst_control=amp_PerChange_formula1_nonTN;
% amp_PerChange_formula1_TN_plst_control=amp_PerChange_formula1_TN;
% 
% 
% amp_PerChange_formula1_0_blank_control=amp_PerChange_formula1_0;
% amp_PerChange_formula1_180_blank_control=amp_PerChange_formula1_180;
% amp_PerChange_formula1_270_blank_control=amp_PerChange_formula1_270;
% amp_PerChange_formula1_90_blank_control=amp_PerChange_formula1_90;
% amp_PerChange_formula1_nonTN_blank_control=amp_PerChange_formula1_nonTN;
% amp_PerChange_formula1_TN_blank_control=amp_PerChange_formula1_TN;
% 
% amp_PerChange_formula1_0_blank_projecting=amp_PerChange_formula1_0;
% amp_PerChange_formula1_180_blank_projecting=amp_PerChange_formula1_180;
% amp_PerChange_formula1_270_blank_projecting=amp_PerChange_formula1_270;
% amp_PerChange_formula1_90_blank_projecting=amp_PerChange_formula1_90;
% amp_PerChange_formula1_nonTN_blank_projecting=amp_PerChange_formula1_nonTN;
% amp_PerChange_formula1_TN_blank_projecting=amp_PerChange_formula1_TN;
% 

load('E:\two-photon imaging\jiashu\data\paper figures\plasticity\data\plst induce projecting\matlab.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\plasticity\data\blank projecting\matlab.mat')

[h_pref0_amp0_projecting,p_pref0_amp0_projecting]=ttest2(amp_PerChange_formula1_0_plst_projecting(:,1),amp_PerChange_formula1_0_blank_projecting(:,1),'Tail','right');
[h_pref90_amp0_projecting,p_pref90_amp0_projecting]=ttest2(amp_PerChange_formula1_90_plst_projecting(:,1),amp_PerChange_formula1_90_blank_projecting(:,1),'Tail','right');
[h_pref180_amp0_projecting,p_pref180_amp0_projecting]=ttest2(amp_PerChange_formula1_180_plst_projecting(:,1),amp_PerChange_formula1_180_blank_projecting(:,1),'Tail','right');
[h_pref270_amp0_projecting,p_pref270_amp0_projecting]=ttest2(amp_PerChange_formula1_270_plst_projecting(:,1),amp_PerChange_formula1_270_blank_projecting(:,1),'Tail','right');

[h_pref90_amp90_projecting,p_pref90_amp90_projecting]=ttest2(amp_PerChange_formula1_90_plst_projecting(:,2),amp_PerChange_formula1_90_blank_projecting(:,2),'Tail','right');
[h_pref180_amp180_projecting,p_pref180_amp180_projecting]=ttest2(amp_PerChange_formula1_180_plst_projecting(:,3),amp_PerChange_formula1_180_blank_projecting(:,3),'Tail','right');
[h_pref270_amp270_projecting,p_pref270_amp270_projecting]=ttest2(amp_PerChange_formula1_270_plst_projecting(:,4),amp_PerChange_formula1_270_blank_projecting(:,4),'Tail','right');


load('E:\two-photon imaging\jiashu\data\paper figures\plasticity\data\blank control\matlab.mat')
load('E:\two-photon imaging\jiashu\data\paper figures\plasticity\data\plst induce control_brainstem\matlab.mat')
[h_pref0_amp0_control,p_pref0_amp0_control]=ttest2(amp_PerChange_formula1_0_plst_control(:,1),amp_PerChange_formula1_0_blank_control(:,1),'Tail','right');
[h_pref90_amp0_control,p_pref90_amp0_control]=ttest2(amp_PerChange_formula1_90_plst_control(:,1),amp_PerChange_formula1_90_blank_control(:,1),'Tail','right');
[h_pref180_amp0_control,p_pref180_amp0_control]=ttest2(amp_PerChange_formula1_180_plst_control(:,1),amp_PerChange_formula1_180_blank_control(:,1),'Tail','right');
[h_pref270_amp0_control,p_pref270_amp0_control]=ttest2(amp_PerChange_formula1_270_plst_control(:,1),amp_PerChange_formula1_270_blank_control(:,1),'Tail','right');

[h_pref90_amp90_control,p_pref90_amp90_control]=ttest2(amp_PerChange_formula1_90_plst_control(:,2),amp_PerChange_formula1_90_blank_control(:,2),'Tail','right');
[h_pref180_amp180_control,p_pref180_amp180_control]=ttest2(amp_PerChange_formula1_180_plst_control(:,3),amp_PerChange_formula1_180_blank_control(:,3),'Tail','right');
[h_pref270_amp270_control,p_pref270_amp270_control]=ttest2(amp_PerChange_formula1_270_plst_control(:,4),amp_PerChange_formula1_270_blank_control(:,4),'Tail','right');



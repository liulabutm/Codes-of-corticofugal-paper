%% 
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath preferpath
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
%plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
saveflag=1;
%outlier=1;
%ignorecell=1;
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
record_num=1;
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));
changeCalVector=table2cell(readtable([calpath 'ROI_change_prefdir.xlsx']));
runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\calFoutput.mat']);
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
    
    

    sortdata.prefdir_mix=sortdata.prefdir_vec_formula_degree_basedori_new;
    
    
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=size(sortdata.AVEpercFlu_amp,2);
    
   % assign the ROI that need to change method to calculate prefered direction from 'based on ori' method to 'direction vector sum'
    tempind = strfind(changeCalVector(:,1),sitename);   
    for i=1:size(tempind,1)
        if tempind{i}==1            
            ROI_change=str2num(changeCalVector{i,1}((strfind(changeCalVector{i,1},'ROI')+4):end));
            if record_num==1 || 2
                sortdata.prefdir_mix(ROI_change,record_num)=sortdata.perfdir_vec_formula_degree(ROI_change,record_num);    
            elseif record_num==3
                sortdata.prefdir_mix(ROI_change,end)=sortdata.perfdir_vec_formula_degree(ROI_change,end);    
            end
            
        end
    end
    
    % remove ROI based on checking 
    tempind = strfind(changeCalVector(:,2),sitename);
    removeflag_prefdir=zeros(ROInum,recordnum);
    for i=1:size(tempind,1)
        if tempind{i}==1            
            ROI_index=str2num(changeCalVector{i,2}((strfind(changeCalVector{i,2},'ROI')+4):end));
            removeflag_prefdir(ROI_index,1)=1;
        end
    end
    
    sortdata.removeflag_prefdir=removeflag_prefdir;
       
    
    if saveflag
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
        %save([calpath sitename '\' ampMethod '\calFoutput.mat'],'calFoutput');    
    end
    clearvars -except changeCalVector record_num ampMethod baselinemethod saveflag calpath moviedataparentpath preferpath NPYdataparentpath RunFolderSeq RLBflag responsiveflag runind vsparaparentpath ;
    close all
end




%% calculate DSI and OSI based on the prefdir_mix

global NPYdataparentpath moviedataparentpath vsparaparentpath calpath preferpath
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
%plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
saveflag=1;
%outlier=1;
%ignorecell=1;
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\calFoutput.mat']);
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
    if blankflag
        respn=sortdata.AVE_peak_perc(:,:,2:end);  %direction response
        uniquestim=sortdata.uniquestim(2:end);
    else
        respn=sortdata.AVE_peak_perc;
        uniquestim=sortdata.uniquestim;
    end
    
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=size(sortdata.AVEpercFlu_amp,2);
    DSI_new=zeros(ROInum,recordnum);
    
    pref_dir_mix_index=zeros(ROInum,recordnum);
    oppo_dir_mix_index=zeros(ROInum,recordnum);
    for k=1:ROInum
        for p=1:recordnum
             pref_dir_mix_index(k,p)=round(sortdata.prefdir_mix(k,p)/45)+1;
             if pref_dir_mix_index(k,p)==9
                 pref_dir_mix_index(k,p)=1;
             elseif isnan(pref_dir_mix_index(k,p))  % if response is NaN, the cell is not selective cell, but the index must be 1-4 to run the loop, so make the index=1. This does not influence result because it is not selective cell
                 pref_dir_mix_index(k,p)=1;            
             end
             if pref_dir_mix_index(k,p)<= size(uniquestim,1)/2
                oppo_dir_mix_index(k,p)= pref_dir_mix_index(k,p)+size(uniquestim,1)/2;
            else 
                oppo_dir_mix_index(k,p)= pref_dir_mix_index(k,p)-size(uniquestim,1)/2;
            end
             
             %DSI_new(k,p)= (respn(k,p,pref_dir_mix_index(k,p)) - respn(k,p,oppo_dir_mix_index(k,p)) ) / (respn(k,p,pref_dir_mix_index(k,p)) + respn(k,p,oppo_dir_mix_index(k,p)) );
             DSI_new(k,p)= (respn(k,p,pref_dir_mix_index(k,p)) - respn(k,p,oppo_dir_mix_index(k,p)) ) / (abs(respn(k,p,pref_dir_mix_index(k,p))) + abs(respn(k,p,oppo_dir_mix_index(k,p))) );
             if DSI_new(k,p)<0
                 [M,I_peak]=max(respn(k,p,:),[],3);
                 if I_peak <= size(uniquestim,1)/2
                     I_oppo= I_peak+size(uniquestim,1)/2;
                 else 
                     I_oppo= I_peak-size(uniquestim,1)/2;
                 end

                 DSI_new(k,p)=(respn(k,p,I_peak)-respn(k,p,I_oppo))/(abs(respn(k,p,I_peak))+abs(respn(k,p,I_oppo)));
             end
        end
    end
    
    sortdata.DSI_new_abs=DSI_new;
    
    respn_ori=zeros(size(respn,1),size(respn,2),size(respn,3)/2);
    for k=1:size(uniquestim,1)/2
        respn_ori(:,:,k)=(respn(:,:,k)+respn(:,:,k+size(respn,3)/2))/2;
    end  
    
    
    for k=1:ROInum
        for p=1:recordnum
            if pref_dir_mix_index(k,p) <= size(respn_ori,3)
                preforiind(k,p)=pref_dir_mix_index(k,p);
            else
                preforiind(k,p)=pref_dir_mix_index(k,p)-size(respn_ori,3);
            end
            if preforiind(k,p)<= size(respn_ori,3)/2
                orth_ori_ind(k,p)= preforiind(k,p)+size(respn_ori,3)/2;
            else 
                orth_ori_ind(k,p)= preforiind(k,p)-size(respn_ori,3)/2;
            end
            
            OSI_new(k,p)= (respn_ori(k,p,preforiind(k,p)) - respn_ori(k,p,orth_ori_ind(k,p)) ) / (respn_ori(k,p,preforiind(k,p)) + respn_ori(k,p,orth_ori_ind(k,p)) );
        end
    end
    sortdata.OSI_new=OSI_new;
    if saveflag
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
        %save([calpath sitename '\' ampMethod '\calFoutput.mat'],'calFoutput');    
    end
    clearvars -except ampMethod baselinemethod saveflag calpath moviedataparentpath preferpath NPYdataparentpath RunFolderSeq RLBflag responsiveflag runind vsparaparentpath ;
    close all
end


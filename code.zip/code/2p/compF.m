function compF(F_combine, F)
    normF=zeros([size(F_combine,1) size(F_combine,2)]); %calculated from registered tif
    normF1=zeros([size(F_combine,1) size(F_combine,2)]);% input from F.NPY
    totalframe=size(F_combine,1);
    ROInum=size(F_combine,2);
    for i=1:ROInum
        normF(:,i)=F_combine(:,i,1)/max(F_combine(:,i,1));%green
        normF1(:,i)=F(i,:)/max(F(i,:));
    end
    figure('Name','compare F');hold on;
    for i=1:ROInum
        plot(1:totalframe, normF(:,i)./normF1(:,i));
        axis([0 totalframe -0.00001 0.00001]);
    end
    set(get(gca,'XLabel'),'String','frame #');
    set(get(gca,'YLabel'),'String','F diff');
end


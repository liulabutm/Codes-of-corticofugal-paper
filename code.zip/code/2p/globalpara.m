function globalpara
global simulationpath figure_path allenmap_folder locate_neuron_folder mapping_folder NPYdataparentpath moviedataparentpath vsparaparentpath calpath rawdataparentpath recordsitepath tuningpath preferpath moviedataparentpathtemp prefervectorpath neuronlocationpath

NPYdataparentpath='E:\two-photon imaging\jiashu\data\suite2p\'; %
moviedataparentpath='E:\two-photon imaging\jiashu\data\compressed data\';
% vsparaparentpath='Z:\Grade Students\liujias4\vs parameter\';
vsparaparentpath='Y:\2p data\vs parameter\';

calpath='E:\two-photon imaging\jiashu\data\matlab sortdata\';
recordsitepath='E:\two-photon imaging\jiashu\data\site recording\';
tuningpath='E:\two-photon imaging\jiashu\data\tuning\';
preferpath='E:\two-photon imaging\jiashu\data\prefer summary\';
rawdataparentpath='E:\two-photon imaging\jiashu\data\raw data\';
prefervectorpath='E:\two-photon imaging\jiashu\data\prefer vector summary\';
neuronlocationpath='E:\two-photon imaging\jiashu\data\neuron location\each_recording_area_mat\';
mapping_folder='E:\two-photon imaging\jiashu\data\blood vessel match';
locate_neuron_folder='E:\two-photon imaging\jiashu\data\neuron location'; 
allenmap_folder='E:\two-photon imaging\jiashu\data\blood vessel match\allen map';
figure_path='E:\two-photon imaging\jiashu\data\paper figures';
simulationpath='E:\two-photon imaging\jiashu\data\paper figures\plasticity\simulation';
global NPYdataparentpath moviedataparentpath vsparaparentpath rawdataparentpath calpath
globalpara;

selpath='E:\two-photon imaging\jiashu\data\raw data\200727_roundAN_m2_OS2';
% fastzflag=RunFolderSeq{runind(f),9};

%read file name
%selpath = uigetdir(rawdataparentpath, 'pick up a dir for original tif'); %select original tif
filelist=dir(selpath);
filelistsub={};%containing the file names of original tif
for i=1:length(filelist)
    if ~isempty(strfind(filelist(i).name, '.tif'))
        filelistsub=[filelistsub filelist(i).name];
    end
end

%use first file to get the information about height, width
filepathtemp=[selpath '\' filelistsub{1}];
info=imfinfo(filepathtemp);
numimgsperstim = size(info,1); % frame/movie  number of frames per stimulus of original tif
info=info(1);
SampleFormat=info.SampleFormat;  % data type
actualImgHeight=round(info.Height); %%%need change
actualImgWidth=round(info.Width);   %%%need change
SI.acqsPerLoop=getheader(info,'SI.acqsPerLoop','%f');
SI.hBeams.powers=getheader(info,'SI.hBeams.powers','%f');
SI.hBeams.pzAdjust=getheader(info,'SI.hBeams.pzAdjust','%l');
SI.hChannels.channelSave=getheader(info,'SI.hChannels.channelSave','%f'); %%%need change
numofchan=length(SI.hChannels.channelSave); 
SI.hFastZ.discardFlybackFrames=getheader(info,'SI.hFastZ.discardFlybackFrames','%l'); %%%need change
SI.hFastZ.enable=getheader(info,'SI.hFastZ.enable','%l');
SI.hFastZ.hasFastZ=getheader(info,'SI.hFastZ.hasFastZ','%l');
SI.hFastZ.numDiscardFlybackFrames=getheader(info,'SI.hFastZ.numDiscardFlybackFrames','%f'); %%%need change
SI.hFastZ.numFramesPerVolume=getheader(info,'SI.hFastZ.numFramesPerVolume','%f');        %%%need change
SI.hFastZ.numVolumes=getheader(info,'SI.hFastZ.numVolumes','%f');                        %%%need change
SI.hFastZ.waveformType=getheader(info,'SI.hFastZ.waveformType','%s');
SI.hScan2D.channelsDataType=getheader(info,'SI.hScan2D.channelsDataType','%s');
SI.hStackManager.framesPerSlice=getheader(info,'SI.hStackManager.framesPerSlice','%f');  %%%need change single slice aqu
SI.hStackManager.numSlices=getheader(info,'SI.hStackManager.numSlices','%f'); %does not include the discarded slice
SI.hStackManager.stackZStepSize=getheader(info,'SI.hStackManager.stackZStepSize','%f');
SI.hStackManager.stackReturnHome=getheader(info,'SI.hStackManager.stackReturnHome','%l');
SI.hStackManager.stackStartCentered=getheader(info,'SI.hStackManager.stackStartCentered','%l');
SI.hRoiManager.scanFrameRate=getheader(info,'SI.hRoiManager.scanFrameRate','%f');       %%%need change
SI.hRoiManager.scanVolumeRate=getheader(info,'SI.hRoiManager.scanVolumeRate','%f');     %%%need change
SI.hRoiManager.scanZoomFactor=getheader(info,'SI.hRoiManager.scanZoomFactor','%f');


backslashpos=strfind(selpath, '\');
%createpath=mkdir(selpath(1:backslashpos(end)),[selpath(backslashpos(end)+1:end) '_comp']);
createpath=mkdir('E:\two-photon imaging\jiashu\data\test',[selpath(backslashpos(end)+1:end) '_remove']);
remove_path=['E:\two-photon imaging\jiashu\data\test\' selpath(backslashpos(end)+1:end) '_remove\'];

tagstruct.ImageLength = actualImgHeight;
tagstruct.ImageWidth = actualImgWidth;
tagstruct.SampleFormat = Tiff.SampleFormat.Int;
tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
tagstruct.BitsPerSample = 16; % Number of bits per component; component here is color channel
tagstruct.SamplesPerPixel = 1; % The number of components per pixel;1 for grayscale, 3 for RGB images
tagstruct.Compression = Tiff.Compression.None;
tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
tagstruct.ResolutionUnit=Tiff.ResolutionUnit.Centimeter;
tagstruct.XResolution=actualImgWidth/(0.041612*2.5/SI.hRoiManager.scanZoomFactor); %unit  pixels per Centimeter  416.12micron/512pixel for 2.5x zoom
tagstruct.YResolution=actualImgHeight/(0.041612*2.5/SI.hRoiManager.scanZoomFactor);
tagstruct.Software=info(1).Software;
tagstruct.Artist=info(1).Artist;

parfor j=1:length(filelistsub) %individual tif files
    t = Tiff([remove_path filelistsub{j}],'w');
    info=imfinfo([selpath '\' filelistsub{j}]);
%     comp_im=zeros(actualImgHeight,actualImgWidth,200); 
    for i=1:SI.hFastZ.numVolumes  % volume
        for k=1:SI.hStackManager.numSlices*numofchan % frame
            tempI=imread([selpath '\' filelistsub{j}],(i-1)*SI.hFastZ.numFramesPerVolume*numofchan+k);
            setTag(t,tagstruct);
            setTag(t,'ImageDescription',info((i-1)*SI.hFastZ.numFramesPerVolume*numofchan+k).ImageDescription);
            write(t,tempI);
            if ~(i==SI.hFastZ.numVolumes && k==SI.hStackManager.numSlices*numofchan)
                writeDirectory(t);
            end
%             imwrite(tempI,[remove_path filelistsub{j}], 'WriteMode','append');% the min pixel value should be >=0%% need to substract the min before call uint16
%             comp_im(:,:,(i-1)*4+k)=tempI;
        end
    end
    close(t);
%     maxI=max(max(max(comp_im)));  %%%
%     minI=min(min(min(comp_im)));  %%%
%     for i=1:size(comp_im,3)
%         imwrite(uint16(comp_im(:,:,i)-minI),[remove_path filelistsub{j}], 'WriteMode','append');% the min pixel value should be >=0%% need to substract the min before call uint16
%     end
end
filenum=length(filelistsub);
imageformat='int16';
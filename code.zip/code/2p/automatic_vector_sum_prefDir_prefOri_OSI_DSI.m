global NPYdataparentpath moviedataparentpath vsparaparentpath calpath preferpath
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
%plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
saveflag=1;
%outlier=1;
%ignorecell=1;
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\calFoutput.mat']);
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=size(sortdata.AVEpercFlu_amp,2);
    repnum=sortdata.repnum;
    
    if blankflag
        respn=sortdata.AVE_peak_perc(:,:,2:end);  %direction response
        uniquestim=sortdata.uniquestim(2:end);
    else
        respn=sortdata.AVE_peak_perc;
        uniquestim=sortdata.uniquestim;
    end
    
    respn_ori=zeros(size(respn,1),size(respn,2),size(respn,3)/2);
    for k=1:size(uniquestim,1)/2
        respn_ori(:,:,k)=(respn(:,:,k)+respn(:,:,k+size(respn,3)/2))/2;
    end  
    
    
    for k=1:ROInum
        for p=1:recordnum
            [amp(k,p),prefdirind(k,p)]=max(respn(k,p,:));
            if prefdirind(k,p)<= size(uniquestim,1)/2
                oppo_dir_ind(k,p)= prefdirind(k,p)+size(uniquestim,1)/2;
            else 
                oppo_dir_ind(k,p)= prefdirind(k,p)-size(uniquestim,1)/2;
            end
            [amp(k,p),preforiind(k,p)]=max(respn_ori(k,p,:));
            if preforiind(k,p)<= size(respn_ori,3)/2
                orth_ori_ind(k,p)= preforiind(k,p)+size(respn_ori,3)/2;
            else 
                orth_ori_ind(k,p)= preforiind(k,p)-size(respn_ori,3)/2;
            end
        end
    end
    
    
    
    uniquestim_radian=uniquestim*pi/180;
    perfori_vec_formula = zeros(ROInum,recordnum);
    perfdir_vec_formula = zeros(ROInum,recordnum);
    DSI = zeros(ROInum,recordnum);
    OSI = zeros(ROInum,recordnum);
    globalOSI = zeros(ROInum,recordnum);
    globalDSI = zeros(ROInum,recordnum);
    for k=1:ROInum
        for p=1:recordnum
           
            perfori_vec_formula(k,p)= angle(sum(squeeze(respn(k,p,:)) .* exp(2*uniquestim_radian(:)*i))); % calculate prefer orientation using weighted vector sum
            perfdir_vec_formula(k,p)= angle(sum(squeeze(respn(k,p,:)) .* exp(uniquestim_radian(:)*i))); % calculate prefer direction using weighted vector sum
            DSI(k,p)= (respn(k,p,prefdirind(k,p)) - respn(k,p,oppo_dir_ind(k,p)) ) / (respn(k,p,prefdirind(k,p)) + respn(k,p,oppo_dir_ind(k,p)) );
            OSI(k,p)= (respn_ori(k,p,preforiind(k,p)) - respn_ori(k,p,orth_ori_ind(k,p)) ) / (respn_ori(k,p,preforiind(k,p)) + respn_ori(k,p,orth_ori_ind(k,p)) );
            globalOSI(k,p)=gOSI(squeeze(respn(k,p,:)));
            globalDSI(k,p)=gDSI(squeeze(respn(k,p,:)));
            
        end
    end
    perfori_vec_formula_degree =180*perfori_vec_formula/pi;
    perfdir_vec_formula_degree =180*perfdir_vec_formula/pi;
    for k=1:ROInum
        for p=1:recordnum
            if perfdir_vec_formula_degree(k,p)<0
                perfdir_vec_formula_degree(k,p)=perfdir_vec_formula_degree(k,p)+360;
            end
            if perfori_vec_formula_degree(k,p)<0
                perfori_vec_formula_degree(k,p)=perfori_vec_formula_degree(k,p)+360;
            end
        end
    end
    perfori_vec_formula_degree=perfori_vec_formula_degree/2;
    
    
    % prefer direction based on preferred orientation
    pref_ori_vec_formula_index=zeros(ROInum,recordnum);
    prefdir_vec_formula_degree_basedori_new=zeros(ROInum,recordnum);
    for k=1:ROInum
        for p=1:recordnum
            
            pref_ori_vec_formula_index(k,p)=round(perfori_vec_formula_degree(k,p)/45)+1;   %find the index of the prefer orientation
            
            if isnan(pref_ori_vec_formula_index(k,p))  % if response is NaN, the cell is not selective cell, but the index must be 1-4 to run the loop, so make the index=1. This does not influence result because it is not selective cell
                pref_ori_vec_formula_index(k,p)=1;
            end
            
            
            if pref_ori_vec_formula_index(k,p)==5
                index_temp1=5;
                index_temp2=1+size(uniquestim,1)/2;
                respn_temp1=respn(k,p,end)+(180+perfori_vec_formula_degree(k,p)-uniquestim(end))*(respn(k,p,1)-respn(k,p,end))/(uniquestim(2)-uniquestim(1));
                respn_temp2=respn(k,p,index_temp1-1)+(perfori_vec_formula_degree(k,p)-uniquestim(index_temp1-1))*(respn(k,p,index_temp1)-respn(k,p,index_temp1-1))/(uniquestim(2)-uniquestim(1));
                if respn_temp1 >= respn_temp2
                    prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p)+180;
                else
                    prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p);
                end
            elseif pref_ori_vec_formula_index(k,p)==1
                index_temp1=1;
                index_temp2=1+size(uniquestim,1)/2;
                respn_temp1=respn(k,p,index_temp1)+(perfori_vec_formula_degree(k,p)-uniquestim(index_temp1))*(respn(k,p,index_temp1+1)-respn(k,p,index_temp1))/(uniquestim(2)-uniquestim(1));
                respn_temp2=respn(k,p,index_temp2)+(180+perfori_vec_formula_degree(k,p)-uniquestim(index_temp2))*(respn(k,p,index_temp2+1)-respn(k,p,index_temp2))/(uniquestim(2)-uniquestim(1));
                if respn_temp1 >= respn_temp2
                    prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p);
                else
                    prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p)+180;
                end
                
            elseif pref_ori_vec_formula_index(k,p)==4
                index_temp1=pref_ori_vec_formula_index(k,p);
                index_temp2=pref_ori_vec_formula_index(k,p)+size(uniquestim,1)/2;
                if perfori_vec_formula_degree(k,p)>uniquestim(pref_ori_vec_formula_index(k,p))
                    respn_temp1=respn(k,p,index_temp1)+(perfori_vec_formula_degree(k,p)-uniquestim(index_temp1))*(respn(k,p,index_temp1+1)-respn(k,p,index_temp1))/(uniquestim(2)-uniquestim(1));
                    respn_temp2=respn(k,p,index_temp2)+(180+perfori_vec_formula_degree(k,p)-uniquestim(index_temp2))*(respn(k,p,1)-respn(k,p,index_temp2))/(uniquestim(2)-uniquestim(1));
                    if respn_temp1 >= respn_temp2
                        prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p);
                    else
                        prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p)+180;
                    end
                else
                    respn_temp1=respn(k,p,index_temp1-1)+(perfori_vec_formula_degree(k,p)-uniquestim(index_temp1-1))*(respn(k,p,index_temp1)-respn(k,p,index_temp1-1))/(uniquestim(2)-uniquestim(1));
                    respn_temp2=respn(k,p,index_temp2-1)+(180+perfori_vec_formula_degree(k,p)-uniquestim(index_temp2-1))*(respn(k,p,index_temp2)-respn(k,p,index_temp2-1))/(uniquestim(2)-uniquestim(1));
                    if respn_temp1 >= respn_temp2
                        prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p);
                    else
                        prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p)+180;
                    end
                end
            else
                index_temp1=pref_ori_vec_formula_index(k,p);
                index_temp2=pref_ori_vec_formula_index(k,p)+size(uniquestim,1)/2;
                if perfori_vec_formula_degree(k,p)>uniquestim(pref_ori_vec_formula_index(k,p))
                    respn_temp1=respn(k,p,index_temp1)+(perfori_vec_formula_degree(k,p)-uniquestim(index_temp1))*(respn(k,p,index_temp1+1)-respn(k,p,index_temp1))/(uniquestim(2)-uniquestim(1));
                    respn_temp2=respn(k,p,index_temp2)+(180+perfori_vec_formula_degree(k,p)-uniquestim(index_temp2))*(respn(k,p,index_temp2+1)-respn(k,p,index_temp2))/(uniquestim(2)-uniquestim(1));
                    if respn_temp1 >= respn_temp2
                        prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p);
                    else
                        prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p)+180;
                    end
                else
                    respn_temp1=respn(k,p,index_temp1-1)+(perfori_vec_formula_degree(k,p)-uniquestim(index_temp1-1))*(respn(k,p,index_temp1)-respn(k,p,index_temp1-1))/(uniquestim(2)-uniquestim(1));
                    respn_temp2=respn(k,p,index_temp2-1)+(180+perfori_vec_formula_degree(k,p)-uniquestim(index_temp2-1))*(respn(k,p,index_temp2)-respn(k,p,index_temp2-1))/(uniquestim(2)-uniquestim(1));
                    if respn_temp1 >= respn_temp2
                        prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p);
                    else
                        prefdir_vec_formula_degree_basedori_new(k,p)=perfori_vec_formula_degree(k,p)+180;
                    end
                end
            end
%             if pref_ori_vec_formula_index(k,p)==5
%                 pref_ori_vec_formula_index(k,p)=1;
%                 temp=[respn(k,p,pref_ori_vec_formula_index(k,p)),respn(k,p,pref_ori_vec_formula_index(k,p)+size(respn,3)/2)];   %find the larger response between the 2 directions in preferred orientation 
%                 [M,I]=max(temp);
%                 if I==1   % if the larger response is within the same range to prefer orientation, the prefer direction equal to prefer orientation
%                     perfdir_vec_formula_degree_basedori(k,p)=perfori_vec_formula_degree(k,p)+180;
%                 elseif I==2   % if the larger response is 180 degree difference from prefer orientation, the prefer direction equal to (180+prefer orientation)
%                     perfdir_vec_formula_degree_basedori(k,p)=perfori_vec_formula_degree(k,p);
%                 end
%             else
%                 temp=[respn(k,p,pref_ori_vec_formula_index(k,p)),respn(k,p,pref_ori_vec_formula_index(k,p)+size(respn,3)/2)];   %find the larger response between the 2 directions in preferred orientation 
%                 [M,I]=max(temp);
%                 if I==1   % if the larger response is within the same range to prefer orientation, the prefer direction equal to prefer orientation
%                     perfdir_vec_formula_degree_basedori(k,p)=perfori_vec_formula_degree(k,p);
%                 elseif I==2   % if the larger response is 180 degree difference from prefer orientation, the prefer direction equal to (180+prefer orientation)
%                     perfdir_vec_formula_degree_basedori(k,p)=perfori_vec_formula_degree(k,p)+180;
%                 end
%             end
        
        end
    end
    
    sortdata.perfdir_vec_formula_degree = perfdir_vec_formula_degree;
    sortdata.perfori_vec_formula_degree = perfori_vec_formula_degree;
    sortdata.prefdir_vec_formula_degree_basedori_new=prefdir_vec_formula_degree_basedori_new;
    %sortdata.prefdir_mix=sortdata.prefdir_vec_formula_degree_basedori_new;
    sortdata.DSI=DSI;
    sortdata.OSI=OSI;
    sortdata.globalDSI=globalDSI;
    sortdata.globalOSI=globalOSI;
    
    
    if saveflag
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
        %save([calpath sitename '\' ampMethod '\calFoutput.mat'],'calFoutput');    
    end
    clearvars -except ampMethod baselinemethod saveflag calpath moviedataparentpath preferpath NPYdataparentpath RunFolderSeq RLBflag responsiveflag runind vsparaparentpath ;
    close all
end




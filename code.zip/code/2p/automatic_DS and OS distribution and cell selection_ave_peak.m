%%
% get the preferred direction (the peak value) and load the prefdir into
% prefdir_load.mat file and prefdir_loadseq.mat file
clear all
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath preferpath
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
%plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
outlier=1;
ignorecell=1;
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         %good=1, bad=0, control=2
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\calFoutput.mat']);
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=size(sortdata.AVEpercFlu_amp,2);
    repnum=sortdata.repnum;

    if blankflag
        AVEperc=sortdata.AVE_peak_perc(:,:,2:end);  %direction response
        uniquestim=sortdata.uniquestim(2:end);
    else
        AVEperc=sortdata.AVE_peak_perc;
        uniquestim=sortdata.uniquestim;
    end

    for i=1:ROInum
        for j=1:recordnum
            [amp(i,j),prefdirind(i,j)]=max(AVEperc(i,j,:));
            prefdir_ave_peak(i,j)=uniquestim(prefdirind(i,j));
        end
    end
    sortdata.prefdir_ave_peak=prefdir_ave_peak;
    save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
    
     %load the selectROI in mat file
    selectROI_outlier=sortdata.selectROI_outlier;
    if f==1       
        if repflag
            ROIselect_load=selectROI_outlier; 
        else
            if VLflag               
                ROIselect_load(:,1,:)=selectROI_outlier(:,1,:);
                ROIselect_load(:,3,:)=selectROI_outlier(:,2,:);
            else                
                ROIselect_load=selectROI_outlier; 
            end
        end
        ROIselect_loadseq={sitename,1,ROInum,recordnum};
        save([preferpath '\OS\ROIselect_load.mat'],'ROIselect_load');
        save([preferpath '\OS\ROIselect_loadseq.mat'],'ROIselect_loadseq');
    else
        load([preferpath '\OS\ROIselect_load.mat']);
        load([preferpath '\OS\ROIselect_loadseq.mat']);
        if repflag
            ROIselect_load(end+1:(size(ROIselect_load,1)+ROInum),1:3)=selectROI_outlier; 
        else
            if VLflag
                endnum=size(ROIselect_load,1);
                ROIselect_load(endnum+1:(endnum+ROInum),1,:)=selectROI_outlier(:,1,:);
                ROIselect_load(endnum+1:(endnum+ROInum),3,:)=selectROI_outlier(:,2,:);
            else
                endnum=size(ROIselect_load,1);
                ROIselect_load(endnum+1:(endnum+ROInum),1,:)=selectROI_outlier(:,1,:);
            end
        end
        ROIstart=ROIselect_loadseq{end,3}+1;
        ROIend=ROIstart+ROInum-1;
        ROIselect_loadseq(end+1,:)={sitename,ROIstart,ROIend,recordnum};
        save([preferpath '\OS\ROIselect_load.mat'],'ROIselect_load');
        save([preferpath '\OS\ROIselect_loadseq.mat'],'ROIselect_loadseq');
    end
    
    if f==1
        prefdir_load_ave_peak=[];
        prefdir_loadseq_ave_peak={sitename,1,ROInum,recordnum};
    else
    %load all the pref directions in an array
        load([preferpath 'OS\prefdir_load_ave_peak.mat']);
        load([preferpath 'OS\prefdir_loadseq_ave_peak.mat']);
        ROIstart=prefdir_loadseq_ave_peak{end,3}+1;
        ROIend=ROIstart+ROInum-1;
        prefdir_loadseq_ave_peak(end+1,:)={sitename,ROIstart,ROIend,recordnum};
    end
    
    if repflag
        prefdir_load_ave_peak(end+1:(size(prefdir_load_ave_peak,1)+ROInum),1:3)=prefdir_ave_peak;    
        
    else
        if VLflag
            endnum=size(prefdir_load_ave_peak,1);
            prefdir_load_ave_peak(endnum+1:(endnum+ROInum),1,:)=prefdir_ave_peak(:,1,:);
            prefdir_load_ave_peak(endnum+1:(endnum+ROInum),3,:)=prefdir_ave_peak(:,2,:);
        else
            endnum=size(prefdir_load_ave_peak,1);
            prefdir_load_ave_peak(endnum+1:(endnum+ROInum),1,:)=prefdir_ave_peak(:,1,:);
        end
    end
    
    
    save([preferpath 'OS\prefdir_load_ave_peak.mat'],'prefdir_load_ave_peak');
    save([preferpath 'OS\prefdir_loadseq_ave_peak.mat'],'prefdir_loadseq_ave_peak');
    
    clearvars -except VirusExp ampMethod baselinemethod calpath moviedataparentpath preferpath NPYdataparentpath RunFolderSeq RLBflag responsiveflag runind vsparaparentpath
%     close all
    
end






%plot the distribution of the pref. direction
load([preferpath 'OS\ROIselect_load.mat'])
load([preferpath 'OS\ROIselect_loadseq.mat'])
load([preferpath 'OS\prefdir_loadseq_ave_peak.mat'])
load([preferpath 'OS\prefdir_load_ave_peak.mat'])

selecellflag=1;  % 1=only distribute the cells that are responsive and reliable. 0 means show all the cells
ROInum=size(prefdir_load_ave_peak,1);
recordnum=size(prefdir_load_ave_peak,2);
prefdir_load_ave_peak_sele=prefdir_load_ave_peak;
if selecellflag
    for i=1:ROInum
        for j=1:recordnum
            if ROIselect_load(i,j)==0
                prefdir_load_ave_peak_sele(i,j)=-100;  %take the unselective cells out of range of category
            end
        end
    end
end
binNumber_dir=8;
binInterval_dir=360/binNumber_dir;
%binResult_dir=zeros(ROInum,recordnum);
binDir=zeros(1,binNumber_dir);
for i=1:binNumber_dir
    binDir(i)=(i-1)*binInterval_dir;    
end
binhistcata_dir=[binDir-binInterval_dir/2 (binDir(end)-binInterval_dir/2+binInterval_dir)];


prefdir_loadseq_ave_peak(:,5)={1};
%plot distribution
%before VL with no selection
%which trials would be included (manually change the number of the 5th column, 1 means included, 0 means not included)
runind=strfind(cell2mat(prefdir_loadseq_ave_peak(:,5))',1);  %find which one is OS stim          

trialindbef=runind';
ROIindbef=cell2mat(prefdir_loadseq_ave_peak(trialindbef,2:3));
endnum=0;
for i=1:size(ROIindbef,1)
    ROIstart=ROIindbef(i,1);
    ROIend=ROIindbef(i,2);
    ROInum=ROIend-ROIstart+1;
    temp1(endnum+1:endnum+ROInum,:)=prefdir_load_ave_peak_sele(ROIstart:ROIend,1);
    endnum=size(temp1,1);
end
figure;
histogram(temp1,binhistcata_dir);
xticks([0 45 90 135 180 225 270 315])
%xticklabels({'0.25','0.5','1','2','4','8'})

%title('before VL; p < 0.2; response > 6%;  n = 5');
%title('before VL; p < 0.05; n = 5');


%%
clear temp1

%repeat with  selection
tempind=strfind(cell2mat(prefdir_loadseq_ave_peak(:,4))',3);
runind=strfind(cell2mat(prefdir_loadseq_ave_peak(:,5))',1);  %find which ones need to run within OS stim
trialindrep=intersect(tempind,runind);

ROIindrep=cell2mat(prefdir_loadseq_ave_peak(trialindrep,2:3));
endnum=0;
temp2=0;
for i=1:size(ROIindrep,1)
    ROIstart=ROIindrep(i,1);
    ROIend=ROIindrep(i,2);
    ROInum=ROIend-ROIstart+1;
    temp2(endnum+1:endnum+ROInum,:)=prefdir_load_ave_peak_sele(ROIstart:ROIend,2);
    endnum=size(temp2,1);
end
figure;
histogram(temp2,binhistcata_dir);
title('repeat  reliable cells');



%after VL with  selection
tempind2=strfind(cell2mat(prefdir_loadseq_ave_peak(:,4))',2);
tempind3=strfind(cell2mat(prefdir_loadseq_ave_peak(:,4))',3);
tempind=unique([tempind2 tempind3]);
runind=strfind(cell2mat(prefdir_loadseq_ave_peak(:,5))',1);  %find which ones need to run within OS stim
trialindaft=intersect(tempind,runind);
ROIindaft=cell2mat(prefdir_loadseq_ave_peak(trialindaft,2:3));
endnum=0;
for i=1:size(ROIindaft,1)
    ROIstart=ROIindaft(i,1);
    ROIend=ROIindaft(i,2);
    ROInum=ROIend-ROIstart+1;
    temp3(endnum+1:endnum+ROInum,:)=prefdir_load_ave_peak_sele(ROIstart:ROIend,3);
    endnum=size(temp3,1);
end
figure;
histogram(temp3,binhistcata_dir);
title('after VL  reliable cells');

%% plasticity

% plot histogram with neurons that are selected in individual recording

prefdir_loadseq_ave_peak(:,5)={1};

%before VL with no selection
%which trials would be included (manually change the number of the 5th column, 1 means included, 0 means not included)
runind=strfind(cell2mat(prefdir_loadseq_ave_peak(:,5))',1);  %find which one is OS stim          

trialindbef=runind';
ROIindbef=cell2mat(prefdir_loadseq_ave_peak(trialindbef,2:3));
endnum=0;
temp1=[];
for i=1:size(ROIindbef,1)
    ROIstart=ROIindbef(i,1);
    ROIend=ROIindbef(i,2);
    ROInum=ROIend-ROIstart+1;
    temp1(endnum+1:endnum+ROInum,:)=prefdir_load_ave_peak_sele(ROIstart:ROIend,1);
    endnum=size(temp1,1);
end
figure;
histogram(temp1,binhistcata_dir);
xticks([0 45 90 135 180 225 270 315])

%after VL with  selection
tempind2=strfind(cell2mat(prefdir_loadseq_ave_peak(:,4))',2);
tempind3=strfind(cell2mat(prefdir_loadseq_ave_peak(:,4))',3);
tempind=unique([tempind2 tempind3]);
runind=strfind(cell2mat(prefdir_loadseq_ave_peak(:,5))',1);  %find which ones need to run within OS stim
trialindaft=intersect(tempind,runind);
ROIindaft=cell2mat(prefdir_loadseq_ave_peak(trialindaft,2:3));
endnum=0;
temp3=[];
for i=1:size(ROIindaft,1)
    ROIstart=ROIindaft(i,1);
    ROIend=ROIindaft(i,2);
    ROInum=ROIend-ROIstart+1;
    temp3(endnum+1:endnum+ROInum,:)=prefdir_load_ave_peak_sele(ROIstart:ROIend,3);
    endnum=size(temp3,1);
end
figure;
histogram(temp3,binhistcata_dir);

% only plot histogram with neurons that are selected in both before and after
ROIselect_both_load=zeros(size(ROIselect_load,1),1);
for i=1:size(ROIselect_both_load,1)  
    if (ROIselect_load(i,1)==1)&&(ROIselect_load(i,3)==1)
        ROIselect_both_load(i,1)=ROIselect_both_load(i,:)+1;
    end
end
prefdir_load_ave_peak_sele_both=prefdir_load_ave_peak;
if selecellflag
    for i=1:size(ROIselect_both_load,1)        
        if ROIselect_both_load(i,1)==0
            prefdir_load_ave_peak_sele_both(i,:)=-100;  %take the unselective cells out of range of category
        end
    
    end
end


prefdir_loadseq_ave_peak(:,5)={1};
%plot distribution
%before plasticity with selection
%which trials would be included (manually change the number of the 5th column, 1 means included, 0 means not included)
runind=strfind(cell2mat(prefdir_loadseq_ave_peak(:,5))',1);  %find which one is OS stim          

trialindbef=runind';
ROIindbef=cell2mat(prefdir_loadseq_ave_peak(trialindbef,2:3));
endnum=0;
temp1=[];
for i=1:size(ROIindbef,1)
    ROIstart=ROIindbef(i,1);
    ROIend=ROIindbef(i,2);
    ROInum=ROIend-ROIstart+1;
    temp1(endnum+1:endnum+ROInum,:)=prefdir_load_ave_peak_sele_both(ROIstart:ROIend,1);
    endnum=size(temp1,1);
end
figure;
histogram(temp1,binhistcata_dir);


%after plasticity with selection
tempind2=strfind(cell2mat(prefdir_loadseq_ave_peak(:,4))',2);
tempind3=strfind(cell2mat(prefdir_loadseq_ave_peak(:,4))',3);
tempind=unique([tempind2 tempind3]);
runind=strfind(cell2mat(prefdir_loadseq_ave_peak(:,5))',1); 
trialindaft=intersect(tempind,runind);
ROIindaft=cell2mat(prefdir_loadseq_ave_peak(trialindaft,2:3));
endnum=0;
temp3=[];
for i=1:size(ROIindaft,1)
    ROIstart=ROIindaft(i,1);
    ROIend=ROIindaft(i,2);
    ROInum=ROIend-ROIstart+1;
    temp3(endnum+1:endnum+ROInum,:)=prefdir_load_ave_peak_sele_both(ROIstart:ROIend,3);
    endnum=size(temp3,1);
end
figure;
histogram(temp3,binhistcata_dir);





function F_Fneucorr=corrmovneu(F_combine,F,Fneu,corrmovflag,Fneucorrcoef)
if nargin<4
    Fneucorrcoef=0.7;
    corrmovflag=1;
end
if isempty(corrmovflag)
    corrmovflag=1;
end
if isempty(Fneucorrcoef)
    Fneucorrcoef=0.7;
end
F_Fneucorr=zeros(size(F));
for i=1:size(F_combine,2) %ROI
    tempred=F_combine(:,i,2); %red channel
    Fredratio=tempred/median(tempred); %normalize to baseline median value
    if corrmovflag 
        Fcor=F(i,:)./Fredratio'; %correct motion artifact
        Fneucor=Fneu(i,:)./Fredratio';
    else 
        Fcor=F(i,:);
        Fneucor=Fneu(i,:);
    end
    F_Fneucorr(i,:)=Fcor-Fneucorrcoef*Fneucor; % have to use weighted average
end


% figure;hold on;
% plot(Fneucor(1,:));
% plot(Fneu(1,:));
% figure;hold on;
% plot(Fcor-Fneucor);
% plot(Fcor);
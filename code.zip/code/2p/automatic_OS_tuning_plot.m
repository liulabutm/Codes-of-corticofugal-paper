%% OS tuning
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath tuningpath
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
AveAmpMethod= 'ave_peak';  %'ave_peak' means average 15 trials first and then get the peak; 'peak_ave' means get peak from each trial and then average the peak value
outlier=1;
ignorecell=1;
saveflag=1;  %save figure or not. if is 0, sortdata will still be saved
plotflag=1;
RLBcalflag=1; %if calculate reliability (formula) or not.  Calculation is need when there is any outlier
OWAcalflag=0; %if calculate one way anowa or not.
ttestcalflag=1; %if calculate t test or not.
responsivethre=0.06;
OWAthre=0.05;  %the threshold of judgement for one way anova
ttest_thre=0.05;   %the threshold of judgement for t test 
responsiveflag=1;  %if  use 'response>a value' as the criteria for selecting cells
RLBflag=0;   %if use reliability (formula) as the criteria for selecting cells
OWAflag=0;  %if  use one way anova as the criteria for selecting cells
ttestflag=1; %if  use t test as the criteria for selecting cells
saveflag=1;

frameoffset=1;%the response end time is 2 frames later than the end of stimulation %%%new
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));
runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
runind=runind';

for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\calFoutput.mat']);
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
    uniquestim=sortdata.uniquestim;
   
%     if stimtype==1
%         uniquestim=[0, 45, 90, 135, 180, 225, 270, 315];
%     elseif stimtype==2
%         uniquestim=[0.02, 0.04, 0.08, 0.16, 0.2, 0.64];
%     elseif stimtype==3
%         uniquestim=[0.25, 0.5, 1, 2, 4, 8];
%     end
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=size(sortdata.AVEpercFlu_amp,2);
    repnum=sortdata.repnum;
    stimendframe=sortdata.pretrigframe+sortdata.actualframerate*sortdata.stimtime+frameoffset; %%% new
    sortdata.frameoffset=frameoffset;
    sortdata.stimendframe=stimendframe;
    if saveflag
        createparpath=mkdir([tuningpath 'rmoutlier\' ampMethod '\' sitename '\' plottype]);
        tuning_path=[tuningpath 'rmoutlier\' ampMethod '\' sitename '\' plottype];
    end
%     outlierflag=~logical(sortdata.outlierflag);
%     if ignorecell
%         ignorecellind=sortdata.ignoreflag;
%         for i=1:ROInum
%             for j=1:recordnum
%                 if ignorecellind(i,j)
%                     outlierflag(i,:,j)=0;
%                 end
%             end
%         end
%     end
    %percFlu_amp(logical(sortdata.outlierflag))=-100;
    switch AveAmpMethod   
          case 'peak_ave'
               AVEperc=zeros(ROInum,recordnum,size(uniquestim,1)); % AveAmpMethod='peak_ave';
                if outlier         
                    %percFlu_amp=sortdata.percFlu_amp;
                    for i=1:ROInum
                        for j=1:recordnum
                            for k=1:sortdata.uniquestimnum
                                outlierflag_stim=squeeze(sortdata.outlierflag(i,1+repnum*(j-1):repnum*j,k));
                                percFlu_amp_stim=squeeze(sortdata.percFlu_amp(i,1+repnum*(j-1):repnum*j,k));
                                AVEperc(i,j,k)=mean(percFlu_amp_stim(~outlierflag_stim),2);
                            end
                        end
                    end
                else
                    AVEperc=sortdata.AVEpercFlu_amp;
                end
        case 'ave_peak'
            AVE_peak_perc=zeros(ROInum,recordnum,size(uniquestim,1));  % AveAmpMethod='ave_peak';
            if outlier         
                percFlu=sortdata.percFlu;
                for i=1:ROInum
                    for j=1:recordnum
                        for k=1:sortdata.uniquestimnum
                            outlierflag_stim=squeeze(sortdata.outlierflag(i,1+repnum*(j-1):repnum*j,k));
                            percFlu_stim=squeeze(sortdata.percFlu(:,1+repnum*(j-1):repnum*j,i,k));                            
                            temp(:,i,j,k)=mean(percFlu_stim(:,~outlierflag_stim),2);                            
                        end                        
                    end
                end                
            else
                for j=1:recordnum
                temp(:,:,j,:)=mean(sortdata.percFlu(:,1+repnum*(j-1):repnum*j,:,:),2);
                end                
            end
            AVE_peak_perc(:,:,:)=squeeze(max(temp(sortdata.pretrigframe+1:stimendframe,:,:,:),[],1));
            sortdata.AVE_peak_perc=AVE_peak_perc;
    end
    
    save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
    
    % calculate reliable responsive
    respROI_outlier=ones(ROInum,recordnum);
    for i=1:ROInum
        for j=1:recordnum        
            if max(sortdata.AVE_peak_perc(i,j,:))<responsivethre  %responsive
                respROI_outlier(i,j)=0;
            end
        end
    end
    %percRespROI=sum(respROI)/ROInum;
    sortdata.respROI_outlier=respROI_outlier;

    
    if RLBcalflag
        % reliability and one way anova
         %reliability  (with the formula)
        MAXpercFlu_amp=zeros(ROInum,recordnum);  %the max value in 8 orientations
        INDofpref=zeros(ROInum,recordnum);       %the index of the prefered (max response) orientation, 1:8=0,45,...,270,315
        MEANofpref=zeros(ROInum,recordnum);      %mean response of 15 repeat of the prefered orientation
        STDofpref=zeros(ROInum,recordnum);       %std of 15 repeat of the prefered orientation
        MEANofblank=zeros(ROInum,recordnum);     %mean response of the blank trial
        STDofblank=zeros(ROInum,recordnum);      %std of the blank trial
        outlierflag=~logical(sortdata.outlierflag);    
        ignorecellind=sortdata.ignoreflag;
        for i=1:ROInum
            for j=1:recordnum
                if ignorecellind(i,j)
                    outlierflag(i,:,j)=0;
                end
            end
        end

        if blankflag
            for i=1:ROInum
                for j=1:recordnum  
                    [MAXpercFlu_amp(i,j),INDofpref(i,j)]=max(sortdata.AVE_peak_perc(i,j,2:end),[],3);
                    temp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)+1),INDofpref(i,j)+1);
                    MEANofpref(i,j)=mean(temp);
                    STDofpref(i,j)=std(temp);
                    MEANofblank(i,j)=mean(sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1),1),2);
                    STDofblank(i,j)=std(sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1),1),0,2);
                end
            end
        else  
            pretrigframe=sortdata.pretrigframe;
            subrecrdtrialnum=sortdata.subrecrdtrialnum;
            baseline_med1=zeros(ROInum,1);
            baseline_med2=zeros(ROInum,1);
            BlankpercFlu=zeros(ROInum,pretrigframe,repnum,sortdata.uniquestimnum);
            if repflag==1
               baseline_med3=zeros(ROInum,1);
            end
            for i=1:ROInum
                baseframevalue1(:,:,:)=sortdata.F_Fneucorr3D((1:pretrigframe),1:repnum,i,:);
                temp=reshape(baseframevalue1,1,pretrigframe*repnum*sortdata.uniquestimnum);
                baseline_med1(i,1) = median(temp);
                BlankpercFlu(i,:,1:repnum,:)=(baseframevalue1-baseline_med1(i,1))/baseline_med1(i,1);
                if repflag==1
                    baseframevalue2(:,:,:)=sortdata.F_Fneucorr3D((1:pretrigframe),1+repnum:repnum*2,i,:);
                    temp=reshape(baseframevalue2,1,pretrigframe*repnum*sortdata.uniquestimnum);
                    baseline_med2(i,1) = median(temp);
                    BlankpercFlu(i,:,1+repnum:repnum*2,:)=(baseframevalue2-baseline_med2(i,1))/baseline_med2(i,1);
                    baseframevalue3(:,:,:)=sortdata.F_Fneucorr3D((1:pretrigframe),1+2*repnum:repnum*3,i,:);
                    temp=reshape(baseframevalue3,1,pretrigframe*repnum*sortdata.uniquestimnum);
                    baseline_med3(i,1) = median(temp);
                    BlankpercFlu(i,:,1+2*repnum:repnum*3,:)=(baseframevalue3-baseline_med3(i,1))/baseline_med2(i,1);
                else
                    if VLflag==1
                        baseframevalue2(:,:,:)=sortdata.F_Fneucorr3D((1:pretrigframe),1+repnum:repnum*2,i,:);
                        temp=reshape(baseframevalue2,1,pretrigframe*repnum*sortdata.uniquestimnum);
                        baseline_med2(i,1) = median(temp);
                        BlankpercFlu(i,:,1+repnum:repnum*2,:)=(baseframevalue2-baseline_med2(i,1))/baseline_med2(i,1);
                    end
                end               
            end
            BlankpercFlu_amp=squeeze(max(BlankpercFlu,[],2));
            BlankpercFlu_amp=squeeze(mean(BlankpercFlu_amp,3));
            
            for i=1:ROInum
                for j=1:recordnum
                    [MAXpercFlu_amp(i,j),INDofpref(i,j)]=max(sortdata.AVEperc(i,j,:),[],3);
                    temp1=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)),INDofpref(i,j));
                    MEANofpref(i,j)=mean(temp1);
                    STDofpref(i,j)=std(temp1);
                    MEANofblank(i,j)=mean(BlankpercFlu_amp(i,1+(j-1)*repnum:j*repnum),2);
                    STDofblank(i,j)=std(BlankpercFlu_amp(i,1+(j-1)*repnum:j*repnum),0,2);
                end
            end
        end
        RLB_outlier=(MEANofpref-MEANofblank)./(STDofpref+STDofblank);
        RLB_outlier=abs(RLB_outlier);
        sortdata.RLB_outlier=RLB_outlier;

        % %one way anova
        if OWAcalflag
            OWA_p_outlier=zeros(ROInum,recordnum);
            reliableROI_outlier=zeros(ROInum,recordnum);
            if blankflag
                for i=1:ROInum
                    for j=1:recordnum
                        percFlu_amp_blanktemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1),1); 
                        percFlu_amp_preftemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)+1),INDofpref(i,j)+1);
                        anovatemp(1:size(percFlu_amp_blanktemp,2))=percFlu_amp_blanktemp;
                        anovagroup(1:size(percFlu_amp_blanktemp,2))={'1'};
                        anovatemp(end+1:size(percFlu_amp_blanktemp,2)+size(percFlu_amp_preftemp,2))=percFlu_amp_preftemp;
                        anovagroup(end+1:size(percFlu_amp_blanktemp,2)+size(percFlu_amp_preftemp,2))={'2'};
                        OWA_p_outlier(i,j)=anova1(anovatemp,anovagroup,'off');
                        if OWA_p_outlier(i,j)<OWAthre
                           reliableROI_outlier(i,j)=1;
                        end
                        clearvars percFlu_amp_blanktemp percFlu_amp_preftemp anovatemp anovagroup
                    end
                end
            else
                for i=1:ROInum
                    for j=1:recordnum
                        percFlu_amp_blanktemp=BlankpercFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1));
                        percFlu_amp_preftemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)),INDofpref(i,j));
                        anovatemp(1:size(percFlu_amp_blanktemp,2))=percFlu_amp_blanktemp;
                        anovagroup(1:size(percFlu_amp_blanktemp,2))={'1'};
                        anovatemp(end+1:size(percFlu_amp_blanktemp,2)+size(percFlu_amp_preftemp,2))=percFlu_amp_preftemp;
                        anovagroup(end+1:size(percFlu_amp_blanktemp,2)+size(percFlu_amp_preftemp,2))={'2'};
                        OWA_p_outlier(i,j)=anova1(anovatemp,anovagroup,'off');
                        if OWA_p_outlier(i,j)<OWAthre
                           reliableROI_outlier(i,j)=1;
                        end
                        clearvars percFlu_amp_blanktemp percFlu_amp_preftemp anovatemp anovagroup
                    end
                end
            end
            sortdata.OWA_p_outlier=OWA_p_outlier;
            sortdata.reliableROI_outlier=reliableROI_outlier;
        end
        if ttestcalflag
            ttest_p_outlier=zeros(ROInum,recordnum);
            reliableROI_ttest_outlier=zeros(ROInum,recordnum);
            if blankflag
                for i=1:ROInum
                    for j=1:recordnum
%                         percFlu_amp_blanktemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1),1); 
%                         percFlu_amp_preftemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)+1),INDofpref(i,j)+1);
                        percFlu_amp_blanktemp=sortdata.percFlu_amp(i,(1+(j-1)*repnum:repnum*j),1);
                        percFlu_amp_preftemp=sortdata.percFlu_amp(i,(1+(j-1)*repnum:repnum*j),INDofpref(i,j)+1);
                        percFlu_amp_blanktemp=percFlu_amp_blanktemp(outlierflag(i,1+(j-1)*repnum:repnum*j,1));
                        percFlu_amp_preftemp=percFlu_amp_preftemp(outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)+1));
                        [ttest_h_outlier(i,j),ttest_p_outlier(i,j)]=ttest2(percFlu_amp_blanktemp,percFlu_amp_preftemp,'Tail','left'); %left means to test if the first vector is less than the second one                         
                        if ttest_p_outlier(i,j)<ttest_thre
                           reliableROI_ttest_outlier(i,j)=1;
                        end
                        clearvars percFlu_amp_blanktemp percFlu_amp_preftemp  
                    end
                end
            else
                for i=1:ROInum
                    for j=1:recordnum
                        percFlu_amp_blanktemp=BlankpercFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1));
                        percFlu_amp_preftemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)),INDofpref(i,j));
                        [ttest_h_outlier(i,j),ttest_p_outlier(i,j)]=ttest2(percFlu_amp_blanktemp,percFlu_amp_preftemp,'Tail','left'); %left means to test if the first vector is less than the second one                   
                        if ttest_p_outlier(i,j)<ttest_thre
                           reliableROI_ttest_outlier(i,j)=1;
                        end
                        clearvars percFlu_amp_blanktemp percFlu_amp_preftemp  
                    end
                end
            end
            sortdata.ttest_p_outlier=ttest_p_outlier;
            sortdata.reliableROI_ttest_outlier=reliableROI_ttest_outlier;
        end
    end
    
    
    %selectROI means which ROI is selected for plot the distribution or
    %calculate the amp change. choose which criterias (response, RLB or one way anova) to use at the beginning
    if responsiveflag
        seltemp(:,:,1)=respROI_outlier;
    else
        seltemp(:,:,1)=ones(ROInum,recordnum);
    end
    if RLBflag
        judgeRLB=zeros(ROInum,recordnum);
        for i=1:ROInum
            for j=1:recordnum
                if RLB_outlier(i,j)>=1
                    judgeRLB(i,j)=1;
                end
            end
        end
        seltemp(:,:,2)=judgeRLB;
    else
        seltemp(:,:,2)=ones(ROInum,recordnum);
    end
    if OWAflag
        seltemp(:,:,3)=reliableROI_outlier;
    else
        seltemp(:,:,3)=ones(ROInum,recordnum);
    end
    if ttestflag
        seltemp(:,:,4)=reliableROI_ttest_outlier;
    else
        seltemp(:,:,4)=ones(ROInum,recordnum);
    end
    selectROI_outlier=zeros(ROInum,recordnum);
    for i=1:ROInum
        for j=1:recordnum
            selectROI_outlier(i,j)=seltemp(i,j,1)&seltemp(i,j,2)&seltemp(i,j,3)&seltemp(i,j,4);
        end
    end
    sortdata.selectROI_outlier=selectROI_outlier;
    if saveflag
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
    end
    
    if plotflag
        switch plottype
            case 'linear'
                for i=1:ROInum % tuning of ROIs
                    figure; hold on;
                    for j=1:recordnum                            
                        switch AveAmpMethod
                            case 'ave_peak'
                                plot(uniquestim,squeeze(AVE_peak_perc(i,j,:)));
                            case 'peak_ave'
                                plot(uniquestim,squeeze(AVEperc(i,j,:)));
                        end
                    end
                    if recordnum==1
                        legend('bef');
                    elseif recordnum==2
                        legend('bef','aft');
                    elseif recordnum==3
                        legend('bef', 'rep','aft');
                    end
                    title(['ROI' num2str(i) ' anova ' num2str(sortdata.ONE_WAY_ANOVA(i,:)) 'outlier' num2str(outlier) 'igncell' num2str(ignorecell)]);
                    if saveflag
                        savefig([tuning_path '\' baselinemethod '_ROI ' num2str(i)]);
                        saveas(gcf,[tuning_path '\' baselinemethod '_ROI ' num2str(i)], 'tiff');
                    end
                end
           case 'polar'                
                minresp=zeros(ROInum,recordnum);
                switch AveAmpMethod
                    case 'ave_peak'
                        resp=AVE_peak_perc;

                    case 'peak_ave'
                        resp=AVEperc;
                end
                if blankflag
                   resp=resp(:,:,2:end);
                   radius=[uniquestim(2:end)', 360];
                else
                   resp=resp;
                   radius=[uniquestim', 360];
                end

                for i=1:ROInum
                    figure;
                    for j=1:recordnum

                        minresp(i,j)=min(resp(i,j,:));
                        if  minresp(i,j)<0
                            resp(i,j,:)=resp(i,j,:)-minresp(i,j);
                        end                
                        resp(i,j,size(radius,2))=resp(i,j,1);
                        polarplot(radius*pi/180, (squeeze(resp(i,j,:)))'); 

                        hold on

                    end
                    if VLflag
                        if repflag
                            title(['ROI' num2str(i) ' recnum' num2str(j) ' sele bef ' num2str(sortdata.selectROI_outlier(i,1)) ' sele rep ' num2str(sortdata.selectROI_outlier(i,2)) ' sele aft ' num2str(sortdata.selectROI_outlier(i,3)) ]);
                        else
                            title(['ROI' num2str(i) ' recnum' num2str(j) ' sele bef ' num2str(sortdata.selectROI_outlier(i,1)) ' sele aft ' num2str(sortdata.selectROI_outlier(i,2)) ]);

                        end
                    else
                        title(['ROI' num2str(i) ' recnum' num2str(j) ' sele bef ' num2str(sortdata.selectROI_outlier(i,1))  ]);

                    end
                    if saveflag
                        savefig([tuning_path '\' baselinemethod '_ROI ' num2str(i) ' recnum' num2str(j)]);
                        saveas(gcf,[tuning_path '\' baselinemethod '_ROI ' num2str(i) ' recnum' num2str(j)], 'tiff');
                    end
                end
        end 
        
    end

    clearvars -except ttest_thre ttestflag RLBflag OWAflag responsiveflag responsivethre RLBcalflag OWAcalflag ttestcalflag AveAmpMethod plotflag ampMethod baselinemethod calpath tuningpath moviedataparentpath NPYdataparentpath frameoffset RunFolderSeq runind saveflag vsparaparentpath plottype outlier ignorecell
    close all
end







%% plot



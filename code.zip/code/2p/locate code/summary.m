function summary
%% input path
global allenmap_folder locate_neuron_folder calpath
globalpara;


brain_layer=1; %this will be consistent with locate_neuron
%load in boundary map
if brain_layer==1
    allenmap=load([allenmap_folder '\allenmap_layer1.mat']); %this should be the same unless you change the boudary image
else
    allenmap=load([allenmap_folder '\allenmap_layer5.mat']); 
end
%first collum: area name
%second collum: boundary coordinates


%% obtain mouse list 

ampMethod= 'peak';   %'peak' or 'integration'
%plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
        
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
recording_folders=cell(size(runind,1),1);
for i=1:size(runind,1)
    recording_folders{i}=RunFolderSeq{runind(i,1),1};
end








% recording_folders = dir([locate_neuron_folder '\each_recording_area_mat']);%information for all folders in each_recording_area_mat folders
% folder_list=string({recording_folders([recording_folders.isdir]).name})';%the names for all folders in each_recording_area_mat folder

recording_list = cell(length(recording_folders),2);
%first column mouse name, second column foler name
%remove_ind=[];
for i = 1:length(recording_folders)
    folder_name=char(recording_folders(i));
%     %ignore file name represented by dots ('.','..',etc.)in the list
%     if any(strfind(folder_name,'.'))
%         remove_ind=[remove_ind i];
%     else
    name_start_ind=strfind(folder_name,'round');
    m_ind=strfind(folder_name,'m');
    name_end_ind=m_ind(1)+1;
    mouse_name=folder_name(name_start_ind:name_end_ind);%extract mouse name
    recording_list{i,1}=mouse_name;
    recording_list{i,2}=folder_name;
    
end  
%recording_list(remove_ind,:)=[];%remove files from folder list

mouse_list=unique(recording_list(:,1));

%% summary for each mouse 
for i = 1:length(mouse_list)
    figure
    hold on;
    
    %plot allenmap
    for n = 1: size(allenmap.boundaries,1) 
        if ~isempty(allenmap.boundaries{n,2})
            shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
            plot(shape{n})
        end
    end
    
    %plot each recording
    for k = 1:size(recording_list,1)
        if any(strfind(recording_list{k,2},mouse_list{i}))
            if contains(recording_list{k,2},'OS')
                load([calpath recording_list{k,2} '\peak\sortdata.mat']);
                
                %stimuli_type=recording_list{k,2}(underscore_ind(3)+1:underscore_ind(4)-2);

                for n=1:size(sortdata.neurons,1)
                    if sortdata.selectROI_outlier(n,1)==1
                       plot(sortdata.neurons(n,2),sortdata.neurons(n,3),'Marker','.','MarkerFaceColor','blue')
                    end
                end
                legend(recording_list{k,2});
                legend off
            end
        end
    end
    
    cd([locate_neuron_folder '\individual_mouse'])
    saveas(gcf,[mouse_list{i} '.jpg']);
    saveas(gcf,[mouse_list{i} '.fig']);
end

%% summary for all mouse
figure
hold on;

%plot allenmap
for n = 1: size(allenmap.boundaries,1) 
    if ~isempty(allenmap.boundaries{n,2})
        shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
        plot(shape{n})
    end
end

for i = 1:length(mouse_list)
    
    %plot each recording
    for k = 1:size(recording_list,1)
        if any(strfind(recording_list{k,2},mouse_list{i}))
            neuron=load([locate_neuron_folder '\each_recording_area_mat\' recording_list{k,2} '\locate_neuron.mat']);
            
            underscore_ind=strfind(recording_list{k,2},'_');
            stimuli_type=recording_list{k,2}(underscore_ind(3)+1:underscore_ind(4)-2);
            
            for n=1:size(neuron.neurons,1)
                switch stimuli_type
                    case 'OS'
                        plot(neuron.neurons(n,2),neuron.neurons(n,3),'Marker','.','MarkerFaceColor','red')
                    case 'TF'
                        plot(neuron.neurons(n,2),neuron.neurons(n,3),'Marker','.','MarkerFaceColor','blue')
                    case 'SF'
                        plot(neuron.neurons(n,2),neuron.neurons(n,3),'Marker','.','MarkerFaceColor','black')
                end
            end
            legend(recording_list{k,2});
            legend off
        end
    end
end

cd([locate_neuron_folder '\summary'])
saveas(gcf,'summary.jpg');
saveas(gcf,'summary.fig');


%% summary for all mouse - modified
figure
hold on;

%plot allenmap
for n = 1: size(allenmap.boundaries,1) 
    if ~isempty(allenmap.boundaries{n,2})
        shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
        pg=plot(shape{n});
        area_name=allenmap.boundaries{n,1};
        switch area_name
            case 'VISal'
                %pg.FaceColor='b';
                pg.FaceColor=[1,1,1];
            case 'VISrl'
                %pg.FaceColor='b';
                pg.FaceColor=[1,1,1];
            case 'VISpor'
%                 pg.FaceColor='r';
                pg.FaceColor=[1,1,1];
            case 'VISpl'
%                 pg.FaceColor='r';
                pg.FaceColor=[1,1,1];
            case 'VISli'
%                 pg.FaceColor='r';
                pg.FaceColor=[1,1,1];
            case 'VISI'
%                 pg.FaceColor='r';
                pg.FaceColor=[1,1,1];
            case 'VISp'
                pg.FaceColor=[1,1,1];
            case 'VISa'
%                 pg.FaceColor='b';
                pg.FaceColor=[1,1,1];
            case 'VISpm'
%                 pg.FaceColor='b';
                pg.FaceColor=[1,1,1];
            case 'VISam'
%                 pg.FaceColor='b';
                pg.FaceColor=[1,1,1];
        end
    end
end
color_exp=[0 0 0];
color_control=[0.25 0.25 0.25];
for i = 1:length(mouse_list)
    
    %plot each recording
    for k = 1:size(recording_list,1)
        if any(strfind(recording_list{k,2},mouse_list{i}))
            if contains(recording_list{k,2},'OS')
                load([calpath recording_list{k,2} '\peak\sortdata.mat']);
                for n=1:size(sortdata.neurons,1)
                    if ~isempty(sortdata.neuron_location{n,1})%only plot neurons in the visual cortex
                        if sortdata.selectROI_outlier(n,1)==1
                            if sortdata.Exptype ==1 %1 is experiment, 2 is control
                                %plot(sortdata.neurons(n,2),sortdata.neurons(n,3),'b.')
                                plot(sortdata.neurons(n,2),sortdata.neurons(n,3),'.','Color',[0.25,0.25,0.25])
                            elseif sortdata.Exptype ==2
                                %plot(sortdata.neurons(n,2),sortdata.neurons(n,3),'k.')
                                plot(sortdata.neurons(n,2),sortdata.neurons(n,3),'.','Color',[0.25,0.25,0.25])
                            else 
                                plot(sortdata.neurons(n,2),sortdata.neurons(n,3),'r.')
                            end  
                        end
                    end
                end
                legend(recording_list{k,2});
                legend off
            end
        end
    end
end
% 
% cd([locate_neuron_folder '\summary'])
% saveas(gcf,'summary_colored_area.jpg');
% % saveas(gcf,'summary_colored_area.fig');
% close all
end
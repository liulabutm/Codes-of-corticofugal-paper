function locate_neuron(selection_mode,display_flag,method,brain_layer)
%%function input
%mode,display_flag: parameter about how to run the locate_neuron
%method,brain_layer: parater baout the calculations used in locate_neuron
%                    these two are usually kept as default


%%mode: 'auto' or 'manual' or 'all'
%   'auto' with run through the whole folder and analyze and un-analyzed folders
%   'maual' will only run on the selected folders
%   'all' will re-run all folders
if nargin <1
   selection_mode = 'auto';
end

%%display_flag, whether to show images of neurons location or not
if nargin <2
    display_flag = 0;
end

%%method:'outer','both'
%   'outer': use the outer (lateral) edge of the mouse brain and standard (allen map) 
%            brain to calculate neuron coordinates under standard coordinate system
%   'both': use the outer (lateral) and inner (medial) edge of the mouse brain and standard  
%           (allen map)brain to calculate neuron coordinates under standard coordinate system
if nargin<3
   method='both';
end

%brain_layer
%   5: use allenmap_layer5 as the standard area map
%   1: use allenmap_layer5 as the standard area map
if nargin<4
   brain_layer=1;
end

%% set paths
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath preferpath mapping_folder locate_neuron_folder allenmap_folder
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
%plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
VirusExp= 'all';   %'good'  or  'bad'   or  'control' or 'all'
         %good=1, bad=0, control=2
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));
runind=find(cell2mat(RunFolderSeq(:,6)));

% runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
% removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
% runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end


%% analyze each recordings
%load in boundary map
if brain_layer==5
    allenmap=load([allenmap_folder '\allenmap_layer5.mat']); %this should be the same unless you change the boudary image
else
    allenmap=load([allenmap_folder '\allenmap_layer1.mat']); 
end
%first collum: area name
%second collum: boundary coordinates

%load in experiment type (control/ experiment)
%experiment=readtable([iscell_folder '\RunFolderSeq_all.xlsx']);

for f=1:size(runind,2)
    %% load recording data
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    Exptype=RunFolderSeq{runind(f),8};
    load([calpath sitename '\calFoutput.mat']);   
    stat=calFoutput.stat;
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end    
    iscell=sortdata.iscell; 



    %get conversion file
    backslash_ind=strfind(sitename,'_');
    folder_ind=(backslash_ind(4)+3):(backslash_ind(5)-1);
    %folder_ind=strfind(sitename,'_comp')-1;
    name_start_ind=strfind(sitename,'round');
    m_ind=strfind(sitename,'m');
    name_end_ind=m_ind(1)+1;
    mouse_name=sitename(name_start_ind:name_end_ind);%extract mouse name
    site_number=sitename(folder_ind);%extract conversion folder number

    conversion_folder_name=[sitename(1:name_end_ind) '_OS' site_number '_pia'];
    if isfile([mapping_folder '\DKRR_' mouse_name '\two-photon\' conversion_folder_name '\conversion.mat'])
        temp=load([mapping_folder '\DKRR_' mouse_name '\two-photon\' conversion_folder_name '\conversion.mat']);
        conversion=temp.conversion;
    else
        fprintf([folder_name ' has not been mapped\n'])

    end

    %calculate savepath
    savepath=[locate_neuron_folder '\each_recording_area_mat\' sitename];


  %% calculate transformed coordiantes of neurons

  %%matlab figure coordinates system
  %the left edge for the image as (0,0)
  %x value increase from left to right
  %y value increase from top to bottom

    neurons=[]; %neurons ind, x coordinate, y coordinate
    for m=1:size(stat,2)
        if iscell(m,1)
            x_cen = sum(double(stat{1,m}.xpix) .* stat{1,m}.lam)/sum(stat{1,m}.lam);
            y_cen = sum(double(stat{1,m}.ypix) .* stat{1,m}.lam)/sum(stat{1,m}.lam);
            neurons = [neurons; [m x_cen y_cen]];
       end
    end

    for k  =1:4 %conversion for first 4 steps of mapping
        for n = 1:size(neurons,1) 
           P = [neurons(n,3); neurons(n,2)]; %y,x coordinates of neurons ---- x,y inverted because y is dimension 1 in matlab

           %%image change
           %within an image, both rotation and resize and done with the original image center as the center of change
           %the World Coordinates of image center stays the same after rotation ------ the image is shifted as needed
           %the World Coordinates of the upper left corner of the image stays the same after resizing
           %       ------ (column, row) = (1,1) of the image before and after  resizing are at the same  location on the World  Coordinates

           % coordiates after rotation
           RotatedIm = imrotate(conversion{k,1}.img1,conversion{k,1}.angle,'bicubic','loose');   % rotation of the main image (im)
           RotMatrix = [cosd(conversion{k,1}.angle) -sind(conversion{k,1}.angle); sind(conversion{k,1}.angle) cosd(conversion{k,1}.angle)]; 
           ImCenterOri = (size(conversion{k,1}.img1)/2)';         % Center of the main image
           ImCenterRot = (size(RotatedIm)/2)';  % Center of the transformed image
           P = RotMatrix*(P-ImCenterOri) + ImCenterRot;
           Center_shift= ImCenterRot-ImCenterOri;

           % Coordiates after x_y_ratio and zoom
           Center_shift=(Center_shift*conversion{k,1}.zoom).*conversion{k,1}.ratio; %compensatory shift for rotation
           numrow=round(conversion{k,1}.zoom*conversion{k,1}.ratio(1,1)*size(RotatedIm,1)); %y
           numcol = round(conversion{k,1}.zoom*conversion{k,1}.ratio(2,1)*size(RotatedIm,2)); %x
           ResizedIm = imresize(RotatedIm, [numrow,numcol]);
           ResizeMatrix = [size(ResizedIm)'./size(RotatedIm)'];%y,x
           ImCenterRat=(size(ResizedIm)/2)';
            P = (P - ImCenterRot) .*ResizeMatrix + ImCenterRat;

           %Coordiates after shifting
           P = P+ conversion{k,1}.shift-Center_shift; 
           neurons(n,3) = P(1,1); 
           neurons(n,2) = P(2,1);
       end
    end

    k=5;%conversion for step5
    for n = 1:size(neurons,1) 
       P = [neurons(n,3); neurons(n,2)]; %y,x coordinates of neurons ---- x,y inverted because y is dimension 1 in matlab

       %%image change
       %within an image, rotation and resize and done with the original image center as the center of change
       %the World Coordinates of image center stays the same after rotation 
       %          ------ the image itself is not shifted for step5

       % coordiates after rotation
       RotatedIm = imrotate(conversion{k,1}.img,conversion{k,1}.angle,'bicubic','loose');   % rotation of the main image (im)
       RotMatrix = [cosd(conversion{k,1}.angle) -sind(conversion{k,1}.angle); sind(conversion{k,1}.angle) cosd(conversion{k,1}.angle)]; 
       ImCenterOri = (size(conversion{k,1}.img(:,:,1))/2)';         % Center of the main image
       ImCenterRot = (size(RotatedIm(:,:,1))/2)';  % Center of the transformed image
       P = RotMatrix*(P-ImCenterOri) + ImCenterRot;
       neurons(n,3) = P(1,1); 
       neurons(n,2) = P(2,1);
    end

   %% calculate outline coordinates after adjusting midline to horizontal
    outline=conversion{5,1}.outline;
    k=5;%the cortex outline will be rotated based on the calculated angle in step 5
    %rotated outline 
    for n = 1:size(outline,1) 
       P = [outline(n,2); outline(n,1)]; %y,x coordinates of neurons ---- x,y inverted because y is dimension 1 in matlab

       %%image change
       %within an image, rotation and resize and done with the original image center as the center of change
       %the World Coordinates of image center stays the same after rotation 
       %          ------ the image itself is not shifted for step5

       % coordiates after rotation
       RotatedIm = imrotate(conversion{k,1}.img,conversion{k,1}.angle,'bicubic','loose');   % rotation of the main image (im)
       RotMatrix = [cosd(conversion{k,1}.angle) -sind(conversion{k,1}.angle); sind(conversion{k,1}.angle) cosd(conversion{k,1}.angle)]; 
       ImCenterOri = (size(conversion{k,1}.img(:,:,1))/2)';         % Center of the main image
       ImCenterRot = (size(RotatedIm(:,:,1))/2)';  % Center of the transformed image
       P = RotMatrix*(P-ImCenterOri) + ImCenterRot;
       outline(n,2) = P(1,1); 
       outline(n,1) = P(2,1);
    end   

    %% calculate the standardized coordinates in pixel
    %measured values
    AP_length_m=max(outline(:,1))-min(outline(:,1));%anterior - posterior length of the cortex
    anterior_pos=max(outline(:,1));%anterior x coordinates
    midline_pos=max(outline(:,2));%midline y coordinates

    %%change coordinates system
    %anterior start point of cortex as zero for x
    %       with the distance (positive) from anterior start point as the x coordinates
    %midline of cortex as zero for y
    %       with the distance (positive) from midline as y coordintes
    neurons(:,2)= abs(neurons(:,2)-anterior_pos);%the length to anterior part of cortex for each neurons (x)
    neurons(:,3)= abs(neurons(:,3)-midline_pos);%the length to midline for each neurons (y)
    outline(:,1)= abs(outline(:,1)-anterior_pos);%the length to anterior part of cortex for each outline data point (x)
    outline(:,2)= abs(outline(:,2)-midline_pos);%the length to midline of cortex for each outline data point (y)
    %after coordinate conversion:
    %the more anterior, the samller the x value
    %the more lateral, the greater the y value


    anterior_ind=find(outline(:,1)==min(outline(:,1)));
    if length(anterior_ind)>1
        if all(diff(anterior_ind)==1) %if the indexes are consecutive number
            anterior_ind=round(median(anterior_ind));%assgin index to the median
        else %if the start and end point happen to on the anterior edge
            cir_shift_ind=find(diff(anterior_ind)>1)+1;
            outline=circshift(outline,cir_shift_ind,1);%shift on the first dimension (row)
            anterior_ind=find(outline(:,1)==min(outline(:,1)));
            anterior_ind=round(median(anterior_ind));
        end
    end

    posterior_ind=find(outline(:,1)==max(outline(:,1)));
    if length(posterior_ind)>1
        if all(diff(posterior_ind)==1) %if the indexes are consecutive number
            posterior_ind=round(median(posterior_ind));%assgin index to the median
        else %if the start and end point happen to on the anterior edge
            cir_shift_ind=find(diff(posterior_ind)>1)+1;
            outline=circshift(outline,cir_shift_ind,1);%shift on the first dimension (row)
            posterior_ind=find(outline(:,1)==max(outline(:,1)));
            posterior_ind=round(median(posterior_ind));
        end
    end

    edge_ind=find(outline(:,2)==max(outline(:,2)));
     if length(edge_ind)>1
        if all(diff(edge_ind)==1) %if the indexes are consecutive number
            edge_ind=round(median(edge_ind));%assgin index to the median
        else %if the start and end point happen to on the anterior edge
            cir_shift_ind=find(diff(edge_ind)>1)+1;
            outline=circshift(outline,cir_shift_ind,1);%shift on the first dimension (row)
            edge_ind=find(outline(:,1)==max(outline(:,2)));
            edge_ind=round(median(edge_ind));
        end
    end

    %%arraign the coordinates of lateral edge from anterior to posterior
    %first column is x and the second column is y
    if ((edge_ind-anterior_ind)*(edge_ind-posterior_ind)) < 0 
        %if the most lateral point is between the index for anterior and posterior edge in the outline matrix
        if anterior_ind > posterior_ind
            lateral_edge=flip(outline(posterior_ind:anterior_ind,:));
            medial_edge=[outline(anterior_ind:end,:);outline(1:posterior_ind,:)];
        else
            lateral_edge=outline(anterior_ind:posterior_ind,:);
            medial_edge=flip([outline(posterior_ind:end,:);outline(1:anterior_ind,:)]);
        end
    else %if the most lateral point is before or after both anterior and posterior edge in the outline matrix
        if anterior_ind > posterior_ind
             lateral_edge=[outline(anterior_ind:end,:);outline(1:posterior_ind,:)];
             medial_edge=flip(outline(posterior_ind:anterior_ind,:));
        else
             lateral_edge=flip([outline(posterior_ind:end,:);outline(1:anterior_ind,:)]);
             medial_edge=outline(anterior_ind:posterior_ind,:);
        end
    end

    %%calculate the medial-lateral length for each corresponding slice in allenmap
    slice_interval=AP_length_m/(85+0.5+0.5); 
    %total 85 (slice 19-104)  intervals  with 0.5 * slice intervals added before the first slice and after the last slice
    mouse_lateral_edge=zeros((104-63+1),2);
    mouse_medial_edge=zeros((104-63+1),2);

    %calculate the x coordinate and medial,lateral edge length for each
    %corresponding slices on the mouse brain 
    for m = 1:  (104-63+1)  %from slice 63 - 104
        x_slice=(m-1+63-(19-0.5))*slice_interval; %cortex starts with slice 18.5
        if sum(lateral_edge(:,1)==x_slice) %if the outline data point happen to be on a slice
            slice_ind=find(lateral_edge(:,1)==x_slice);
            y_slice_lateral=lateral_edge(slice_ind,2);
            y_slice_medial=medial_edge(slice_ind,2);
        else %lateral and medial edge data points may be of different density 
            %%lateral edge
            slice_ind_lateral=lateral_edge(:,1)>x_slice; 
            %the particular slice locate between the two adjunctive points where the x value of 
            %previous data point is smaller than x_slice while that of the latter is larger
            slice_ind_lateral_b=find(diff(slice_ind_lateral)>0); %the point before the slice
            slice_ind_lateral_a=find(diff(slice_ind_lateral)>0)+1;%the point after the slice
            %linear intropolation between two adjacent dots where plotting the outline
            %y=ax+b
            a_lateral_mouse=(lateral_edge(slice_ind_lateral_b,2)-lateral_edge(slice_ind_lateral_a,2))/(lateral_edge(slice_ind_lateral_b,1)-lateral_edge(slice_ind_lateral_a,1));
            b_lateral_mouse=(lateral_edge(slice_ind_lateral_a,2)*lateral_edge(slice_ind_lateral_b,1) - lateral_edge(slice_ind_lateral_b,2)*lateral_edge(slice_ind_lateral_a,1))/(lateral_edge(slice_ind_lateral_b,1)-lateral_edge(slice_ind_lateral_a,1));
            y_slice_lateral=a_lateral_mouse*x_slice+b_lateral_mouse;

            %meidal edge
            slice_ind_medial=medial_edge(:,1)>x_slice; 
            slice_ind_medial_b=find(diff(slice_ind_medial)>0); %the point before the slice
            slice_ind_medial_a=find(diff(slice_ind_medial)>0)+1;%the point after the slice
            a_medial_mouse=(medial_edge(slice_ind_medial_b,2)-medial_edge(slice_ind_medial_a,2))/(medial_edge(slice_ind_medial_b,1)-medial_edge(slice_ind_medial_a,1));
            b_medial_mouse=(medial_edge(slice_ind_medial_a,2)*medial_edge(slice_ind_medial_b,1) - medial_edge(slice_ind_medial_b,2)*medial_edge(slice_ind_medial_a,1))/(medial_edge(slice_ind_medial_b,1)-medial_edge(slice_ind_medial_a,1));
            y_slice_medial=a_medial_mouse*x_slice+b_medial_mouse;
        end
        mouse_lateral_edge(m,1)= x_slice;
        mouse_lateral_edge(m,2)= y_slice_lateral;
        mouse_medial_edge(m,1)= x_slice;
        mouse_medial_edge(m,2)= y_slice_medial;
    end

    %%startard values - according to allenmap
    AP_length_s=(104-19)*100+50+50; 
    %total 85 (slice 19-104)  intervals (100nm / slice) of brain slices with 50nm added before the first slice and after the last slice
    lateral_s=[((allenmap.allenmap(1,:)'-19)*100+50) allenmap.allenmap(3,:)']; %the pixel values for the left edge (slice 63-104)
    medial_s=[((allenmap.allenmap(1,:)'-19)*100+50) allenmap.allenmap(4,:)']; %the pixel values for inner edge (slice 63-104)


     %%calculate the standardized neuron coordinates
    for n = 1:size(neurons,1)  
       %determine which brain slice the neuron is on                  
       %calculate standardized y coordinates according to the standard
       %medial - lateral width of x coordinate
       %will be on the same slice index for mouse coordinates and standard coordinates
       if sum(mouse_lateral_edge(:,1)==neurons(n,2)) %if the neruon happen to be on a slice
        neuron_slice=find(mouse_lateral_edge(:,1)==neurons(n,2));
        neurons(n,3)=neurons(n,3)/(mouse_lateral_edge(neuron_slice,2)-mouse_medial_edge(neuron_slice,2))*(lateral_s(neuron_slice)- medial_s(neuron_slice))+medial_s(neuron_slice);
        %standardized x coordinates
        neurons(n,2)=neurons(n,2)/AP_length_m*AP_length_s;

       else
        neuron_slice_temp=mouse_lateral_edge(:,1)>neurons(n,2); 
        neuron_slice_b=find(diff(neuron_slice_temp)>0);%the slice before the neruon
        neuron_slice_a=find(diff(neuron_slice_temp)>0)+1;%the slice after the neruon

        %%interporlation of neuron coordinates on mouse coordinate system
        %lateral edge for coordinate x
        %y=ax+b
        a_lateral_mouse=(mouse_lateral_edge(neuron_slice_b,2)-mouse_lateral_edge(neuron_slice_a,2))/(mouse_lateral_edge(neuron_slice_b,1)-mouse_lateral_edge(neuron_slice_a,1));
        b_lateral_mouse=(mouse_lateral_edge(neuron_slice_a,2)*mouse_lateral_edge(neuron_slice_b,1) - mouse_lateral_edge(neuron_slice_b,2)*mouse_lateral_edge(neuron_slice_a,1))/(mouse_lateral_edge(neuron_slice_b,1)-mouse_lateral_edge(neuron_slice_a,1));
        neuron_lateral_mouse=a_lateral_mouse*neurons(n,2)+b_lateral_mouse;

        %medial edge for coordinate x
        a_medial_mouse=(mouse_medial_edge(neuron_slice_b,2)-mouse_medial_edge(neuron_slice_a,2))/(mouse_medial_edge(neuron_slice_b,1)-mouse_medial_edge(neuron_slice_a,1));
        b_medial_mouse=(mouse_medial_edge(neuron_slice_a,2)*mouse_medial_edge(neuron_slice_b,1) - mouse_medial_edge(neuron_slice_b,2)*mouse_medial_edge(neuron_slice_a,1))/(mouse_medial_edge(neuron_slice_b,1)-mouse_medial_edge(neuron_slice_a,1));
        neuron_medial_mouse=a_medial_mouse*neurons(n,2)+b_medial_mouse;

        %%interporlation of neuron coordinates on standard allenmap
        %standardized x coordinates
        neurons(n,2)=neurons(n,2)/AP_length_m*AP_length_s;

        %lateral edge for standardized coordinate x
        a_lateral_standard=(lateral_s(neuron_slice_b,2)-lateral_s(neuron_slice_a,2))/(lateral_s(neuron_slice_b,1)-lateral_s(neuron_slice_a,1));
        b_lateral_standard=(lateral_s(neuron_slice_a,2)*lateral_s(neuron_slice_b,1) - lateral_s(neuron_slice_b,2)*lateral_s(neuron_slice_a,1))/(lateral_s(neuron_slice_b,1)-lateral_s(neuron_slice_a,1));
        neuron_allen_lateral=a_lateral_standard*neurons(n,2)+b_lateral_standard;

        %medial edge for coordinate x
        a_medial_standard=(medial_s(neuron_slice_b,2)-medial_s(neuron_slice_a,2))/(medial_s(neuron_slice_b,1)-medial_s(neuron_slice_a,1));
        b_medial_standard=(medial_s(neuron_slice_a,2)*medial_s(neuron_slice_b,1) - medial_s(neuron_slice_b,2)*medial_s(neuron_slice_a,1))/(medial_s(neuron_slice_b,1)-medial_s(neuron_slice_a,1));
        neuron_allen_medial=a_medial_standard*neurons(n,2)+b_medial_standard;

        switch method
        case 'outer'
            neurons(n,3)=neurons(n,3)/neuron_lateral_mouse*neuron_allen_lateral;
        case 'both'
            neurons(n,3)=(neurons(n,3)-neuron_medial_mouse)/(neuron_lateral_mouse-neuron_medial_mouse)*(neuron_allen_lateral- neuron_allen_medial)+neuron_allen_medial;
        end           
       end   
    end

  %% locate neurons
    % determine if a dot is in polygon
    neuron_location=cell(size(neurons,1),2);
    neuron_location(:,1) = num2cell(neurons(:,1));
    for n = 1:size(neurons,1)
        for m = 1:size(allenmap.boundaries,1) 
            if ~isempty(allenmap.boundaries{m,2})
                if inpolygon(neurons(n,2),neurons(n,3),allenmap.boundaries{m,2}(1,:)',allenmap.boundaries{m,2}(2,:)') 
                    neuron_location(n, 2)=allenmap.boundaries(m,1);
                end
            end
        end
    end

    if ~isdir(savepath)
        mkdir(savepath)
    end
    sortdata.neuron_location=neuron_location(:,2);
    sortdata.neurons=neurons;
    sortdata.Exptype=Exptype;
    save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
     cd(savepath)
     save('locate_neuron.mat','neurons','neuron_location','Exptype')

    %% show neuron location summary figure
    figure
    hold on;
    for n = 1: size(allenmap.boundaries,1) 
        if ~isempty(allenmap.boundaries{n,2})
            shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
            plot(shape{n})
        end
    end
    for n = 1:size(neurons,1)
        if sortdata.selectROI_outlier(n,1)==1  % only plot selected ROI
            if Exptype==1 %1 is experiment, 2 is control
                plot(neurons(n,2),neurons(n,3),'b.')
            elseif Exptype==2
                plot(neurons(n,2),neurons(n,3),'k.')
            else
                plot(neurons(n,2),neurons(n,3),'r.')
            end
        end
    end
    title(sitename)
    cd(savepath)
    saveas(gcf,'locate_neuron.jpg')
    if  ~display_flag
        close all
    end
end

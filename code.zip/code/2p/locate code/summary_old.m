function summary
%% input path
global allenmap_folder locate_neuron_folder
globalpara;


brain_layer=1; %this will be consistent with locate_neuron
%load in boundary map
if brain_layer==1
    allenmap=load([allenmap_folder '\allenmap_layer1.mat']); %this should be the same unless you change the boudary image
else
    allenmap=load([allenmap_folder '\allenmap_layer5.mat']); 
end
%first collum: area name
%second collum: boundary coordinates


%% obtain mouse list from all recordings
recording_folders = dir([locate_neuron_folder '\each_recording_area_mat']);%information for all folders in each_recording_area_mat folders
folder_list=string({recording_folders([recording_folders.isdir]).name})';%the names for all folders in each_recording_area_mat folder

recording_list = cell(length(folder_list),2);
%first column mouse name, second column foler name
remove_ind=[];
for i = 1:length(folder_list)
    folder_name=char(folder_list(i));
    %ignore file name represented by dots ('.','..',etc.)in the list
    if any(strfind(folder_name,'.'))
        remove_ind=[remove_ind i];
    else
        name_start_ind=strfind(folder_name,'round');
        m_ind=strfind(folder_name,'m');
        name_end_ind=m_ind(1)+1;
        mouse_name=folder_name(name_start_ind:name_end_ind);%extract mouse name
        recording_list{i,1}=mouse_name;
        recording_list{i,2}=folder_name;
    end
end  
recording_list(remove_ind,:)=[];%remove files from folder list

mouse_list=unique(recording_list(:,1));

%% summary for each mouse 
for i = 1:length(mouse_list)
    figure
    hold on;
    
    %plot allenmap
    for n = 1: size(allenmap.boundaries,1) 
        if ~isempty(allenmap.boundaries{n,2})
            shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
            plot(shape{n})
        end
    end
    
    %plot each recording
    for k = 1:size(recording_list,1)
        if any(strfind(recording_list{k,2},mouse_list{i}))
            neuron=load([locate_neuron_folder '\each_recording_area_mat\' recording_list{k,2} '\locate_neuron.mat']);
            
            underscore_ind=strfind(recording_list{k,2},'_');
            stimuli_type=recording_list{k,2}(underscore_ind(3)+1:underscore_ind(4)-2);
            
            for n=1:size(neuron.neurons,1)
                switch stimuli_type
                    case 'OS'
                        plot(neuron.neurons(n,2),neuron.neurons(n,3),'Marker','.','MarkerFaceColor','red')
                    case 'TF'
                        plot(neuron.neurons(n,2),neuron.neurons(n,3),'Marker','.','MarkerFaceColor','blue')
                    case 'SF'
                        plot(neuron.neurons(n,2),neuron.neurons(n,3),'Marker','.','MarkerFaceColor','black')
                    otherwise
                        plot(neuron.neurons(n,2),neuron.neurons(n,3),'bx')
                end
            end
            legend(recording_list{k,2});
            legend off
        end
    end
    
    cd([locate_neuron_folder '\individual_mouse'])
    saveas(gcf,[mouse_list{i} '.jpg']);
    saveas(gcf,[mouse_list{i} '.fig']);
end

%% summary for all mouse
figure
hold on;

%plot allenmap
for n = 1: size(allenmap.boundaries,1) 
    if ~isempty(allenmap.boundaries{n,2})
        shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
        plot(shape{n})
    end
end

for i = 1:length(mouse_list)
    
    %plot each recording
    for k = 1:size(recording_list,1)
        if any(strfind(recording_list{k,2},mouse_list{i}))
            neuron=load([locate_neuron_folder '\each_recording_area_mat\' recording_list{k,2} '\locate_neuron.mat']);
            
            underscore_ind=strfind(recording_list{k,2},'_');
            stimuli_type=recording_list{k,2}(underscore_ind(3)+1:underscore_ind(4)-2);
            
            for n=1:size(neuron.neurons,1)
                switch stimuli_type
                    case 'OS'
                        plot(neuron.neurons(n,2),neuron.neurons(n,3),'Marker','.','MarkerFaceColor','red')
                    case 'TF'
                        plot(neuron.neurons(n,2),neuron.neurons(n,3),'Marker','.','MarkerFaceColor','blue')
                    case 'SF'
                        plot(neuron.neurons(n,2),neuron.neurons(n,3),'Marker','.','MarkerFaceColor','black')
                end
            end
            legend(recording_list{k,2});
            legend off
        end
    end
end

cd([locate_neuron_folder '\summary'])
saveas(gcf,'summary.jpg');
saveas(gcf,'summary.fig');


%% summary for all mouse - modified
figure
hold on;

%plot allenmap
for n = 1: size(allenmap.boundaries,1) 
    if ~isempty(allenmap.boundaries{n,2})
        shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
        pg=plot(shape{n});
        area_name=allenmap.boundaries{n,1};
        switch area_name
            case 'VISal'
                pg.FaceColor='b';
            case 'VISrl'
                pg.FaceColor='b';
            case 'VISpor'
                pg.FaceColor='r';
            case 'VISpl'
                pg.FaceColor='r';
            case 'VISli'
                pg.FaceColor='r';
            case 'VISI'
                pg.FaceColor='r';
            case 'VISp'
                pg.FaceColor=[1,1,1];
            case 'VISa'
                pg.FaceColor='b';
            case 'VISpm'
                pg.FaceColor='b';
            case 'VISam'
                pg.FaceColor='b';
        end
    end
end

for i = 1:length(mouse_list)
    
    %plot each recording
    for k = 1:size(recording_list,1)
        if any(strfind(recording_list{k,2},mouse_list{i}))
            neuron=load([locate_neuron_folder '\each_recording_area_mat\' recording_list{k,2} '\locate_neuron.mat']);
            
            underscore_ind=strfind(recording_list{k,2},'_');
            stimuli_type=recording_list{k,2}(underscore_ind(3)+1:underscore_ind(4)-2);
            
            for n=1:size(neuron.neurons,1)
                if ~isempty(neuron.neuron_location{n,2})%only plot neurons in the visual cortex
                    switch stimuli_type
                        case 'OS'%plot os only
                            if neuron.Exptype ==1 %1 is experiment, 2 is control
                                plot(neuron.neurons(n,2),neuron.neurons(n,3),'b.')
                            elseif neuron.Exptype ==2
                                plot(neuron.neurons(n,2),neuron.neurons(n,3),'k.')
                            else 
                                plot(neuron.neurons(n,2),neuron.neurons(n,3),'r.')
                            end
                    end
                end
            end
            legend(recording_list{k,2});
            legend off
        end
    end
end

cd([locate_neuron_folder '\summary'])
saveas(gcf,'summary_colored_area.jpg');
saveas(gcf,'summary_colored_area.fig');
close all
end
function automatic_data_analysis2P
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath
globalpara;

%run the folders automatically
%load the list of running sequence and the properties of each folder
saveflag=1;   %1=save cal and sortdata
baselinemethod='pretrig'; % 'pretrig'  or  'med'
ampMethod= 'peak';   %'peak' or 'integration'
frameoffset=2;%the response end time is 2 frames later than the end of stimulation %%%new



RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));
runind=find(cell2mat(RunFolderSeq(:,6)));
for f=1:size(runind,1)
    % changed para for each time
    sitename=RunFolderSeq{runind(f),1};
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    redflag=RunFolderSeq{runind(f),7};    %1=this ROI use red channel to correct the motion artifact
    load([calpath sitename '\calFoutput.mat']);
    
    imagepara=calFoutput.imagepara;
    subrecrdtrialnum=imagepara.SI.acqsPerLoop;
    
    %read csv file to get the stim parameters
%     selpath=calFoutput.selpath;
%     pos1=strfind(selpath, '_comp');
%     pos2=strfind(selpath, '\');
    %vsparapath=[vsparaparentpath selpath((pos2(end)+1):pos1(end)-1) '\vsparam.csv'];
    vsparapath1=[vsparaparentpath calFoutput.beforeVLmovie '\vsparam.csv'];
    vsparatemp = csvread(vsparapath1);
    vsparatemp = vsparatemp(:,1:14);
    %vsparatemp = vsparatemp(:,1:14);
    %vspara(1:subrecrdtrialnum,:)=vsparatemp(10:144,:);
    %vspara(1:subrecrdtrialnum,:)=vsparatemp(8:112,:);
    vspara(1:subrecrdtrialnum,:)=vsparatemp(:,:);
    if repflag
        vsparapath2=[vsparaparentpath calFoutput.repeatmovie '\vsparam.csv'];
        vsparatemp = csvread(vsparapath2);
        vsparatemp = vsparatemp(:,1:14);
        vspara(subrecrdtrialnum+1:subrecrdtrialnum*2,:) = vsparatemp;
        vsparapath3=[vsparaparentpath calFoutput.afterVLmovie '\vsparam.csv'];
        vsparatemp = csvread(vsparapath3);
        vsparatemp = vsparatemp(:,1:14);
        vspara(2*subrecrdtrialnum+1:subrecrdtrialnum*3,:) = vsparatemp;
    else
        if VLflag
            vsparapath2=[vsparaparentpath calFoutput.afterVLmovie '\vsparam.csv'];
            vsparatemp = csvread(vsparapath2);
            vsparatemp = vsparatemp(:,1:14);
            vspara(subrecrdtrialnum+1:subrecrdtrialnum*2,:) = vsparatemp;
        end
    end

    stimtime=vspara(1,7)/1000;
    trigertime=vspara(1,9)/1000;
    if stimtype==1 % OS
        stim_sequence=vspara(:,10);
        offset=vspara(1,12);
    elseif stimtype==2  %SF
        stim_sequence=vspara(:,1);
    elseif stimtype==3  %TF
        stim_sequence=vspara(:,2);
    elseif stimtype==4  %SI
        stim_sequence=vspara(:,14);
    elseif stimtype==5   %OS x SF
        stim_sequence(:,1)=vspara(121:360,10);
        stim_sequence(:,2)=vspara(121:360,1);
        offset=vspara(1,12);
    end

    %how many types of stimulation (e.g. how many orientation or square for RF)
    if stimtype==5  %OS X SF
        uniquestim_OS=unique(stim_sequence_OS);
        uniquestim_SF=unique(stim_sequence_SF);
        trialnum=size(stim_sequence_OS,1);
        uniquestimnum_OS=size(uniquestim_OS,1);
        uniquestimnum_SF=size(uniquestim_SF,1);
    else
        uniquestim=unique(stim_sequence);
        if stimtype==2
            if blankflag
                uniquestim(1)=0;   %0 means blank trial
            end
        end
        trialnum=size(stim_sequence,1);
        uniquestimnum=size(uniquestim,1);
    end

    if stimtype==1  % OS
        uniquestim=uniquestim-offset;
        %angledif=360/uniquestimnum;
        %angles=(0:(uniquestimnum-1))*angledif;
    elseif stimtype==5  % OS x SF
        angledif=360/uniquestimnum_OS;
        angles=(0:(uniquestimnum_OS-1))*angledif;
    end    
    
    %trialnum=size(stim_sequence,1);
    F_combine=calFoutput.F_combine;
%     F=F_combine(:,:,1);
%     F=permute(F,[2 1]);
    F=calFoutput.F;
    iscell=calFoutput.iscell;
    F(iscell(:,1)==0,:)=[]; %remove non-cell ROI
    Fneu=calFoutput.Fneu;
    Fneu(iscell(:,1)==0,:)=[]; %remove non-cell ROI
    
    %imagepara=calFoutput.imagepara;
    actualframerate=round(imagepara.actualframerate);
    if imagepara.SI.hFastZ.enable
        actualnumimgsperstim=imagepara.SI.hFastZ.numVolumes/imagepara.Tave;
        
    else
        actualnumimgsperstim=imagepara.SI.hStackManager.framesPerSlice;
    end


    %correct flu with motion artifact and neuropil 
    if redflag
        F_Fneucorr=corrmovneu(F_combine,F,Fneu,1,0.7); %run function to correct the motion artifact based on red channel; correct neuropail signal
    else
        F_Fneucorr=corrmovneu(F_combine,F,Fneu,0,0.7);
    end
    ROInum=size(F_Fneucorr,1);
    F_Fneucorr3D=reshape(F_Fneucorr',[actualnumimgsperstim,trialnum,ROInum]);  %reshape the original data and make it into 3 dimentional array. Row is the frame number for each trial, column is the number of trial, page is cell number.





    %calculate percentage change
    
    if imagepara.SI.hFastZ.enable
        pretrigframe=actualframerate*trigertime-calFoutput.imagepara.numDiscardVolumes;
    else 
        pretrigframe=actualframerate*trigertime;
    end
    stimendframe=pretrigframe+actualframerate*stimtime+frameoffset; %%% new
    switch baselinemethod
        case 'pretrig'        
            baseline_pertrial=mean(F_Fneucorr3D(1:pretrigframe,:,:),1);
            percFlu=F_Fneucorr3D;
            for i=1:actualnumimgsperstim
                percFlu(i,:,:)=(F_Fneucorr3D(i,:,:)-baseline_pertrial)./baseline_pertrial;
            end  
        case 'med'  %%do not revise for fastz yet
            %use median as the baseline to calculate percentage change
            %trialnum=120;
            baseline_med1=zeros(ROInum,1);
            baseline_med2=zeros(ROInum,1);
            if repflag==1
               baseline_med3=zeros(ROInum,1);
            end
            percFlu=F_Fneucorr3D;
            for i=1:ROInum
                baseframevalue1=reshape(F_Fneucorr3D((1:pretrigframe),1:subrecrdtrialnum,i),pretrigframe*trialnum,1);
                baseline_med1(i,1) = median(baseframevalue1);
                percFlu(:,1:subrecrdtrialnum,i)=(F_Fneucorr3D(:,1:subrecrdtrialnum,i)-baseline_med1(i,1))/baseline_med1(i,1);
                %baseline_med1=repmat(baseline_med1,actualnumimgsperstim,subrecrdtrialnum);
                if VLflag==1
                    baseframevalue2=reshape(F_Fneucorr3D((1:pretrigframe),subrecrdtrialnum+1:2*subrecrdtrialnum,i),pretrigframe*trialnum,1);
                    baseline_med2(i,1) = median(baseframevalue2);
                    percFlu(:,subrecrdtrialnum+1:2*subrecrdtrialnum,i)=(F_Fneucorr3D(:,subrecrdtrialnum+1:2*subrecrdtrialnum,i)-baseline_med2(i,1))/baseline_med2(i,1); 
                end
                    %baseline_med2=repmat(baseline_med2,actualnumimgsperstim,subrecrdtrialnum);
                if repflag==1
                    baseframevalue3=reshape(F_Fneucorr3D((1:pretrigframe),2*subrecrdtrialnum+1:3*subrecrdtrialnum,i),pretrigframe*trialnum,1);
                    baseline_med3(i,1) = median(baseframevalue3);
                    percFlu(:,2*subrecrdtrialnum+1:3*subrecrdtrialnum,i)=(F_Fneucorr3D(:,2*subrecrdtrialnum+1:3*subrecrdtrialnum,i)-baseline_med3(i,1))/baseline_med3(i,1);
                    %baseline_med3=repmat(baseline_med3,actualnumimgsperstim,subrecrdtrialnum);
                end


                % B1 = repmat(baselinevalue,frameperstim,stimpersession)
                % B=cat(2,b1, b2);
                %percFlu(:,:,i)=(F_Fneucorr3D(:,:,i)-baseline_med(i,1))/baseline_med(i,1);
                %
            end
    end



    
    %amp calculation
    timeperframe=1/actualframerate;
    switch ampMethod
        case 'integration'    %%do not revise for fastz yet
            
            intdur = 4;   %unit: second
            intstart=trigertime;
            percFlu_amp=zeros(ROInum,trialnum);
            %percFlu_med_response=zeros(ROInum,trialnum,2);
            frameend=intstart*actualframerate+actualframerate*intdur;
            if frameend>actualnumimgsperstim
                frameend=actualnumimgsperstim;
                intdur=(frameend-(intstart*actualframerate+1)+1)/actualframerate;
            end
            switch baselinemethod
                case 'pretrig' 
                    for i=1:ROInum   
                        percFlu_amp(i,:)=trapz(timeperframe,percFlu(intstart*actualframerate+1:frameend,:,i))/(intdur-timeperframe);
                    end
                case 'med'
                    percFlu_amp_base=zeros(ROInum,trialnum);
                    percFlu_amp_stim=zeros(ROInum,trialnum);
                    for i=1:ROInum
                         percFlu_amp_base(i,:)=trapz(timeperframe,percFlu(1:trigertime*actualframerate,:,i))/(trigertime-timeperframe); %baseline
                         percFlu_amp_stim(i,:)=trapz(timeperframe,percFlu(intstart*actualframerate+1:frameend,:,i))/(intdur-timeperframe);
                    end
                    percFlu_amp=percFlu_amp_stim(:,:)-percFlu_amp_base(:,:);
            end
        case 'peak'
            for i=1:size(percFlu,2)
                percFlu_amp(:,i)=max(percFlu(pretrigframe+1:stimendframe,i,:),[],1); % previous to end
            end
    end


    %sort data with same type of the stimulation

    sortdata=[];
    sortdata = sortonstim(sortdata, F_Fneucorr3D, 2, stim_sequence);
    sortdata = sortonstim(sortdata, percFlu, 2, stim_sequence);
    sortdata = sortonstim(sortdata, percFlu_amp, 2, stim_sequence);


    % sortSF=struct([]);

    % if stimtype==5
    %      for i=1:uniquestimnum_SF
    %          trialindex_SF=find(abs(stim_sequence_SF-0.01*(2^i))<10^-8);
    %          sortSF(i).percFlu=percFlu(:,trialindex_SF,:); 
    %          stim_sequence_OSinSF=stim_sequence_OS(trialindex_SF);
    %          
    %          for j=1:uniquestimnum_OS
    %              trialindex_OS=find(abs(stim_sequence_OSinSF-(j-1)*angledif-offset)<10^-8);
    %              sortSF(i).sortOS(j).percFlu=sortSF(i).percFlu(:,trialindex_OS,:);   
    %           end
    %      end
    % else
    %     for i=1:uniquestimnum
    %         trialindex=find(abs(stim_sequence-uniquestim(i))<10^-8);
    %     end      
    %         sortdata(i).absFluGreen=F_Fneucorr3D(:,trialindex,:); % time,rep,roi
    %  end




    %average rep
    if repflag
        recordnum=3;  
    else
        if VLflag
            recordnum=2;
        else
            recordnum=1;
        end
    end
    repnum=trialnum/uniquestimnum/recordnum;
    AVEpercFlu_amp=zeros(ROInum,recordnum,uniquestimnum);  %recordnum means how many times this site is recorded. 1=before VL, 2=repeat before VL, 3=after VL;
    for i=1:ROInum
        for j=1:uniquestimnum
            for k=1:recordnum
                AVEpercFlu_amp(i,k,j)=mean(sortdata.percFlu_amp(i,1+(k-1)*repnum:repnum*k,j),2); 
            end
        end
    end
    sortdata.AVEpercFlu_amp=AVEpercFlu_amp;  


    %reliability  (with the formula)
    MAXpercFlu_amp=zeros(ROInum,recordnum);  %the max value in 8 orientations
    INDofpref=zeros(ROInum,recordnum);       %the index of the prefered (max response) orientation, 1:8=0,45,...,270,315
    MEANofpref=zeros(ROInum,recordnum);      %mean response of 15 repeat of the prefered orientation
    STDofpref=zeros(ROInum,recordnum);       %std of 15 repeat of the prefered orientation
    MEANofblank=zeros(ROInum,recordnum);     %mean response of the blank trial
    STDofblank=zeros(ROInum,recordnum);      %std of the blank trial

    if blankflag

        for i=1:ROInum
            for j=1:recordnum
                [MAXpercFlu_amp(i,j),INDofpref(i,j)]=max(AVEpercFlu_amp(i,j,2:end),[],3);
                MEANofpref(i,j)=mean(sortdata.percFlu_amp(i,1+(j-1)*repnum:repnum*j,(INDofpref(i,j)+1)),2);
                STDofpref(i,j)=std(sortdata.percFlu_amp(i,1+(j-1)*repnum:repnum*j,(INDofpref(i,j)+1)),0,2);
                MEANofblank(i,j)=mean(sortdata.percFlu_amp(i,1+(j-1)*repnum:repnum*j,1),2);
                STDofblank(i,j)=std(sortdata.percFlu_amp(i,1+(j-1)*repnum:repnum*j,1),0,2);

            end
        end
    else
        baseline_med1=zeros(ROInum,1);
        baseline_med2=zeros(ROInum,1);
        BlankpercFlu=zeros(ROInum,pretrigframe,size(sortdata.percFlu_amp,2));
        if repflag==1
           baseline_med3=zeros(ROInum,1);
        end
        for i=1:ROInum
            baseframevalue1=F_Fneucorr3D((1:pretrigframe),1:subrecrdtrialnum,i);
            temp=reshape(baseframevalue1,pretrigframe*subrecrdtrialnum,1);
            baseline_med1(i,1) = median(temp);
            BlankpercFlu(i,:,1:subrecrdtrialnum)=(baseframevalue1-baseline_med1(i,1))/baseline_med1(i,1);
            if VLflag==1
                baseframevalue2=F_Fneucorr3D((1:pretrigframe),subrecrdtrialnum+1:2*subrecrdtrialnum,i);
                temp=reshape(baseframevalue2,pretrigframe*subrecrdtrialnum,1);
                baseline_med2(i,1) = median(temp);
                BlankpercFlu(i,:,subrecrdtrialnum+1:2*subrecrdtrialnum)=(baseframevalue2-baseline_med2(i,1))/baseline_med2(i,1);
            end
            if repflag==1
                baseframevalue3=F_Fneucorr3D((1:pretrigframe),2*subrecrdtrialnum+1:3*subrecrdtrialnum,i);
                temp=reshape(baseframevalue3,pretrigframe*subrecrdtrialnum,1);
                baseline_med3(i,1) = median(temp);
                BlankpercFlu(i,:,2*subrecrdtrialnum+1:3*subrecrdtrialnum)=(baseframevalue3-baseline_med3(i,1))/baseline_med3(i,1);
            end
        end
        BlankpercFlu_amp=zeros(ROInum,trialnum);
        for i=1:ROInum
            BlankpercFlu_amp(i,:)=trapz(timeperframe,BlankpercFlu(i,:,:))/(trigertime-timeperframe); 

        end
        BlankpercFlu_amp=reshape(BlankpercFlu_amp,ROInum,repnum,uniquestimnum,recordnum);
        BlankpercFlu_amp=squeeze(mean(BlankpercFlu_amp,3));

        for i=1:ROInum
            for j=1:recordnum
                [MAXpercFlu_amp(i,j),INDofpref(i,j)]=max(AVEpercFlu_amp(i,j,2:end),[],3);
                MEANofpref(i,j)=mean(sortdata.percFlu_amp(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)),2);
                STDofpref(i,j)=std(sortdata.percFlu_amp(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)),0,2);
                MEANofblank(i,j)=mean(BlankpercFlu_amp(i,:,j),2);
                STDofblank(i,j)=std(BlankpercFlu_amp(i,:,j),0,2);
            end
        end
    end
    RLBpercFlu_amp=(MEANofpref-MEANofblank)./(STDofpref+STDofblank);
    RLBpercFlu_amp=abs(RLBpercFlu_amp);
    sortdata.RLB=RLBpercFlu_amp;

    % %one way anova
    ONE_WAY_ANOVA_p=zeros(ROInum,recordnum);
    JudgeP=zeros(ROInum,recordnum);

    if blankflag
        for i=1:ROInum
            for j=1:recordnum
                percFlu_amp_blanktemp=sortdata.percFlu_amp(i,1+(j-1)*repnum:repnum*j,1);
                percFlu_amp_preftemp=sortdata.percFlu_amp(i,1+(j-1)*repnum:repnum*j,(INDofpref(i,j)+1));
                anovagroup(:,1)=percFlu_amp_blanktemp;
                anovagroup(:,2)=percFlu_amp_preftemp;
                ONE_WAY_ANOVA_p(i,j)=anova1(anovagroup);
                if ONE_WAY_ANOVA_p(i,j)<0.2
                   JudgeP(i,j)=1;
                end
            end
        end
    else
        for i=1:ROInum
            for j=1:recordnum
                percFlu_amp_blanktemp=BlankpercFlu_amp(i,:,j);
                percFlu_amp_preftemp=sortdata.percFlu_amp(i,1+(j-1)*repnum:repnum*j,(INDofpref(i,j)));
                anovagroup(:,1)=percFlu_amp_blanktemp;
                anovagroup(:,2)=percFlu_amp_preftemp;
                ONE_WAY_ANOVA_p(i,j)=anova1(anovagroup);
                if ONE_WAY_ANOVA_p(i,j)<0.2
                   JudgeP(i,j)=1;
                end
            end
        end
    end

    sortdata.ONE_WAY_ANOVA=ONE_WAY_ANOVA_p;
    sortdata.JudgeP=JudgeP;
    sortdata.actualframerate=actualframerate;
    sortdata.actualnumimgsperstim=actualnumimgsperstim;
    sortdata.ampMethod=ampMethod;
    sortdata.baseline_pertrial=baseline_pertrial;
    sortdata.baselinemethod=baselinemethod;
    sortdata.blankflag=blankflag;
    sortdata.INDofpref=INDofpref;
    sortdata.iscell=iscell;
    sortdata.pretrigframe=pretrigframe;
    sortdata.recordnum=recordnum;
    sortdata.redflag=redflag;
    sortdata.repflag=repflag;
    sortdata.repnum=repnum;
    sortdata.sitename=sitename;
    sortdata.stimtime=stimtime;
    sortdata.stimtype=stimtype;
    sortdata.subrecrdtrialnum=subrecrdtrialnum;
    sortdata.timeperframe=timeperframe;
    sortdata.trialnum=trialnum;
    sortdata.trigertime=trigertime;
    sortdata.uniquestim=uniquestim;
    sortdata.uniquestimnum=uniquestimnum;
    sortdata.VLflag=VLflag;
    sortdata.vspara=vspara;
    if saveflag
        createparpath=mkdir([calpath sitename '\' ampMethod]);
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
        %save([calpath sitename '\' ampMethod '\calFoutput.mat'],'calFoutput');    
    end
    
    clearvars -except frameoffset ampMethod baselinemethod calpath moviedataparentpath NPYdataparentpath RunFolderSeq runind saveflag vsparaparentpath
    close all
end
function calFoutput=calFfromROI
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath recordsitepath
globalpara;

RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));
runind=find(cell2mat(RunFolderSeq(:,6)));
for f=1:size(runind,1)
    % changed para for each time
    sitename=RunFolderSeq{runind(f),1};
    %selpath = uigetdir(NPYdataparentpath, 'pick up a dir for NPY file'); % NPY path
    %backslashpos=strfind(selpath, '\');
    %compmoviepath=[moviedataparentpath selpath((pos2(end)+1):pos1(end)+4) '\'];%compressed tif 
    siterecd=table2array(readtable([recordsitepath 'recording.xlsx']));
    %sitename=selpath(backslashpos(end)+1:end);
    siteindex = find(contains(siterecd,sitename));
    beforeVLmoviepath=[moviedataparentpath cell2mat(siterecd(siteindex,2)) '_comp'];
    beforeVLmovie=cell2mat(siterecd(siteindex,2));
    repeatmovie=cell2mat(siterecd(siteindex,3));
    afterVLmovie=cell2mat(siterecd(siteindex,4));
    imagepara=load([beforeVLmoviepath '\imagepara.mat']);
    if imagepara.SI.hFastZ.enable
        stepnum=imagepara.SI.hFastZ.numFramesPerVolume; %slice per volume
        NPYcombinepath=[NPYdataparentpath sitename '\suite2p\combined\'];
        NPYpath=cell(1,stepnum);
        for s=1:stepnum
            NPYpath{1,s}=[NPYdataparentpath sitename '\suite2p\plane' num2str(s-1,'%d') '\'];            
        end
        bind=imagepara.bind;
        if bind
            RegTifpath=cell(1,stepnum);              
            filelistsub={};
            for s=1:stepnum
                RegTifpath{1,s}=[NPYpath{1,s} 'reg_tif\'];% registered tif
                TIFfilelist=dir(RegTifpath{1,s}); %registered tif
                filelistsubtemp=cell(1,length(TIFfilelist));
                for i=1:length(TIFfilelist)
                    filelistsubtemp{1,i}=[TIFfilelist(i).name];
                    if isempty(strfind(TIFfilelist(i).name, '.tif'))
                        filelistsubtemp{1,i}=[];
                    end
                end
                
                filelistsubtemp=filelistsubtemp(~cellfun('isempty',filelistsubtemp));
                filelistsub(s,:)=filelistsubtemp;                
            end
            
        else
            RegTifpath=cell(1,stepnum);
            RegRedTifpath=cell(1,stepnum);               
            filelistsub={};
            filelistsubRed={};
            for s=1:stepnum
                RegTifpath{1,s}=[NPYpath{1,s} 'reg_tif\'];% registered tif
                RegRedTifpath{1,s}=[NPYpath{1,s} 'reg_tif_chan2\'];
                TIFfilelist=dir(RegTifpath{1,s}); %registered tif
                TIFRedfilelist=dir(RegRedTifpath{1,s}); %registered tif
                filelistsubtemp=cell(1,length(TIFfilelist));
                filelistsubRedtemp=cell(1,length(TIFRedfilelist));
                %green(function) channel
                for i=1:length(TIFfilelist)
                    filelistsubtemp{1,i}=[TIFfilelist(i).name];
                    if isempty(strfind(TIFfilelist(i).name, '.tif'))
                        filelistsubtemp{1,i}=[];
                    end
                end  
                filelistsubtemp=filelistsubtemp(~cellfun('isempty',filelistsubtemp));
                filelistsub(s,:)=filelistsubtemp; 
                
                %red channel
                for i=1:length(TIFRedfilelist)
                    filelistsubRedtemp{1,i}=[TIFRedfilelist(i).name];
                    if isempty(strfind(TIFRedfilelist(i).name, '.tif'))
                        filelistsubRedtemp{1,i}=[];
                    end
                end                
                filelistsubRedtemp=filelistsubRedtemp(~cellfun('isempty',filelistsubRedtemp));
                filelistsubRed(s,:)=filelistsubRedtemp;                 
            end            
        end 
        
        channelnum=imagepara.SI.numofchan;  
        maxsubframe=zeros(1, stepnum);
%         iscell=[];
        totalframe=zeros(1, stepnum); % total number of frames in the experiments
        for s=1:stepnum        
            for i=1:length(filelistsub(s,:)) %registered tif
                info=imfinfo([RegTifpath{1,s} filelistsub{s,i}]);
                totalframe(1,s) = totalframe(1,s)+size(info,1);
                if size(info,1)>maxsubframe(1,s)
                    maxsubframe(1,s)=size(info,1);
                end
                imsize=[info(1).Height info(1).Width];
            end
%             endnum=size(iscell,1);
%             iscelltemp=readNPY([NPYpath{1,s} 'iscell.npy']);
            
%             subtotalROInum(1,s)=size(iscelltemp,1);
%             iscell(endnum+1:endnum+subtotalROInum(1,s),:)=iscelltemp;
            
        end
        iscell=readNPY([NPYcombinepath 'iscell.npy']);
        ROIindex=find(abs(iscell(:,1)-1)<10^-6); % one based
        ROInum=length(ROIindex);
        F=readNPY([NPYcombinepath 'F.npy']);
        F(iscell(:,1)==0,:)=[];
%          
        if bind  %do not update for fast z yet
            F_combine=zeros(totalframe,ROInum, channelnum); %chan1, chan2
            for i=1:totalframe
                TIFfileindex=floor((i-1)/maxsubframe)+1;
                subframeindex=rem(i-1,maxsubframe)+1;
                temp=double(imread([RegTifpath filelistsub{TIFfileindex}],subframeindex)); %read the registered tif file
                for j=1:ROInum
                    xpix=stat{ROIindex(j)}.xpix;
                    ypix=stat{ROIindex(j)}.ypix;
                    lam=stat{ROIindex(j)}.lam;
                    overlap=stat{ROIindex(j)}.overlap;
                    eff_xpix=xpix(~overlap);
                    eff_ypix=ypix(~overlap);
                    eff_lam=lam(~overlap);
                    for p=1:channelnum % 1, Green; 2, red
                        indexpix=sub2ind(imsize, eff_ypix+1, eff_xpix+1+(p-1)*imsize(2)/channelnum);
                        F_combine(i,j,p)=sum(temp(indexpix).*eff_lam)/sum(eff_lam);  %i=framenum, j=ROI number, p=2 channels It was accumulated fluorescence. should be weighted average
                    end
                end
            end
        else
            endnum=0; %number of ROI in previous slices
            
            F_combine=zeros(totalframe(1,s),ROInum,channelnum);
            subtotalCellnum=zeros(1,stepnum+1);
            for s=1:stepnum
                Falltemp=load([NPYpath{1,s} 'Fall.mat']);
                %stat=Falltemp.stat;
                %iscellsub=readNPY([NPYpath{1,s} 'iscell.npy']);
                subtotalCellnum(1,s+1)=size(Falltemp.F,1);
                ROIindexsub=find(abs(iscell((subtotalCellnum(1,s)+1):(subtotalCellnum(1,s)+subtotalCellnum(1,s+1)),1)-1)<10^-6);                
                
                Fallcombine=load([NPYcombinepath 'Fall.mat']);  
                stat=Fallcombine.stat;
                F_combine_temp=zeros(totalframe(1,s),size(ROIindexsub,1), channelnum);
                for i=1:totalframe(1,s)
                    TIFfileindex=floor((i-1)/maxsubframe(s))+1;
                    subframeindex=rem(i-1,maxsubframe(s))+1;
                    tempG=double(imread([RegTifpath{1,s} filelistsub{s,TIFfileindex}],subframeindex)); %read Green channel registered figure
                    tempR=double(imread([RegRedTifpath{1,s} filelistsubRed{s,TIFfileindex}],subframeindex)); %read Red channel registered figure
                    for j=1:size(ROIindexsub,1)
                        if s==1
                            xpix=stat{subtotalCellnum(1,s)+ROIindexsub(j)}.xpix;
                        elseif s==2
                            xpix=stat{subtotalCellnum(1,s)+ROIindexsub(j)}.xpix-imsize(1,1);
                        end
                        ypix=stat{subtotalCellnum(1,s)+ROIindexsub(j)}.ypix;
                        lam=stat{subtotalCellnum(1,s)+ROIindexsub(j)}.lam;
                        overlap=stat{subtotalCellnum(1,s)+ROIindexsub(j)}.overlap;
                        eff_xpix=xpix(~overlap);
                        eff_ypix=ypix(~overlap);
                        eff_lam=lam(~overlap);
                        indexpix=sub2ind(imsize, eff_ypix+1, eff_xpix+1);
                        F_combine_temp(i,j,1)=sum(tempG(indexpix).*eff_lam)/sum(eff_lam);  %i=framenum, j=ROI number, 2 channels It was accumulated fluorescence. should be weighted average
                        F_combine_temp(i,j,2)=sum(tempR(indexpix).*eff_lam)/sum(eff_lam);             
                    end
                end                
                F_combine(:,endnum+1:endnum+size(ROIindexsub,1),:)=F_combine_temp;
                endnum=endnum+size(ROIindexsub,1);
            end
        end
        
        %stat=Falltemp.stat;
        stat={};
        for s=1:stepnum
            endnum=size(stat,2);
            Falltemp=load([NPYpath{1,s} 'Fall.mat']);  
            stattemp=Falltemp.stat;            
            subtotalROInum(1,s)=size(stattemp,2);
            stat(1,endnum+1:endnum+subtotalROInum(1,s))=stattemp;
            
        end
        
        Falltemp=load([NPYcombinepath 'Fall.mat']);
        
        
    else        
        NPYpath=[NPYdataparentpath sitename '\suite2p\plane0\'];
    
        bind=imagepara.bind;
        if bind
            RegTifpath=[NPYpath 'reg_tif\'];% registered tif
            TIFfilelist=dir(RegTifpath); %registered tif
            filelistsub={};
            for i=1:length(TIFfilelist)
                if ~isempty(strfind(TIFfilelist(i).name, '.tif'))
                    filelistsub=[filelistsub TIFfilelist(i).name];
                end
            end
        else
            RegTifpath=[NPYpath 'reg_tif\'];
            RegRedTifpath=[NPYpath 'reg_tif_chan2\'];
            TIFfilelist=dir(RegTifpath); %registered tif
            filelistsub={};
            for i=1:length(TIFfilelist)
                if ~isempty(strfind(TIFfilelist(i).name, '.tif'))
                    filelistsub=[filelistsub TIFfilelist(i).name];
                end
            end
            TIFRedfilelist=dir(RegRedTifpath); %registered tif
            filelistsubRed={};
            for i=1:length(TIFRedfilelist)
                if ~isempty(strfind(TIFRedfilelist(i).name, '.tif'))
                    filelistsubRed=[filelistsubRed TIFRedfilelist(i).name];
                end
            end
        end
    
        %channelnum=imagepara.channum;    
        channelnum=imagepara.SI.numofchan;
        totalframe=0;
        maxsubframe=0;
        for i=1:length(filelistsub) %registered tif
            info=imfinfo([RegTifpath filelistsub{i}]);
            totalframe = totalframe+size(info,1);
            if size(info,1)>maxsubframe
                maxsubframe=size(info,1);
            end
            imsize=[info(1).Height info(1).Width];
        end

        iscell=readNPY([NPYpath 'iscell.npy']);
        ROIindex=find(abs(iscell(:,1)-1)<10^-6); % one based
        ROInum=length(ROIindex);
        F=readNPY([NPYpath 'F.npy']);
        F(iscell(:,1)==0,:)=[];
        Falltemp=load([NPYpath 'Fall.mat']);
        stat=Falltemp.stat;

        F_combine=zeros(totalframe,ROInum, channelnum); %chan1, chan2
        if bind
            for i=1:totalframe
                TIFfileindex=floor((i-1)/maxsubframe)+1;
                subframeindex=rem(i-1,maxsubframe)+1;
                temp=double(imread([RegTifpath filelistsub{TIFfileindex}],subframeindex)); %read the registered tif file
                for j=1:ROInum
                    xpix=stat{ROIindex(j)}.xpix;
                    ypix=stat{ROIindex(j)}.ypix;
                    lam=stat{ROIindex(j)}.lam;
                    overlap=stat{ROIindex(j)}.overlap;
                    eff_xpix=xpix(~overlap);
                    eff_ypix=ypix(~overlap);
                    eff_lam=lam(~overlap);
                    for p=1:channelnum % 1, Green; 2, red
                        indexpix=sub2ind(imsize, eff_ypix+1, eff_xpix+1+(p-1)*imsize(2)/channelnum);
                        F_combine(i,j,p)=sum(temp(indexpix).*eff_lam)/sum(eff_lam);  %i=framenum, j=ROI number, p=2 channels It was accumulated fluorescence. should be weighted average
                    end
                end
            end
        else
            for i=1:totalframe
                TIFfileindex=floor((i-1)/maxsubframe)+1;
                subframeindex=rem(i-1,maxsubframe)+1;
                tempG=double(imread([RegTifpath filelistsub{TIFfileindex}],subframeindex)); %read Green channel registered figure
                tempR=double(imread([RegRedTifpath filelistsubRed{TIFfileindex}],subframeindex)); %read Red channel registered figure
                for j=1:ROInum
                    xpix=stat{ROIindex(j)}.xpix;
                    ypix=stat{ROIindex(j)}.ypix;
                    lam=stat{ROIindex(j)}.lam;
                    overlap=stat{ROIindex(j)}.overlap;
                    eff_xpix=xpix(~overlap);
                    eff_ypix=ypix(~overlap);
                    eff_lam=lam(~overlap);
                    indexpix=sub2ind(imsize, eff_ypix+1, eff_xpix+1);
                    F_combine(i,j,1)=sum(tempG(indexpix).*eff_lam)/sum(eff_lam);  %i=framenum, j=ROI number, 2 channels It was accumulated fluorescence. should be weighted average
                    F_combine(i,j,2)=sum(tempR(indexpix).*eff_lam)/sum(eff_lam);             
                end
            end
        end
    end
    
    % F_combine(:,:,channelnum+1)=F';
    %compF(F_combine, F);
    calFoutput.F_combine=F_combine;
    calFoutput.F=Falltemp.F;
    calFoutput.Fneu=Falltemp.Fneu; % This is wrong. It has to be calculated. otherwise its unit is not the same as F_combine
    calFoutput.spks=Falltemp.spks;
    calFoutput.iscell=iscell;
    %calFoutput.selpath=selpath;
    calFoutput.imagepara=imagepara;
    calFoutput.stat=stat;
    calFoutput.sitename=sitename;
    calFoutput.beforeVLmovie=beforeVLmovie;
    calFoutput.repeatmovie=repeatmovie;
    calFoutput.afterVLmovie=afterVLmovie;
    createpath=mkdir([calpath sitename]);
    save([calpath sitename '\calFoutput.mat'],'calFoutput');
    clearvars -except NPYdataparentpath moviedataparentpath vsparaparentpath calpath recordsitepath RunFolderSeq runind
%     close all
end


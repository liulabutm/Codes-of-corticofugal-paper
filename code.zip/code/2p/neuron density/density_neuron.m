function density_neuron (brain_layer)
%% input
%%brain_layer
%   5: use allenmap_layer5 as the standard area map
%   1: use allenmap_layer5 as the standard area map
if nargin<1
    brain_layer=5;
end

%% set parameters
%%excel naming rule: brain slice following the only "-" in the name, and ends right before ".xlsx"

%neuron_location_folders: the folder where the excel files are

% 3 control mouses
neuron_location_folders={'E:\imaging facility\Jiashu\AX_m2\match\neuron_location_excel';...
                                            'E:\imaging facility\Jiashu\AX_m3\match\neuron_location_excel';...
                                            'E:\imaging facility\Jiashu\AY_m0\match\neuron_location_excel'};

% 4 projecting mouses
% neuron_location_folders={'E:\imaging facility\Jiashu\181205\new match\neurons location excel';...
%                                             'E:\imaging facility\Jiashu\191114\match\Female m0\neurons location excel';...
%                                             'E:\imaging facility\Jiashu\191114\match\Male m1\neurons location excel';...
%                                             'E:\imaging facility\Jiashu\200908_roundAK_m3\match\neuron_location_excel'};                                        
                                        
                                        
savepath='E:\two-photon imaging\jiashu\data\retro_tracing';
%%grid_size: the length side length of each square grid under standard allen_map
step=100; 
%the value need to be fixed (100) for current area calculation(getting outline_img)
%need to be a multiple of 100 to do neuron cell count

%%cortex outline (left) image folder
if brain_layer==5
    outline_folder='E:\two-photon imaging\jiashu\data\retro_tracing\layer4_5';
    PL_folder='F:\Lab\Baohua Liu Lab\code\mapping - for jiashu\allen map\layer5_PL_outline'; %not used in code, for reference only
end

%allenmap folder
global  allenmap_folder 
globalpara;
%load in boundary map
if brain_layer==5
    allenmap=load([allenmap_folder '\allenmap_layer5.mat']); %this should be the same unless you change the boudary image
else
    allenmap=load([allenmap_folder '\allenmap_layer1.mat']); 
end
%first collum: area name
%second collum: boundary coordinates

%area code
Areacode={'1', 'VISp';  '2', 'VISI';  '3', 'VISli'; '4', 'VISpor'; '5', 'VISpl'; '6', 'VISal'; '7', 'VISrl';...
            '8', 'VISa'; '9', 'VISam'; '10', 'VISpm'; '11', 'midline'; '12', 'inner_edge';'13', 'outer_edge'};
        
%bregma distance from the start of cortex
Bregma=3380;

%% grab neuron location excels
%concatenate excel results
%Excel columns: Type	Slice	X	Y	Value	C-pos	Z-pos	T-pos	X(inch)	Y(inch)	Z(inch)
%         Type: area code
%          X: the x coordinates ----- midline is parallel to y axis, so only x values are needed for distance calculations
%          other values are not used in this script

neuron_location=[];
%neuron_location matrix will have columns:
%       1. which brain slice (mouse atlas slice) a neuron is on
%       2. the area code of the neuron
%       3. the measured distance from midline

slice_para=[];
%slice_para matrix will have columns:
%       1. which brain slice (mouse atlas slice) a neuron is on
%       2. inner_edge distance from midline: area code 12
%       3. outer_edge distance from midline: area code 13

for m=1 : length(neuron_location_folders)
    single_folder=neuron_location_folders{m};
    cd(single_folder)
    %obtain neuron coordinates excels 
    %excelfiles = dir('*.xlsx'); 
    excelfiles = dir('*.csv');
    excellist=string({excelfiles(~[excelfiles.isdir]).name})';%the names for all excel files

    for i = 1:length(excellist)
        excelname=excellist{i};
        %start_ind = strfind(excelname,'-')+1; %slice number start after the only '-' in the name
        start_ind=strfind(excelname,'atlas')+6;
        %end_ind = strfind(excelname,'.xls')-1; %slice number end right before '.xls' or '.xlsx'
        end_ind = strfind(excelname,'.csv')-1;
        slice_ind=str2double(excelname(start_ind:end_ind));
        excel_temp=table2array(readtable(excelname));
        %excel_temp=csvread(excelname);
        
        %excel_temp = xlsread(excelname); 
        midline=excel_temp(excel_temp(:,1)==11,3); % area code for midline is 11
            %midline is to the right of neruons and the inner and outer edge of the
        %left hemisphere, so the x value for midline is always the largest
        neuron_dis=[excel_temp(excel_temp(:,1)<11,1), (midline-excel_temp(excel_temp(:,1)<11,3))]; %area code for VIS areas are 1-10
        neuron_dis= [(zeros(size(neuron_dis,1),1)+slice_ind),neuron_dis];
        inner_edge_dis=midline-excel_temp(excel_temp(:,1)==12,3); % area code for inner edge is 12
        if inner_edge_dis <0 %sometimes the inned_edge is too close to midline and give some minor measuring fluctuations
            inner_edge_dis = 0; %for distance to 0 if this happens
        end
        outer_edge_dis=midline-excel_temp(excel_temp(:,1)==13,3); % area code for outer edge is 13
        slice_dis=[slice_ind inner_edge_dis outer_edge_dis];
        neuron_location=[neuron_location; neuron_dis];
        slice_para=[slice_para; slice_dis];
    end
end

%% grab layer 5 outline image and excel
cd(outline_folder)
%obtain outline image matrix 
imgfiles = dir('*.jpg'); 
imglist=string({imgfiles(~[imgfiles.isdir]).name})';%the names for all jpg files

outline_struct=struct;
for i = 1:length(imglist)
    imgname=imglist{i};
    start_ind = strfind(imgname,'-')+1; %slice number start after the only '-' in the name
    end_ind = strfind(imgname,'.jpg')-1; %slice number end right before '.jpg'
    slice_temp=imgname(start_ind:end_ind);
    outline_struct.(['atlas' slice_temp])=imread(imglist{i});
end

midline_position=xlsread([outline_folder '\midline position.xlsx']);
%1st column: slice number
%2nd column: midline pixel
%3rd column: inner edge pixel (left)
%4th column: outer edge pixel (left)


%% calculate the standardized coordinates in micron
%%startard values - according to allenmap
%total 85 (slice 19-104)  intervals (100nm / slice) of brain slices with 50nm added before the first slice and after the last slice
standard_para=[allenmap.allenmap(1,:)', ((allenmap.allenmap(1,:)'-19)*100+50),allenmap.allenmap(4,:)',allenmap.allenmap(3,:)'];
%standard_para matrix will have columns:
%       1. slice number
%       2. anterior-posterior position each slice is on
%       3. inner_edge distance from midline: area code 12
%       4. outer_edge distance from midline: area code 13

 %%calculate the standardized top-down coordinates of neuron
 neurons=nan(size(neuron_location,1),4);
 % top-down coordinates of neurons
 %          1st column: slice number
 %          2nd column: area code
 %          3rd column: x coordinates - indicate anterior posterior position
 %          4th column: y coordinates - indicate lateral position
 
for n = 1:size(neuron_location,1)  
       %use the ratio (neuron-inner_edge)/(outer_edge-inner_edge) to
       %calculate the standardized neuron coordinates on standard allanmap
       neurons(n,1:2)=neuron_location(n,1:2);
       slice_num_temp=neuron_location(n,1);
       mouse_inner_edge=slice_para((slice_para(:,1)==slice_num_temp),2);
       if length(mouse_inner_edge)>1 %sometimes one brain slice have more than one excels 
           mouse_inner_edge=mean(mouse_inner_edge);
       end
       mouse_outer_edge=slice_para((slice_para(:,1)==slice_num_temp),3);
       if length(mouse_outer_edge)>1 %sometimes one brain slice have more than one excels 
           mouse_outer_edge=mean(mouse_outer_edge);
       end
       standard_inner_edge= standard_para((standard_para(:,1)==slice_num_temp),3);
       standard_outer_edge= standard_para((standard_para(:,1)==slice_num_temp),4);
       neurons(n,4)=(neuron_location(n,3)-mouse_inner_edge)/(mouse_outer_edge - mouse_inner_edge) * (standard_outer_edge - standard_inner_edge) +standard_inner_edge;
       neurons(n,3)=standard_para((standard_para(:,1)==slice_num_temp),2);
end

%% calculate neuron density in small grids (standard allen map, top-down view)
ML_num=ceil((max(neurons(:,4))-min(neurons(:,4)))/step); %round to nearest integer greater than or equal to the division
AP_num=ceil((max(neurons(:,3))-min(neurons(:,3)))/step);
ML_start=min(neurons(:,4));
AP_start=min(neurons(:,3));

grid_ind=neurons(:,3:4);
grid_ind(:,1)=ceil((neurons(:,3)-AP_start)/step);%AP
grid_ind(:,2)=ceil((neurons(:,4)-ML_start)/step);%ML

density=[];
%initiate density matrix
%   1st: anterial x coordinate of the grid, the posterior coordinate will  be anterial + grid_size
%   2nd: medial y coordinate of the grid, the lateral coordinate will  be medial + grid_size
%   3rd: neuron number within in the grid
%   4th brian layer 5 "surface area" in the grid
%   5th: neuron density within in the grid

for i = 1: AP_num 
    AP_mid=AP_start+(i-1)*step;
    slice_ind=unique(neurons(neurons(:,3)==AP_mid,1)); %get slice number
    outline_img=outline_struct.(['atlas' num2str(slice_ind)]);
    midline_pix=midline_position(midline_position(:,1)==slice_ind,2);
    outline_img=outline_img(:,1:midline_pix);%get corresponding ouline the left hemisphere of the brain
    outline_img=flip(outline_img,2); %set midline to 0 pixel ----- midline is also 0 on the top-down view
    outline_ind=[];
    %first column is the outline row index, second column is the outline column index
    [outline_ind(:,1),outline_ind(:,2)]=find(outline_img==0); 
    
    %%when estimating legnth ---- linear regression (slope) & grid_size (cos) 
    for j = 1: ML_num  
        %%in coronal view, row is the depth and column is the medial-lateral position 
        %the brain outline is continuous, however the mannual drawing may
        %leave gaps between two pixel points on an outline
        ML_medial=ML_start+(j-1)*step; 
        [~, ML_medial_ind]=min(abs(outline_ind(:,2)-ML_medial)); %row ind  of outline ind           
        ML_lateral=ML_medial+step;
        [~, ML_lateral_ind]=min(abs(outline_ind(:,2)-ML_lateral)); 

        %use regression line between ML_medial and ML_lateral to calculate slope
        [~,slope,~] = regression(outline_ind(ML_medial_ind:ML_lateral_ind,2)',outline_ind(ML_medial_ind:ML_lateral_ind,1)');
        area= step * step/cos(atan(slope));
        %%assume the actual surface area to be rectangular 
        %ML_step/cos(atan(slope)): for the actual medial - lateral length along the layer 5 cortex
        %step for anterior - posterior length 
        %%assume the acutal surface length is a straight line in each grid,
        %and is the hypotenuse of the right triangle formed by the lateral width of each grid (on the brain top-down view), and the depth
        %difference of grid (the difference of depths of the two lateral edge of each grid in coronal slice view)
        neurons_num=sum(grid_ind(:,1)==i&grid_ind(:,2)==j ); %count the number of neurons in each grid for all animals
        density=[density; [AP_mid, ML_medial, neurons_num, area, neurons_num/area/length(neuron_location_folders)]]; 
    end
end
density(isnan(density))=0; % only the outline of visual cortex is drawn, so the nans are areas outisde of visual cortex but set as grids

%% adjust neuorn density for grids within VISpl
%part of VISpl layer 5 is beneath VISp in topview
%compressed all VISpl layer5 to lateral side of VISp for density may display
%thus the area need to be recalculated based on ratio between layer45
%boundary (boundary in topview map) and the actual layer 5 boudary

%read in PL tansform matrix from allen map
layer45boundary_lengths=allenmap.PL_trans_mat.layer45boundary_lengths;
actual_layer5boundary_lengths=allenmap.PL_trans_mat.actual_layer5boundary_lengths;
slice_AP=allenmap.PL_trans_mat.slice_AP;

%%recalculate actual PL area for each PL grid
%density: AP_mid, ML_medial, neurons_num, area, neurons_num/area/length(neuron_location_folders)
PL_ind=find(~cellfun(@isempty,strfind(allenmap.boundaries(:,1),'VISpl')));%get VISpl boundary coordinate
PL_boundary=allenmap.boundaries{PL_ind,2};
for i=1:size(density,1) 
    slice_PL_boundary_ind=find(PL_boundary(1,:)-density(i,1)==0); %get the start and end point of VISpl on corresponding brain slice
    if ~isempty(slice_PL_boundary_ind) %check if the mid-point of the grid is on brain slice containing VISpl
        PL_slice_medial=min(PL_boundary(2,slice_PL_boundary_ind)); %medial coordiante of topview VISpl on corresponding slice
        PL_slice_lateral=max(PL_boundary(2,slice_PL_boundary_ind));%lateral coordiante of topview VISpl on corresponding slice
        if density(i,2)+100>PL_slice_medial & (density(i,2)+step)<PL_slice_lateral %adjust actual area if parts of the grid is in VISpl
            %since the VISpl is conpression uniformly on each brain slice
            %and the thickness of each brain slice is fixed
            %the ratio between the actual area of each topview grid is the
            %same as the ratio between the length of actual layer5 boundary
            %and the legnth of layer4,5 boundary
            slice_ind=find(slice_AP(:,2)==density(i,1));
            density(i,4)=density(i,4)/layer45boundary_lengths(slice_ind,2)*actual_layer5boundary_lengths(slice_ind,2);
            density(i,5)=density(i,3)/density(i,4)/length(neuron_location_folders);
        end
    end
end

% 
% density(628:660,3)=density(628:660,3)/2;
% density(826:858,3)=density(826:858,3)/2;
% density(892:924,3)=density(892:924,3)/2;
%% calculate the neuron density for each visual area
Visual_area_density=[];
%1st: areacode
%2nd: neuron counts
%3rd: neuron density

for i=1:size(Areacode,1)
    area_type=str2num(Areacode{i,1});
    if area_type<11
        neuron_count=sum(neuron_location(:,2)==area_type);
        vis_area=Areacode{i,2};
        actual_area=allenmap.actual_area{find(double(strcmp(string(allenmap.actual_area(:,1)),vis_area))),2};
        Visual_area_density=[Visual_area_density; [area_type neuron_count neuron_count/actual_area/length(neuron_location_folders)]];
    end
end
T=num2cell(Visual_area_density);
T(:,1)=Areacode(1:10,2);
T=cell2table(T);
T.Properties.VariableNames={'area','neuron_num','density'};
cd(savepath)
writetable(T,'density per area.xlsx','Sheet',1,'Range','D1')

%% density in gray scle on brain top-down view
figure
title('neuron density')
hold on;
%plot gray scale2
density(:,1)=density(:,1)-Bregma; %change start coordinate to bregma
for n=1 : size(density,1)
    grid{n} = polyshape([density(n,1);density(n,1)+step;density(n,1)+step;density(n,1)], [density(n,2);density(n,2);density(n,2)+step;density(n,2)+step]);
    if ~isnan(density(n,5))
         color_val=[1,1,1]-density(n,5)/max(density(:,5)); %white is 1
    else
        color_val=[1 1 1];
    end
    plot(grid{n}, 'FaceColor', color_val, 'FaceAlpha',1, 'EdgeAlpha',0)
end

Tick_label=([0:11]*max(density(:,5))/10*10^3)';
Tick_label=round(Tick_label,2);
c=flip(gray);
colormap (c)
c=colorbar('Ticks', [0:0.1:1],'TickLabels', num2str(Tick_label))
c.Label.String = 'density (10^-3 neurons/um^2)';

%plot allen map
color_mat={'blue','blue','red', 'red','red','red','black','blue','blue','blue'};
for n = 1: size(allenmap.boundaries,1) 
    shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)'-Bregma,allenmap.boundaries{n,2}(2,:)');%x,y %change start coordinate to bregma
    plot(shape{n},'FaceAlpha',0,'EdgeColor',color_mat{n},'Linewidth',1)
end

saveas(gcf,'density.fig','fig')
saveas(gcf,'density.tiff','tif')

end
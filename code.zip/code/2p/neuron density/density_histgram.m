% density histgram


%%excel naming rule: brain slice following the only "-" in the name, and ends right before ".xlsx"

%neuron_location_folders: the folder where the excel files are

% 3 control mouses
neuron_location_folders={'E:\imaging facility\Jiashu\AX_m2\match\neuron_location_excel';...
                                            'E:\imaging facility\Jiashu\AX_m3\match\neuron_location_excel';...
                                            'E:\imaging facility\Jiashu\AY_m0\match\neuron_location_excel'};

% 4 projecting mouses
% neuron_location_folders={'E:\imaging facility\Jiashu\181205\new match\neurons location excel';...
%                                             'E:\imaging facility\Jiashu\191114\match\Female m0\neurons location excel';...
%                                             'E:\imaging facility\Jiashu\191114\match\Male m1\neurons location excel';...
%                                             'E:\imaging facility\Jiashu\200908_roundAK_m3\match\neuron_location_excel'};                                        
                                        

%area code
Areacode={'1', 'VISp';  '2', 'VISI';  '3', 'VISli'; '4', 'VISpor'; '5', 'VISpl'; '6', 'VISal'; '7', 'VISrl';...
            '8', 'VISa'; '9', 'VISam'; '10', 'VISpm'; '11', 'midline'; '12', 'inner_edge';'13', 'outer_edge'};
        
%bregma distance from the start of cortex


%% grab neuron location excels
%concatenate excel results
%Excel columns: Type	Slice	X	Y	Value	C-pos	Z-pos	T-pos	X(inch)	Y(inch)	Z(inch)
%         Type: area code
%          X: the x coordinates ----- midline is parallel to y axis, so only x values are needed for distance calculations
%          other values are not used in this script

all_mouse_summary={};
all_mouse_area_summary=[];
for m=1 : length(neuron_location_folders)
    single_folder=neuron_location_folders{m};
    cd(single_folder)
    %obtain neuron coordinates excels 
    %excelfiles = dir('*.xlsx'); 
    excelfiles = dir('*.csv');
    excellist=string({excelfiles(~[excelfiles.isdir]).name})';%the names for all excel files
    neuron_num_summary=zeros(size(excellist,1),10); %1st: slice , 2nd: areas
    for i = 1:length(excellist)
        excelname=excellist{i};       
        excel_temp=table2array(readtable(excelname));
        area_unique=unique(excel_temp(:,1));
        area_unique=area_unique(1:end-3);% remove the last: midline, inner and outer edge
        neurons_num=[];
        for j=1:size(area_unique,1)
            neurons_num(j,1)=sum(excel_temp(:,1)==area_unique(j));
            neuron_num_summary(i,area_unique(j))=neurons_num(j,1);
        end
       
    end
    all_mouse_summary{m}=neuron_num_summary;
    all_mouse_area_summary(m,:)=sum(neuron_num_summary,1);
end


%% randomization test 
global figure_path
globalpara;
         
folder_list=table2cell(readtable([figure_path '\2p prefer direction distribution\' 'folder_names.xlsx']));

runind=strfind((cell2mat(folder_list(:,2)))',1);  %find which one to run          
neurontype='ventral';  % all or V1 or ventral


%% TN direction and horizontal orientation has more neurons than other directions and orientations in projecting gourp than control group
for f=1:size(runind,2)
    foldername=folder_list{runind(f),1};    
    % load in
    load([figure_path '\2p prefer direction distribution\' foldername '\prefdir_projecting.mat']);
    load([figure_path '\2p prefer direction distribution\' foldername '\prefdir_control.mat']);

    numofangle=8;
    anglestep=360/numofangle;
    x=0:(anglestep):(360-anglestep);
    sim_ite=1000000;

    % experimental group
    switch neurontype
        case 'all'
            prefDir_projecting=prefdir_projecting.prefdir_mix_load(prefdir_projecting.prefdir_mix_load~=-100);
        case 'V1'
            prefDir_projecting=prefdir_projecting.prefdir_mix_indv_areas(prefdir_projecting.prefdir_mix_indv_areas(:,1)~=-100,1);
        case 'ventral'
            prefDir_projecting=prefdir_projecting.prefdir_mix_ventral(prefdir_projecting.prefdir_mix_ventral~=-100);
    end

    N_exp=hist(prefDir_projecting,x); 
    figure;bar(N_exp);
    per_exp=N_exp/sum(N_exp);

    % control group
    switch neurontype
        case 'all'
            prefDir_control=prefdir_control.prefdir_mix_load(prefdir_control.prefdir_mix_load~=-100);
        case 'V1'
            prefDir_control=prefdir_control.prefdir_mix_indv_areas((prefdir_control.prefdir_mix_indv_areas(:,1)~=-100),1);
            prefDir_control=prefDir_control(prefDir_control~=0);
        case 'ventral'
            prefDir_control=prefdir_control.prefdir_mix_ventral(prefdir_control.prefdir_mix_ventral~=-100);
    end
    N_control=hist(prefDir_control,x);
    figure;bar(N_control);
    per_control=N_control/sum(N_control);

    N_total=N_exp+N_control;


    cat_prefDS=[];
    for i=1:length (N_total)
        cat_prefDS=[cat_prefDS, ones(1,N_total(i))*i];
    end

    oridiff=zeros(length(x)/2,sim_ite); 
    dirdiff=zeros(length(x),sim_ite);
    hor=zeros(1,sim_ite);
    hordiff=zeros(1,sim_ite);
    counttemp=zeros(1,sim_ite);
    for j=1:sim_ite
        [exp_sim,idx] = datasample(cat_prefDS,sum(N_exp),'Replace',false);
        N_exp_sim=hist(exp_sim,1:length(x));
        N_control_sim=N_total-N_exp_sim;
        per_exp_sim=N_exp_sim/sum(N_exp_sim);
        per_control_sim=N_control_sim/sum(N_control_sim);
        counttemp(j)=N_exp_sim(1);
        for k=1:(length(x)/2)
            oridiff(k,j)=((per_exp_sim(1)+per_exp_sim(1+length(x)/2))-(per_exp_sim(k)+per_exp_sim(k+length(x)/2)))-((per_control_sim(1)+per_control_sim(1+length(x)/2))-(per_control_sim(k)+per_control_sim(k+length(x)/2)));
            % (horizontal_exp-anyori_exp)-(horizontal_con-anyori_con)
        end
        for k=1:length(x)
            dirdiff(k,j)=(per_exp_sim(1)-per_exp_sim(k))-(per_control_sim(1)-per_control_sim(k));% hypothesis is that the difference between OR angles is higher in exp group
            % (TN_exp-anydir_exp)-(TN_con-anydir_con)
        end
        hor(j)=per_exp_sim(1)-per_control_sim(1); %hypothesis is that the hozontially preffered cell in the exp is higher than the control
        hordiff(j)=(per_exp_sim(1)-sum(per_exp_sim(2:end)))-(per_control_sim(1)-sum(per_control_sim(2:end))); % the hypothesis is that the horitally preferred cells is more than the rest.
    end
    per_exp_ori=per_exp(1:(length(x)/2))+per_exp((length(x)/2+1):end);
    per_control_ori=per_control(1:(length(x)/2))+per_control((length(x)/2+1):end);
    oridiff_real=(per_exp_ori(1)-per_exp_ori)-(per_control_ori(1)-per_control_ori);
    dirdiff_real=(per_exp(1)-per_exp)-(per_control(1)-per_control);

    ori_pvalue=zeros(1,length(oridiff_real));
    dir_pvalue=zeros(1,length(dirdiff_real));
    for k=1:length(ori_pvalue)
        ori_pvalue(k)=sum(oridiff(k,:)>=oridiff_real(k))/sim_ite; % the first value means nothing
    end
    for k=1:length(dir_pvalue)
        dir_pvalue(k)=sum(dirdiff(k,:)>=dirdiff_real(k))/sim_ite; % the first value means nothing
    end
    hor_real=per_exp(1)-per_control(1);
    hor_pvalue=sum(hor>=hor_real)/sim_ite;
    hordiff_real=(per_exp(1)-sum(per_exp(2:end)))-(per_control(1)-sum(per_control(2:end)));
    hordiff_pvalue=sum(hordiff>=hordiff_real)/sim_ite;

    switch neurontype
        case 'all'
            stat_ran.all.ori_pvalue=ori_pvalue;
            stat_ran.all.dir_pvalue=dir_pvalue;
            stat_ran.all.hor_pvalue=hor_pvalue;
            stat_ran.all.hordiff_pvalue=hordiff_pvalue;
            stat_ran.all.sim_ite=sim_ite;
        case 'V1'
            load([figure_path '\2p prefer direction distribution\' foldername '\stat_ran.mat']);
            stat_ran.V1.ori_pvalue=ori_pvalue;
            stat_ran.V1.dir_pvalue=dir_pvalue;
            stat_ran.V1.hor_pvalue=hor_pvalue;
            stat_ran.V1.hordiff_pvalue=hordiff_pvalue;
            stat_ran.V1.sim_ite=sim_ite;
        case 'ventral'
            load([figure_path '\2p prefer direction distribution\' foldername '\stat_ran.mat']);
            stat_ran.ventral.ori_pvalue=ori_pvalue;
            stat_ran.ventral.dir_pvalue=dir_pvalue;
            stat_ran.ventral.hor_pvalue=hor_pvalue;
            stat_ran.ventral.hordiff_pvalue=hordiff_pvalue;
            stat_ran.ventral.sim_ite=sim_ite;
    end






    %% test TN direction

    total_num=sum(N_exp);
    direction=[1:8];
    per_exp_real_TN=N_exp(1)/total_num;
    per_exp_sim_TN=[];
    for j=1:sim_ite
        [exp_sim_TN,idx] = datasample(direction,total_num,'Replace',true);
        N_exp_sim_TN=hist(exp_sim_TN,1:length(direction));
        per_exp_sim_TN(j)=N_exp_sim_TN(1)/sum(N_exp_sim_TN);

    end
    TN_pvalue=sum(per_exp_sim_TN>=per_exp_real_TN)/sim_ite;

    
    switch neurontype
        case 'all'
            stat_ran.all.TN_pvalue=TN_pvalue;
        case 'V1'
            %load([figure_path '\2p prefer direction distribution\' foldername '\stat_ran.mat']);
            stat_ran.V1.TN_pvalue=TN_pvalue;
        case 'ventral'
            %load([figure_path '\2p prefer direction distribution\' foldername '\stat_ran.mat']);
            stat_ran.ventral.TN_pvalue=TN_pvalue;
    end
    
    save([figure_path '\2p prefer direction distribution\' foldername  '\stat_ran.mat'],'stat_ran');
       
   
    clearvars -except figure_path folder_list runind neurontype
   

end























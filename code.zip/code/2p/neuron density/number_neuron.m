function number_neuron (brain_layer)
%% input
%%brain_layer
%   5: use allenmap_layer5 as the standard area map
%   1: use allenmap_layer5 as the standard area map
if nargin<1
    brain_layer=5;
end

%% set parameters
%%excel naming rule: brain slice following the only "-" in the name, and ends right before ".xlsx"

%%neuron_location_folders: the folder where the excel files are
neuron_location_folders={'C:\Users\he_yi\Downloads\male1\neurons location excel';...
                                            'C:\Users\he_yi\Downloads\male0\neurons location excel';...
                                            'C:\Users\he_yi\Downloads\female0\neurons location excel'};
savepath='C:\Users\he_yi\Downloads';

%%grid_size: the length side length of each square grid under standard allen_map
ML_step=50; 
AP_step=100; %the allenmap slices are 100um thick
%the AP value need to be fixed (100) for current area calculation
%need to be a multiple of 100 to do neuron cell count

%%cortex outline (left) image folder
if brain_layer==5
    outline_folder='F:\Lab\Baohua Liu Lab\code\mapping - for jiashu\allen map\layer5_coronal_outline';
end

%%folders and naming rules
%allenmap folder
allenmap_folder='F:\Lab\Baohua Liu Lab\code\mapping - for jiashu\allen map';
%load in boundary map
if brain_layer==5
    allenmap=load([allenmap_folder '\allenmap_layer5.mat']); %this should be the same unless you change the boudary image
else
    allenmap=load([allenmap_folder '\allenmap_layer1.mat']); 
end
%first collum: area name
%second collum: boundary coordinates

%area code
Areacode={'1', 'VISp';  '2', 'VISI';  '3', 'VISli'; '4', 'VISpor'; '5', 'VISpl'; '6', 'VISal'; '7', 'VISrl';...
            '8', 'VISa'; '9', 'VISam'; '10', 'VISpm'; '11', 'midline'; '12', 'inner_edge';'13', 'outer_edge'};
        
% parameters for smoothing
% x and y start value of the top view allen map
x_start=4500;
y_start=1000;
% x and y pixel length for the density plot
x_length=4000;
y_length=4000;

%bregma distance from the start of cortex
Bregma=3380;

%% grab neuron location excels
%concatenate excel results
%Excel columns: Type	Slice	X	Y	Value	C-pos	Z-pos	T-pos	X(inch)	Y(inch)	Z(inch)
%         Type: area code
%          X: the x coordinates ----- midline is parallel to y axis, so only x values are needed for distance calculations
%          other values are not used in this script

neuron_location=[];
%neuron_location matrix will have columns:
%       1. which brain slice (mouse atlas slice) a neuron is on
%       2. the area code of the neuron
%       3. the measured distance from midline

slice_para=[];
%slice_para matrix will have columns:
%       1. which brain slice (mouse atlas slice) a neuron is on
%       2. inner_edge distance from midline: area code 12
%       3. outer_edge distance from midline: area code 13

for m=1 : length(neuron_location_folders)
    single_folder=neuron_location_folders{m};
    cd(single_folder)
    %obtain neuron coordinates excels 
    excelfiles = dir('*.xlsx'); 
    excellist=string({excelfiles(~[excelfiles.isdir]).name})';%the names for all excel files

    for i = 1:length(excellist)
        excelname=excellist{i};
        start_ind = strfind(excelname,'-')+1; %slice number start after the only '-' in the name
        end_ind = strfind(excelname,'.xls')-1; %slice number end right before '.xls' or '.xlsx'
        slice_num=str2double(excelname(start_ind:end_ind));
        excel_temp = xlsread(excelname); 
        midline=excel_temp(excel_temp(:,1)==11,3); % area code for midline is 11
            %midline is to the right of neruons and the inner and outer edge of the
        %left hemisphere, so the x value for midline is always the largest
        neuron_dis=[excel_temp(excel_temp(:,1)<11,1), (midline-excel_temp(excel_temp(:,1)<11,3))]; %area code for VIS areas are 1-10
        neuron_dis= [(zeros(size(neuron_dis,1),1)+slice_num),neuron_dis];
        inner_edge_dis=midline-excel_temp(excel_temp(:,1)==12,3); % area code for inner edge is 12
        if inner_edge_dis <0 %sometimes the inned_edge is too close to midline and give some minor measuring fluctuations
            inner_edge_dis = 0; %for distance to 0 if this happens
        end
        outer_edge_dis=midline-excel_temp(excel_temp(:,1)==13,3); % area code for outer edge is 13
        slice_dis=[slice_num inner_edge_dis outer_edge_dis];
        neuron_location=[neuron_location; neuron_dis];
        slice_para=[slice_para; slice_dis];
    end
end

%% grab layer 5 outline image and excel
cd(outline_folder)
%obtain outline image matrix 
imgfiles = dir('*.jpg'); 
imglist=string({imgfiles(~[imgfiles.isdir]).name})';%the names for all jpg files

outline_struct=struct;
for i = 1:length(imglist)
    imgname=imglist{i};
    start_ind = strfind(imgname,'-')+1; %slice number start after the only '-' in the name
    end_ind = strfind(imgname,'.jpg')-1; %slice number end right before '.jpg'
    slice_temp=imgname(start_ind:end_ind);
    outline_struct.(['atlas' slice_temp])=imread(imglist{i});
end

midline_position=xlsread([outline_folder '\midline position.xlsx']);
%1st column: slice number
%2nd column: midline pixel
%3rd column: inner edge pixel (left)
%4th column: outer edge pixel (left)

%% calculate the standardized coordinates in micron
%%startard values - according to allenmap
%total 85 (slice 19-104)  intervals (100nm / slice) of brain slices with 50nm added before the first slice and after the last slice
standard_para=[allenmap.allenmap(1,:)', ((allenmap.allenmap(1,:)'-19)*100+50),allenmap.allenmap(4,:)',allenmap.allenmap(3,:)'];
%standard_para matrix will have columns:
%       1. slice number
%       2. anterior-posterior position each slice is on
%       3. inner_edge distance from midline: area code 12
%       4. outer_edge distance from midline: area code 13

 %%calculate the standardized top-down coordinates of neuron
 neurons=nan(size(neuron_location,1),4);
 % top-down coordinates of neurons
 %          1st column: slice number
 %          2nd column: area code
 %          3rd column: x coordinates - indicate anterior posterior position
 %          4th column: y coordinates - indicate lateral position
 
for n = 1:size(neuron_location,1)  
       %use the ratio (neuron-inner_edge)/(outer_edge-inner_edge) to
       %calculate the standardized neuron coordinates on standard allanmap
       neurons(n,1:2)=neuron_location(n,1:2);
       slice_num_temp=neuron_location(n,1);
       mouse_inner_edge=slice_para((slice_para(:,1)==slice_num_temp),2);
       if length(mouse_inner_edge)>1 %sometimes one brain slice have more than one excels 
           mouse_inner_edge=mean(mouse_inner_edge);
       end
       mouse_outer_edge=slice_para((slice_para(:,1)==slice_num_temp),3);
       if length(mouse_outer_edge)>1 %sometimes one brain slice have more than one excels 
           mouse_outer_edge=mean(mouse_outer_edge);
       end
       standard_inner_edge= standard_para((standard_para(:,1)==slice_num_temp),3);
       standard_outer_edge= standard_para((standard_para(:,1)==slice_num_temp),4);
       neurons(n,4)=(neuron_location(n,3)-mouse_inner_edge)/(mouse_outer_edge - mouse_inner_edge) * (standard_outer_edge - standard_inner_edge) +standard_inner_edge;
       neurons(n,3)=standard_para((standard_para(:,1)==slice_num_temp),2);
end

%% calculate neuron number and density in small grids (standard allen map, top-down view)
tot_n=zeros( size(allenmap.boundaries,1),1);
%neuron number, area list order the same as in actual_area in allenmap
for i = 1: size(allenmap.boundaries,1)
       boundary=allenmap.boundaries{i,2};
       boundary_AP=unique(boundary(1,:));
       slice_num=[];
       slice_AP=[];
       %obtian the slice number from boundary 
       %      ----- some points are added to make the topview look better
       %      ----- the slice outline is assumed to be in the middle of the 100um
       %      slice (thus end with 50), and the length of each visual area 
       %      on each slice is used to calculate the approximal topview surface
       %      of the 100um slice. 
       %      ----- thus the points added 0-50um before/ after the
       %      first/last slice to improve display should be removed when
       %      calculting the surface area
       for j=1: length(boundary_AP)
           slice_temp=num2str(boundary_AP(j));
           if endsWith(slice_temp,'50')
               slice_AP=[slice_AP boundary_AP(j)];
               slice_num=[slice_num ((boundary_AP(j)-50)/100+19)];
           end
       end
       %extract the tract length and calculate topview area on each slice 
       for j=1:length(slice_num)        
           %obtain slice image
            outline_img=outline_struct.(['atlas' num2str(slice_num(j))]);
            midline_pix=midline_position(midline_position(:,1)==slice_num(j),2);
            outline_img=outline_img(:,1:midline_pix);%get corresponding ouline the left hemisphere of the brain
            outline_img=flip(outline_img,2); %set midline to 0 pixel ----- midline is also 0 on the top-down view
            outline_ind=[];
            %first column is the outline row index, second column is the outline column index
            [outline_ind(:,1),outline_ind(:,2)]=find(outline_img==0); 
            
            %obtain ML medial-lateral start and end position
            boundary_ML=boundary(2,boundary(1,:)==slice_AP(j));
            ML_num=ceil((max(boundary_ML)-min(boundary_ML))/ML_step);%midline is set to 0
            
             %%when estimating legnth ---- linear regression (slope) & grid_size (cos) 
             for n = 1: ML_num
                 if n<ML_num
                    %%in coronal view, row is the depth and column is the medial-lateral position 
                    %the brain outline is continuous, however the mannual drawing may
                    %leave gaps between two pixel points on an outline
                    ML_medial=min(boundary_ML)+(n-1)*ML_step; 
                    ML_lateral=ML_medial+ML_step;
                 else
                    ML_medial=min(boundary_ML)+(n-1)*ML_step; 
                    ML_lateral=max(boundary_ML);
                 end
                neuron_num=sum(neurons(neurons(:,3)==slice_AP(j),4)>=ML_medial & neurons(neurons(:,3)==slice_AP(j),4)<=ML_lateral);
                tot_n(i)= tot_n(i)+neuron_num;
             end
       end
end
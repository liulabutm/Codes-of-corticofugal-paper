function neuron_distribution
%%excel naming rule: brain slice following the only "-" in the name, and ends right before ".xlsx"
global mapping_folder locate_neuron_folder allenmap_folder
globalpara;
%%brain_layer
brain_layer=5;
%   5: use allenmap_layer5 as the standard area map
%   1: use allenmap_layer5 as the standard area map


%%neuron_location_folders: the folder where the excel files are
neuron_location_folders={'E:\imaging facility\Jiashu\AX_m2\match\neuron_location_excel';...
                                            'E:\imaging facility\Jiashu\AX_m3\match\neuron_location_excel';...
                                            'E:\imaging facility\Jiashu\AY_m0\match\neuron_location_excel'};
savepath='E:\two-photon imaging\jiashu\data\retro_tracing';
%%folders and naming rules
%allenmap folder
%allenmap_folder='F:\Lab\Baohua Liu Lab\code\mapping - for jiashu\allen map';
%load in boundary map
if brain_layer==5
    allenmap=load([allenmap_folder '\allenmap_layer5.mat']); %this should be the same unless you change the boudary image
else
    allenmap=load([allenmap_folder '\allenmap_layer1.mat']); 
end
%first collum: area name
%second collum: boundary coordinates

%area code
Areacode={'1', 'VISp';  '2', 'VISI';  '3', 'VISli'; '4', 'VISpor'; '5', 'VISpl'; '6', 'VISal'; '7', 'VISrl';...
            '8', 'VISa'; '9', 'VISam'; '10', 'VISpm'; '11', 'midline'; '12', 'inner_edge';'13', 'outer_edge'};
        
%% grab neuron location excels
%concatenate excel results
%Excel columns: Type	Slice	X	Y	Value	C-pos	Z-pos	T-pos	X(inch)	Y(inch)	Z(inch)
%         Type: area code
%          X: the x coordinates ----- midline is parallel to y axis, so only x values are needed for distance calculations
%          other values are not used in this script

neuron_location=[];
%neuron_location matrix will have columns:
%       1. which brain slice (mouse atlas slice) a neuron is on
%       2. the area code of the neuron
%       3. the measured distance from midline

slice_para=[];
%slice_para matrix will have columns:
%       1. which brain slice (mouse atlas slice) a neuron is on
%       2. inner_edge distance from midline: area code 12
%       3. outer_edge distance from midline: area code 13

for m=1 : length(neuron_location_folders)
    single_folder=neuron_location_folders{m};
    cd(single_folder)
    %obtain neuron coordinates excels 
    %excelfiles = dir('*.xlsx'); 
    excelfiles = dir('*.csv'); 
    excellist=string({excelfiles(~[excelfiles.isdir]).name})';%the names for all excel files

    for i = 1:length(excellist)
        excelname=excellist{i};
        start_ind=strfind(excelname,'atlas')+6; %slice number start after the only '-' in the name
        end_ind = strfind(excelname,'.xls')-1; %slice number end right before '.xls' or '.xlsx'
        end_ind = strfind(excelname,'.csv')-1;
        slice_num=str2double(excelname(start_ind:end_ind));
        excel_temp = xlsread(excelname); 
        midline=excel_temp(excel_temp(:,1)==11,3); % area code for midline is 11
            %midline is to the right of neruons and the inner and outer edge of the
        %left hemisphere, so the x value for midline is always the largest
        neuron_dis=[excel_temp(excel_temp(:,1)<11,1), (midline-excel_temp(excel_temp(:,1)<11,3))]; %area code for VIS areas are 1-10
        neuron_dis= [(zeros(size(neuron_dis,1),1)+slice_num),neuron_dis];
        inner_edge_dis=midline-excel_temp(excel_temp(:,1)==12,3); % area code for inner edge is 12
        if inner_edge_dis <0 %sometimes the inned_edge is too close to midline and give some minor measuring fluctuations
            inner_edge_dis = 0; %for distance to 0 if this happens
        end
        outer_edge_dis=midline-excel_temp(excel_temp(:,1)==13,3); % area code for outer edge is 13
        slice_dis=[slice_num inner_edge_dis outer_edge_dis];
        neuron_location=[neuron_location; neuron_dis];
        slice_para=[slice_para; slice_dis];
    end
end

%% calculate the standardized coordinates in micron
%%startard values - according to allenmap
%total 85 (slice 19-104)  intervals (100nm / slice) of brain slices with 50nm added before the first slice and after the last slice
standard_para=[allenmap.allenmap(1,:)', ((allenmap.allenmap(1,:)'-19)*100+50),allenmap.allenmap(4,:)',allenmap.allenmap(3,:)'];
%standard_para matrix will have columns:
%       1. slice number
%       2. anterior-posterior position each slice is on
%       3. inner_edge distance from midline: area code 12
%       4. outer_edge distance from midline: area code 13

 %%calculate the standardized top-down coordinates of neuron
 neurons=nan(size(neuron_location,1),4);
 % top-down coordinates of neurons
 %          1st column: slice number
 %          2nd column: area code
 %          3rd column: x coordinates - indicate anterior posterior position
 %          4th column: y coordinates - indicate lateral position
 
for n = 1:size(neuron_location,1)  
       %use the ratio (neuron-inner_edge)/(outer_edge-inner_edge) to
       %calculate the standardized neuron coordinates on standard allanmap
       neurons(n,1:2)=neuron_location(n,1:2);
       slice_num_temp=neuron_location(n,1);
       mouse_inner_edge=slice_para((slice_para(:,1)==slice_num_temp),2);
       if length(mouse_inner_edge)>1 %sometimes one brain slice have more than one excels 
           mouse_inner_edge=mean(mouse_inner_edge);
       end
       mouse_outer_edge=slice_para((slice_para(:,1)==slice_num_temp),3);
       if length(mouse_outer_edge)>1 %sometimes one brain slice have more than one excels 
           mouse_outer_edge=mean(mouse_outer_edge);
       end
       standard_inner_edge= standard_para((standard_para(:,1)==slice_num_temp),3);
       standard_outer_edge= standard_para((standard_para(:,1)==slice_num_temp),4);
       neurons(n,4)=(neuron_location(n,3)-mouse_inner_edge)/(mouse_outer_edge - mouse_inner_edge) * (standard_outer_edge - standard_inner_edge) +standard_inner_edge;
       %add a random number between -50 to 50 around assigned slice
       %anterior-posterior coordinates for better display
       neurons(n,3)=standard_para((standard_para(:,1)==slice_num_temp),2)+50*(2*rand(1)-1);
       %rand(1) give uniformally distributed random numbers between 0~1 
end

%% plot neurons on brain top-down view
cd(savepath)
%neuron actual position for each area
for m=1:(size(Areacode,1)-3) %the last 3 areacodes are for midline and midial & lateral edges
      subplot(3,4,m) 
      hold on;
    for n = 1: size(allenmap.boundaries,1) 
        if ~isempty(allenmap.boundaries{n,2})
            shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
            pg=plot(shape{n});
            area_name=allenmap.boundaries{n,1};
            switch area_name
                case 'VISal'
                    pg.FaceColor='b';
                case 'VISrl'
                    pg.FaceColor='b';
                case 'VISpor'
                    pg.FaceColor='r';
                case 'VISpl'
                    pg.FaceColor='r';
                case 'VISli'
                    pg.FaceColor='r';
                case 'VISI'
                    pg.FaceColor='r';
                case 'VISp'
                    pg.FaceColor=[1,1,1];
                case 'VISa'
                    pg.FaceColor='b';
                case 'VISpm'
                    pg.FaceColor='b';
                case 'VISam'
                    pg.FaceColor='b';
            end
        end
    end
      for n = 1:size(neurons,1)
          if neurons(n,2)==str2num(Areacode{m,1})
                plot(neurons(n,3),neurons(n,4),'b.')
          end
      title(Areacode{m,2})
      end
      hold off
end

%neuron position for all areas
subplot(3,4,12)
title('ALL')
hold on;
for n = 1: size(allenmap.boundaries,1) 
    if ~isempty(allenmap.boundaries{n,2})
        shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
        plot(shape{n})
    end
end
for n = 1:size(neurons,1)
      plot(neurons(n,3),neurons(n,4),'k.')
end
hold off
 sgtitle('neuron distribution')
 
 saveas(gcf,'distribution.fig','fig')
 saveas(gcf,'distribution.tiff','tif')
 
 %% save above section area-wise for easy-viewing
 cd(savepath)
%neuron actual position for each area
for m=1:(size(Areacode,1)-3) %the last 3 areacodes are for midline and midial & lateral edges
figure
     hold on;
    for n = 1: size(allenmap.boundaries,1) 
        if ~isempty(allenmap.boundaries{n,2})
            shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
            pg=plot(shape{n});
            area_name=allenmap.boundaries{n,1};
            switch area_name
                case 'VISal'
                    pg.FaceColor='b';
                case 'VISrl'
                    pg.FaceColor='b';
                case 'VISpor'
                    pg.FaceColor='r';
                case 'VISpl'
                    pg.FaceColor='r';
                case 'VISli'
                    pg.FaceColor='r';
                case 'VISI'
                    pg.FaceColor='r';
                case 'VISp'
                    pg.FaceColor=[1,1,1];
                case 'VISa'
                    pg.FaceColor='b';
                case 'VISpm'
                    pg.FaceColor='b';
                case 'VISam'
                    pg.FaceColor='b';
            end
        end
    end
      for n = 1:size(neurons,1)
          if neurons(n,2)==str2num(Areacode{m,1})
                plot(neurons(n,3),neurons(n,4),'b.')
          end
      title(Areacode{m,2})
      end
      hold off
       saveas(gcf,[Areacode{m,2} '.fig'],'fig')
       saveas(gcf,[Areacode{m,2} '.tiff'],'tif')
end

%neuron position for all areas
figure
title('ALL')
hold on;
for n = 1: size(allenmap.boundaries,1) 
    if ~isempty(allenmap.boundaries{n,2})
        shape{n} = polyshape(allenmap.boundaries{n,2}(1,:)',allenmap.boundaries{n,2}(2,:)');%x,y
        pg=plot(shape{n});
        area_name=allenmap.boundaries{n,1};
        switch area_name
            case 'VISal'
                pg.FaceColor='b';
            case 'VISrl'
                pg.FaceColor='b';
            case 'VISpor'
                pg.FaceColor='r';
            case 'VISpl'
                pg.FaceColor='r';
            case 'VISli'
                pg.FaceColor='r';
            case 'VISI'
                pg.FaceColor='r';
            case 'VISp'
                pg.FaceColor=[1,1,1];
            case 'VISa'
                pg.FaceColor='b';
            case 'VISpm'
                pg.FaceColor='b';
            case 'VISam'
                pg.FaceColor='b';
        end
    end
end
for n = 1:size(neurons,1)
      plot(neurons(n,3),neurons(n,4),'k.')
end
hold off 
saveas(gcf,'ALL.fig','fig')
saveas(gcf,'ALL.tiff','tif')
 
end
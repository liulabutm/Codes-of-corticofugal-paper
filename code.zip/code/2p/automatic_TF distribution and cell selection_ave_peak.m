%%
% get the preferred TF (the peak value) and load the prefTF into
% prefTF_load.mat file and prefTF_loadseq.mat file
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath preferpath
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
%plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
outlier=1;
ignorecell=1;

VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq_final.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',3);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
      

for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\calFoutput.mat']);
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=size(sortdata.AVEpercFlu_amp,2);
    repnum=sortdata.repnum;

    if blankflag
        AVEperc=sortdata.AVE_peak_perc(:,:,2:end);  %TF response
        uniquestim=sortdata.uniquestim(2:end);
    else
        AVEperc=sortdata.AVE_peak_perc;
        uniquestim=sortdata.uniquestim;
    end

    for i=1:ROInum
        for j=1:recordnum
            [amp(i,j),prefTFind(i,j)]=max(AVEperc(i,j,:));
            prefTF_ave_peak(i,j)=uniquestim(prefTFind(i,j));
        end
    end
    sortdata.prefTF_ave_peak=prefTF_ave_peak;
    save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
    
    if f==1
        prefTF_load_ave_peak=[];
        prefTF_loadseq_ave_peak={sitename,1,ROInum,recordnum};
    else
    %load all the pref TF in an array
        load([preferpath 'TF\prefTF_load_ave_peak.mat']);
        load([preferpath 'TF\prefTF_loadseq_ave_peak.mat']);
        ROIstart=prefTF_loadseq_ave_peak{end,3}+1;
        ROIend=ROIstart+ROInum-1;
        prefTF_loadseq_ave_peak(end+1,:)={sitename,ROIstart,ROIend,recordnum};
    end
    
    if repflag
        prefTF_load_ave_peak(end+1:(size(prefTF_load_ave_peak,1)+ROInum),1:3)=prefTF_ave_peak;    
        
    else
        if VLflag
            endnum=size(prefTF_load_ave_peak,1);
            prefTF_load_ave_peak(endnum+1:(endnum+ROInum),1,:)=prefTF_ave_peak(:,1,:);
            prefTF_load_ave_peak(endnum+1:(endnum+ROInum),3,:)=prefTF_ave_peak(:,2,:);
        else
            endnum=size(prefTF_load_ave_peak,1);
            prefTF_load_ave_peak(endnum+1:(endnum+ROInum),1,:)=prefTF_ave_peak(:,1,:);
        end
    end
    
    
    save([preferpath 'TF\prefTF_load_ave_peak.mat'],'prefTF_load_ave_peak');
    save([preferpath 'TF\prefTF_loadseq_ave_peak.mat'],'prefTF_loadseq_ave_peak');
    
    clearvars -except ampMethod VirusExp baselinemethod calpath moviedataparentpath preferpath NPYdataparentpath RunFolderSeq RLBflag responsiveflag runind vsparaparentpath
    close all
    
end




%get responsive neuron and p value of one way anova after removing outlier,
%and load in the mat file
global NPYdataparentpath moviedataparentpath vsparaparentpath calpath preferpath
globalpara;
ampMethod='peak';
RLBcalflag=1; %if calculate reliability (formula) or not.  Calculation is need when there is any outlier
OWAcalflag=0; %if calculate one way anowa or not.
ttestcalflag=1; %if calculate t test or not.
responsivethre=0.06;
OWAthre=0.05;  %the threshold of judgement for one way anova
ttest_thre=0.05;   %the threshold of judgement for t test 
responsiveflag=1;  %if  use 'response>a value' as the criteria for selecting cells
RLBflag=0;   %if use reliability (formula) as the criteria for selecting cells
OWAflag=0;  %if  use one way anova as the criteria for selecting cells
ttestflag=1; %if  use t test as the criteria for selecting cells
saveflag=1;
%VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
% RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));
% 
% runind=strfind((cell2mat(RunFolderSeq(:,2)))',3);  %find which one is OS stim          
% removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
% runind(removeind)=[];  %remove the no-run one
% switch VirusExp
%     case 'all'
%         runind=runind';
%     case 'good'
%         removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
%         runind(removeind_1)=[];
%         removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
%         runind(removeind_2)=[];
%         runind=runind';
%     case 'bad'
%         removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
%         runind(removeind_1)=[];
%         removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
%         runind(removeind_2)=[]; 
%         runind=runind';
%     case 'control'
%         removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
%         runind(removeind_1)=[];
%         removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
%         runind(removeind_2)=[]; 
%         runind=runind';
% end
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\peak\sortdata.mat']);
    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=sortdata.recordnum;
    repnum=sortdata.repnum;
    %select good cell: responsive, reliable and has tuning
    %responsive calculate
    respROI_outlier=ones(ROInum,recordnum);
    for i=1:ROInum
        for j=1:recordnum        
            if max(sortdata.AVE_peak_perc(i,j,:))<responsivethre  %responsive
                respROI_outlier(i,j)=0;
            end
        end
    end
    %percRespROI=sum(respROI)/ROInum;
    sortdata.respROI_outlier=respROI_outlier;

    
    if RLBcalflag
        % reliability and one way anova
         %reliability  (with the formula)
        MAXpercFlu_amp=zeros(ROInum,recordnum);  %the max value in 8 orientations
        INDofpref=zeros(ROInum,recordnum);       %the index of the prefered (max response) orientation, 1:8=0,45,...,270,315
        MEANofpref=zeros(ROInum,recordnum);      %mean response of 15 repeat of the prefered orientation
        STDofpref=zeros(ROInum,recordnum);       %std of 15 repeat of the prefered orientation
        MEANofblank=zeros(ROInum,recordnum);     %mean response of the blank trial
        STDofblank=zeros(ROInum,recordnum);      %std of the blank trial
        outlierflag=~logical(sortdata.outlierflag);    
        ignorecellind=sortdata.ignoreflag;
        for i=1:ROInum
            for j=1:recordnum
                if ignorecellind(i,j)
                    outlierflag(i,:,j)=0;
                end
            end
        end

        if blankflag
            for i=1:ROInum
                for j=1:recordnum  
                    [MAXpercFlu_amp(i,j),INDofpref(i,j)]=max(sortdata.AVE_peak_perc(i,j,2:end),[],3);
                    temp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)+1),INDofpref(i,j)+1);
                    MEANofpref(i,j)=mean(temp);
                    STDofpref(i,j)=std(temp);
                    MEANofblank(i,j)=mean(sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1),1),2);
                    STDofblank(i,j)=std(sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1),1),0,2);
                end
            end
        else  
            pretrigframe=sortdata.pretrigframe;
            subrecrdtrialnum=sortdata.subrecrdtrialnum;
            baseline_med1=zeros(ROInum,1);
            baseline_med2=zeros(ROInum,1);
            BlankpercFlu=zeros(ROInum,pretrigframe,repnum,sortdata.uniquestimnum);
            if repflag==1
               baseline_med3=zeros(ROInum,1);
            end
            for i=1:ROInum
                baseframevalue1(:,:,:)=sortdata.F_Fneucorr3D((1:pretrigframe),1:repnum,i,:);
                temp=reshape(baseframevalue1,1,pretrigframe*repnum*sortdata.uniquestimnum);
                baseline_med1(i,1) = median(temp);
                BlankpercFlu(i,:,1:repnum,:)=(baseframevalue1-baseline_med1(i,1))/baseline_med1(i,1);
                if repflag==1
                    baseframevalue2(:,:,:)=sortdata.F_Fneucorr3D((1:pretrigframe),1+repnum:repnum*2,i,:);
                    temp=reshape(baseframevalue2,1,pretrigframe*repnum*sortdata.uniquestimnum);
                    baseline_med2(i,1) = median(temp);
                    BlankpercFlu(i,:,1+repnum:repnum*2,:)=(baseframevalue2-baseline_med2(i,1))/baseline_med2(i,1);
                    baseframevalue3(:,:,:)=sortdata.F_Fneucorr3D((1:pretrigframe),1+2*repnum:repnum*3,i,:);
                    temp=reshape(baseframevalue3,1,pretrigframe*repnum*sortdata.uniquestimnum);
                    baseline_med3(i,1) = median(temp);
                    BlankpercFlu(i,:,1+2*repnum:repnum*3,:)=(baseframevalue3-baseline_med3(i,1))/baseline_med2(i,1);
                else
                    if VLflag==1
                        baseframevalue2(:,:,:)=sortdata.F_Fneucorr3D((1:pretrigframe),1+repnum:repnum*2,i,:);
                        temp=reshape(baseframevalue2,1,pretrigframe*repnum*sortdata.uniquestimnum);
                        baseline_med2(i,1) = median(temp);
                        BlankpercFlu(i,:,1+repnum:repnum*2,:)=(baseframevalue2-baseline_med2(i,1))/baseline_med2(i,1);
                    end
                end               
            end
            BlankpercFlu_amp=squeeze(max(BlankpercFlu,[],2));
            BlankpercFlu_amp=squeeze(mean(BlankpercFlu_amp,3));
            
            for i=1:ROInum
                for j=1:recordnum
                    [MAXpercFlu_amp(i,j),INDofpref(i,j)]=max(sortdata.AVEperc(i,j,:),[],3);
                    temp1=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)),INDofpref(i,j));
                    MEANofpref(i,j)=mean(temp1);
                    STDofpref(i,j)=std(temp1);
                    MEANofblank(i,j)=mean(BlankpercFlu_amp(i,1+(j-1)*repnum:j*repnum),2);
                    STDofblank(i,j)=std(BlankpercFlu_amp(i,1+(j-1)*repnum:j*repnum),0,2);
                end
            end
        end
        RLB_outlier=(MEANofpref-MEANofblank)./(STDofpref+STDofblank);
        RLB_outlier=abs(RLB_outlier);
        sortdata.RLB_outlier=RLB_outlier;

        % %one way anova
        if OWAcalflag
            OWA_p_outlier=zeros(ROInum,recordnum);
            reliableROI_outlier=zeros(ROInum,recordnum);
            if blankflag
                for i=1:ROInum
                    for j=1:recordnum
                        percFlu_amp_blanktemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1),1); 
                        percFlu_amp_preftemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)+1),INDofpref(i,j)+1);
                        anovatemp(1:size(percFlu_amp_blanktemp,2))=percFlu_amp_blanktemp;
                        anovagroup(1:size(percFlu_amp_blanktemp,2))={'1'};
                        anovatemp(end+1:size(percFlu_amp_blanktemp,2)+size(percFlu_amp_preftemp,2))=percFlu_amp_preftemp;
                        anovagroup(end+1:size(percFlu_amp_blanktemp,2)+size(percFlu_amp_preftemp,2))={'2'};
                        OWA_p_outlier(i,j)=anova1(anovatemp,anovagroup,'off');
                        if OWA_p_outlier(i,j)<OWAthre
                           reliableROI_outlier(i,j)=1;
                        end
                        clearvars percFlu_amp_blanktemp percFlu_amp_preftemp anovatemp anovagroup
                    end
                end
            else
                for i=1:ROInum
                    for j=1:recordnum
                        percFlu_amp_blanktemp=BlankpercFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1));
                        percFlu_amp_preftemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)),INDofpref(i,j));
                        anovatemp(1:size(percFlu_amp_blanktemp,2))=percFlu_amp_blanktemp;
                        anovagroup(1:size(percFlu_amp_blanktemp,2))={'1'};
                        anovatemp(end+1:size(percFlu_amp_blanktemp,2)+size(percFlu_amp_preftemp,2))=percFlu_amp_preftemp;
                        anovagroup(end+1:size(percFlu_amp_blanktemp,2)+size(percFlu_amp_preftemp,2))={'2'};
                        OWA_p_outlier(i,j)=anova1(anovatemp,anovagroup,'off');
                        if OWA_p_outlier(i,j)<OWAthre
                           reliableROI_outlier(i,j)=1;
                        end
                        clearvars percFlu_amp_blanktemp percFlu_amp_preftemp anovatemp anovagroup
                    end
                end
            end
            sortdata.OWA_p_outlier=OWA_p_outlier;
            sortdata.reliableROI_outlier=reliableROI_outlier;
        end
        if ttestcalflag
            ttest_p_outlier=zeros(ROInum,recordnum);
            reliableROI_ttest_outlier=zeros(ROInum,recordnum);
            if blankflag
                for i=1:ROInum
                    for j=1:recordnum
                        percFlu_amp_blanktemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1),1); 
                        percFlu_amp_preftemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)+1),INDofpref(i,j)+1);
                        [ttest_h_outlier(i,j),ttest_p_outlier(i,j)]=ttest2(percFlu_amp_blanktemp,percFlu_amp_preftemp,'Tail','left'); %left means to test if the first vector is less than the second one                         
                        if ttest_p_outlier(i,j)<ttest_thre
                           reliableROI_ttest_outlier(i,j)=1;
                        end
                        clearvars percFlu_amp_blanktemp percFlu_amp_preftemp  
                    end
                end
            else
                for i=1:ROInum
                    for j=1:recordnum
                        percFlu_amp_blanktemp=BlankpercFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,1));
                        percFlu_amp_preftemp=sortdata.percFlu_amp(i,outlierflag(i,1+(j-1)*repnum:repnum*j,INDofpref(i,j)),INDofpref(i,j));
                        [ttest_h_outlier(i,j),ttest_p_outlier(i,j)]=ttest2(percFlu_amp_blanktemp,percFlu_amp_preftemp,'Tail','left'); %left means to test if the first vector is less than the second one                   
                        if ttest_p_outlier(i,j)<ttest_thre
                           reliableROI_ttest_outlier(i,j)=1;
                        end
                        clearvars percFlu_amp_blanktemp percFlu_amp_preftemp  
                    end
                end
            end
            sortdata.ttest_p_outlier=ttest_p_outlier;
            sortdata.reliableROI_ttest_outlier=reliableROI_ttest_outlier;
        end
    end
    
    
    %selectROI means which ROI is selected for plot the distribution or
    %calculate the amp change. choose which criterias (response, RLB or one way anova) to use at the beginning
    if responsiveflag
        seltemp(:,:,1)=respROI_outlier;
    else
        seltemp(:,:,1)=ones(ROInum,recordnum);
    end
    if RLBflag
        judgeRLB=zeros(ROInum,recordnum);
        for i=1:ROInum
            for j=1:recordnum
                if RLB_outlier(i,j)>=1
                    judgeRLB(i,j)=1;
                end
            end
        end
        seltemp(:,:,2)=judgeRLB;
    else
        seltemp(:,:,2)=ones(ROInum,recordnum);
    end
    if OWAflag
        seltemp(:,:,3)=reliableROI_outlier;
    else
        seltemp(:,:,3)=ones(ROInum,recordnum);
    end
    if ttestflag
        seltemp(:,:,4)=reliableROI_ttest_outlier;
    else
        seltemp(:,:,4)=ones(ROInum,recordnum);
    end
    selectROI_outlier=zeros(ROInum,recordnum);
    for i=1:ROInum
        for j=1:recordnum
            selectROI_outlier(i,j)=seltemp(i,j,1)&seltemp(i,j,2)&seltemp(i,j,3)&seltemp(i,j,4);
        end
    end
    sortdata.selectROI_outlier=selectROI_outlier;
    if saveflag
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
    end
    
    
    %load the selectROI in mat file
    if f==1
        ROIselect_load=selectROI_outlier;
        ROIselect_loadseq={sitename,1,ROInum,recordnum};
        save([preferpath '\TF\ROIselect_load.mat'],'ROIselect_load');
        save([preferpath '\TF\ROIselect_loadseq.mat'],'ROIselect_loadseq');
    else
        load([preferpath '\TF\ROIselect_load.mat']);
        load([preferpath '\TF\ROIselect_loadseq.mat']);
        if repflag
            ROIselect_load(end+1:(size(ROIselect_load,1)+ROInum),1:3)=selectROI_outlier; 
        else
            if VLflag
                endnum=size(ROIselect_load,1);
                ROIselect_load(endnum+1:(endnum+ROInum),1,:)=selectROI_outlier(:,1,:);
                ROIselect_load(endnum+1:(endnum+ROInum),3,:)=selectROI_outlier(:,2,:);
            else
                endnum=size(ROIselect_load,1);
                ROIselect_load(endnum+1:(endnum+ROInum),1,:)=selectROI_outlier(:,1,:);
            end
        end
        ROIstart=ROIselect_loadseq{end,3}+1;
        ROIend=ROIstart+ROInum-1;
        ROIselect_loadseq(end+1,:)={sitename,ROIstart,ROIend,recordnum};
        save([preferpath '\TF\ROIselect_load.mat'],'ROIselect_load');
        save([preferpath '\TF\ROIselect_loadseq.mat'],'ROIselect_loadseq');
    end
    clearvars -except   OWAthre ttest_thre ampMethod calpath preferpath moviedataparentpath NPYdataparentpath  OWAflag responsiveflag responsivethre RLBcalflag OWAcalflag ttestcalflag RLBflag ttestflag RunFolderSeq runind saveflag vsparaparentpath 
    close all
    
end


%%

load([preferpath 'TF\ROIselect_load.mat'])
load([preferpath 'TF\ROIselect_loadseq.mat'])
load([preferpath 'TF\prefTF_loadseq_ave_peak.mat'])
load([preferpath 'TF\prefTF_load_ave_peak.mat'])
%%
%plot the distribution of the pref. TF
selecellflag=1;  % 1=only distribute the cells that are responsive and reliable. 0 means show all the cells

ROInum=size(prefTF_load_ave_peak,1);
recordnum=size(prefTF_load_ave_peak,2);
if selecellflag
    for i=1:ROInum
        for j=1:recordnum
            if ROIselect_load(i,j)==0
                prefTF_load_ave_peak(i,j)=-100;  %take the unselective cells out of range of category
            end
        end
    end
end

binhistcata_TF=[1:7];



prefTF_loadseq_ave_peak(:,5)={1};
%plot distribution
%before VL with no selection
%which trials would be included (manually change the number of the 5th column, 1 means included, 0 means not included)
runind=strfind(cell2mat(prefTF_loadseq_ave_peak(:,5))',1);  %find which one need to run           
trialindbef=runind';
ROIindbef=cell2mat(prefTF_loadseq_ave_peak(trialindbef,2:3));
endnum=0;
for i=1:size(ROIindbef,1)
    ROIstart=ROIindbef(i,1);
    ROIend=ROIindbef(i,2);
    ROInum=ROIend-ROIstart+1;
    temp1(endnum+1:endnum+ROInum,:)=prefTF_load_ave_peak(ROIstart:ROIend,1);
    endnum=size(temp1,1);
end
temp1=temp1(temp1~=-100);
a=real(1+log2(temp1/0.25));
figure;
histogram(a,binhistcata_TF,'Normalization','probability');
ytix = get(gca, 'YTick'); % setting y in %
set(gca, 'YTick',ytix, 'YTickLabel',ytix*100);% setting y in %
xticks([1.5 2.5 3.5 4.5 5.5 6.5])
xticklabels({'0.25','0.5','1','2','4','8'})
%title('before VL; p < 0.2; response > 6%;  n = 5');
%title('before VL; p < 0.05; n = 5');

%%
clear temp1

%repeat with no selection
tempind=strfind(cell2mat(prefTF_loadseq_ave_peak(:,4))',3);
runind=strfind(cell2mat(prefTF_loadseq_ave_peak(:,5))',1);  %find which ones need to run within OS stim
trialindrep=intersect(tempind,runind);

ROIindrep=cell2mat(prefTF_loadseq_ave_peak(trialindrep,2:3));
endnum=0;
for i=1:size(ROIindrep,1)
    ROIstart=ROIindrep(i,1);
    ROIend=ROIindrep(i,2);
    ROInum=ROIend-ROIstart+1;
    temp2(endnum+1:endnum+ROInum,:)=prefTF_load_ave_peak(ROIstart:ROIend,2);
    endnum=size(temp2,1);
end
figure;
histogram(temp2,binhistcata_dir);
title('repeat  reliable cells');



%after VL with no selection
tempind2=strfind(cell2mat(prefTF_loadseq_ave_peak(:,4))',2);
tempind3=strfind(cell2mat(prefTF_loadseq_ave_peak(:,4))',3);
tempind=unique([tempind2 tempind3]);
runind=strfind(cell2mat(prefTF_loadseq_ave_peak(:,5))',1);  %find which ones need to run within OS stim
trialindaft=intersect(tempind,runind);
ROIindaft=cell2mat(prefTF_loadseq_ave_peak(trialindaft,2:3));
endnum=0;
for i=1:size(ROIindaft,1)
    ROIstart=ROIindaft(i,1);
    ROIend=ROIindaft(i,2);
    ROInum=ROIend-ROIstart+1;
    temp3(endnum+1:endnum+ROInum,:)=prefTF_load_ave_peak(ROIstart:ROIend,3);
    endnum=size(temp3,1);
end
figure;
histogram(temp3,binhistcata_dir);
title('after VL  reliable cells');


%% cumulative distribution plot


%load projecting and control TF
for i=1:size(prefTF_load_ave_peak,1)
       if ROIselect_load(i,1)==0
            prefTF_load_ave_peak(i,1)=-100;  %take the unselective cells out of range of category
       end   
end


prefTF_projecting=prefTF_load_ave_peak;
prefTF_projecting(prefTF_load_ave_peak==-100)=[];

prefTF_control=prefTF_load_ave_peak;
prefTF_control(prefTF_load_ave_peak==-100)=[];



%linear SF into [1, 2, 3, 4,...]
linear_prefTF_projecting=real(1+log2(prefTF_projecting/0.25));
linear_prefTF_control=real(1+log2(prefTF_control/0.25));
% get the cumulative distribution function
[f1,x1] = ecdf(linear_prefTF_projecting);
[f2,x2] = ecdf(linear_prefTF_control);
%plot
figure;hold on;
cdfplot(linear_prefTF_projecting);
cdfplot(linear_prefTF_control);
legend('NOT-DTN projecting','Control','Location','best')
xticks([1 2 3 4 5 6])
xticklabels({'0.25','0.5','1','2','4','8'})
yticks([0 0.2 0.4 0.6 0.8 1])
yticklabels({'0','20','40','60','80','100'})
%ttest
[h,p] = ttest(f1,f2,'Tail','right');
[hks,pks] = kstest2(linear_prefTF_projecting,linear_prefTF_control);
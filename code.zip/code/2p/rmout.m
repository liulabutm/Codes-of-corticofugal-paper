global sortdata
responseviewer;

%% plot tuning for each ROI with prefer ori/dir calculated with vector sum
clear all

global calpath prefervectorpath preferpath
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
baselinemethod='pretrig';
saveflag=1;

checktype='direction';   %'orientation' or 'direction'  or 'dir_mix'
selectmode='any';    %'all' or 'any'   %'all' means all recordings are selected; 'any' means as long as one of the recording is selected, it will be ploted
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials
    load([calpath sitename '\calFoutput.mat']);
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
%     sortdata.prefdir_mix=sortdata.prefdir_vec_formula_degree_basedori_new;

    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=size(sortdata.AVEpercFlu_amp,2);
    repnum=sortdata.repnum;
    if f==1
        response_load=[];
        switch checktype
            case 'orientation'
                prefori_vec_selecell=[];
                gOSI=[];
            case 'direction'
                prefdir_basedori_selecell=[];
                prefdir_vec_selecell=[];
                DSI=[];
                prefori_vec_selecell=[];
                gOSI=[];
            case 'dir_mix'
                prefori_vec_selecell=[];
                prefdir_vec_selecell=[];
                prefdir_basedori_selecell=[];
                prefdir_mix_selecell=[];
                DSI=[];
                gOSI=[];
                DSI_new=[];
        end
        cellname={};
        
    else
    %load all the pref directions in an array
        load([prefervectorpath 'tuning\response_load.mat']);        
        load([prefervectorpath 'tuning\cellname.mat']);
        
        switch checktype
            case 'orientation'
                load([prefervectorpath 'tuning\prefori_vec_selecell.mat']);
                load([prefervectorpath 'tuning\gOSI.mat']);
            case 'direction'
                load([prefervectorpath 'tuning\prefdir_basedori_selecell.mat']);
                load([prefervectorpath 'tuning\prefdir_vec_selecell.mat']);
                load([prefervectorpath 'tuning\DSI.mat']);
                load([prefervectorpath 'tuning\prefori_vec_selecell.mat']);
                load([prefervectorpath 'tuning\gOSI.mat']);
            case 'dir_mix'
                load([prefervectorpath 'tuning\prefdir_basedori_selecell.mat']);
                load([prefervectorpath 'tuning\prefori_vec_selecell.mat']);
                load([prefervectorpath 'tuning\prefdir_vec_selecell.mat']);
                load([prefervectorpath 'tuning\DSI.mat']);
                load([prefervectorpath 'tuning\DSI_new.mat']);
                load([prefervectorpath 'tuning\gOSI.mat']);
                load([prefervectorpath 'tuning\prefdir_mix_selecell.mat']);
        end
    end
    if blankflag
        response=zeros(1,3,sortdata.uniquestimnum-1);
    else
        response=zeros(1,3,sortdata.uniquestimnum);
    end
    for i=1:ROInum
        switch selectmode
            case'all'
                if all(sortdata.selectROI_outlier(i,:))
                    selectROI=1;
                else
                    selectROI=0;
                end
            case 'any'
                if any(sortdata.selectROI_outlier(i,:))
                    selectROI=1;
                else
                    selectROI=0;
                end
                
        end
        if selectROI  %only selected neurons
            
            if blankflag
                
                if repflag
                    response=sortdata.AVE_peak_perc(i,:,2:end);
                else
                    if VLflag
                        response(1,1,:)=sortdata.AVE_peak_perc(i,1,2:end);
                        response(1,3,:)=sortdata.AVE_peak_perc(i,2,2:end);
                    else
                        response(1,1,:)=sortdata.AVE_peak_perc(i,1,2:end);
                    end
                end
            else
                
                if repflag
                    response=sortdata.AVE_peak_perc(i,:,:);
                else
                    if VLflag
                        response(1,1,:)=sortdata.AVE_peak_perc(i,1,:);
                        response(1,3,:)=sortdata.AVE_peak_perc(i,2,:);
                    else
                        response(1,1,1)=sortdata.AVE_peak_perc(i,1,:);
                    end
                end
                
            end
            endnum=size(response_load,1);
            response_load(endnum+1,:,:)=response(1,:,:);
            cellname{endnum+1,1}=[sitename ' ROI ' num2str(i)];
            switch checktype
                case 'orientation'
                   
                    if repflag
                        prefori_vec_selecell(endnum+1,1:3)=sortdata.perfori_vec_formula_degree(i,:);
                        gOSI(endnum+1,1:3)=sortdata.globalOSI(i,:);
                    else
                        if VLflag
                            prefori_vec_selecell(endnum+1,1)=sortdata.perfori_vec_formula_degree(i,1);
                            gOSI(endnum+1,1)=sortdata.globalOSI(i,1);
                            prefori_vec_selecell(endnum+1,2)=0;
                            gOSI(endnum+1,2)=0;
                            prefori_vec_selecell(endnum+1,3)=sortdata.perfori_vec_formula_degree(i,2);
                            gOSI(endnum+1,3)=sortdata.globalOSI(i,2);
                           
                        else
                            prefori_vec_selecell(endnum+1,1)=sortdata.perfori_vec_formula_degree(i,:);
                            gOSI(endnum+1,1)=sortdata.globalOSI(i,:);
                        end
                    end                    
                   
                case 'direction'
                    
                    if repflag
                        prefdir_basedori_selecell(endnum+1,1:3)=sortdata.prefdir_vec_formula_degree_basedori_new(i,:);
                        prefori_vec_selecell(endnum+1,1:3)=sortdata.perfori_vec_formula_degree(i,:);
                        gOSI(endnum+1,1:3)=sortdata.globalOSI(i,:);
                        prefdir_vec_selecell(endnum+1,1:3)=sortdata.perfdir_vec_formula_degree(i,:);
                        DSI(endnum+1,1:3)=sortdata.DSI(i,:);
                    else
                        if VLflag
                            prefdir_basedori_selecell(endnum+1,1)=sortdata.prefdir_vec_formula_degree_basedori_new(i,1);
                            prefori_vec_selecell(endnum+1,1)=sortdata.perfori_vec_formula_degree(i,1);
                            gOSI(endnum+1,1)=sortdata.globalOSI(i,1);
                            prefori_vec_selecell(endnum+1,2)=0;
                            gOSI(endnum+1,2)=0;
                            prefori_vec_selecell(endnum+1,3)=sortdata.perfori_vec_formula_degree(i,2);
                            gOSI(endnum+1,3)=sortdata.globalOSI(i,2);                           
                            prefdir_vec_selecell(endnum+1,1)=sortdata.perfdir_vec_formula_degree(i,1);
                            DSI(endnum+1,1)=sortdata.DSI(i,1);
                            prefdir_basedori_selecell(endnum+1,2)=0;
                            prefdir_vec_selecell(endnum+1,2)=0;
                            DSI(endnum+1,2)=0;
                            prefdir_basedori_selecell(endnum+1,3)=sortdata.prefdir_vec_formula_degree_basedori_new(i,2);
                            prefdir_vec_selecell(endnum+1,3)=sortdata.perfdir_vec_formula_degree(i,2);
                            DSI(endnum+1,3)=sortdata.DSI(i,2);
                        else
                            prefdir_basedori_selecell(endnum+1,1)=sortdata.prefdir_vec_formula_degree_basedori_new(i,:);
                            prefori_vec_selecell(endnum+1,1)=sortdata.perfori_vec_formula_degree(i,:);
                            gOSI(endnum+1,1)=sortdata.globalOSI(i,:);
                            prefdir_vec_selecell(endnum+1,1)=sortdata.perfdir_vec_formula_degree(i,:);
                            DSI(endnum+1,1)=sortdata.DSI(i,:);
                        end
                    end    
                    
                case 'dir_mix'
                    
                    if repflag
                        prefori_vec_selecell(endnum+1,1:3)=sortdata.perfori_vec_formula_degree(i,:);
                        gOSI(endnum+1,1:3)=sortdata.globalOSI(i,:);
                        prefdir_vec_selecell(endnum+1,1:3)=sortdata.perfdir_vec_formula_degree(i,:);
                        DSI(endnum+1,1:3)=sortdata.DSI(i,:);
                        prefdir_basedori_selecell(endnum+1,1:3)=sortdata.prefdir_vec_formula_degree_basedori_new(i,:);
                        prefdir_mix_selecell(endnum+1,1:3)=sortdata.prefdir_mix(i,:);
                        DSI_new(endnum+1,1:3)=sortdata.DSI_new(i,:);
                    else
                        if VLflag
                            prefori_vec_selecell(endnum+1,1)=sortdata.perfori_vec_formula_degree(i,1);
                            gOSI(endnum+1,1)=sortdata.globalOSI(i,1);
                            prefori_vec_selecell(endnum+1,2)=0;
                            gOSI(endnum+1,2)=0;
                            prefori_vec_selecell(endnum+1,3)=sortdata.perfori_vec_formula_degree(i,2);
                            gOSI(endnum+1,3)=sortdata.globalOSI(i,2);                           
                            prefdir_vec_selecell(endnum+1,1)=sortdata.perfdir_vec_formula_degree(i,1);
                            DSI(endnum+1,1)=sortdata.DSI(i,1);
                            prefdir_vec_selecell(endnum+1,2)=0;
                            DSI(endnum+1,2)=0;
                            prefdir_vec_selecell(endnum+1,3)=sortdata.perfdir_vec_formula_degree(i,2);
                            DSI(endnum+1,3)=sortdata.DSI(i,2);
                            prefdir_basedori_selecell(endnum+1,1)=sortdata.prefdir_vec_formula_degree_basedori_new(i,1);
                            prefdir_mix_selecell(endnum+1,1)=sortdata.prefdir_mix(i,1);
                            DSI_new(endnum+1,1)=sortdata.DSI_new(i,1);
                            prefdir_basedori_selecell(endnum+1,2)=0;
                            prefdir_mix_selecell(endnum+1,2)=0;
                            DSI_new(endnum+1,2)=0;
                            prefdir_basedori_selecell(endnum+1,3)=sortdata.prefdir_vec_formula_degree_basedori_new(i,2);
                            prefdir_mix_selecell(endnum+1,3)=sortdata.prefdir_mix(i,2);
                            DSI_new(endnum+1,3)=sortdata.DSI_new(i,2);
                        else
                            prefori_vec_selecell(endnum+1,1)=sortdata.perfori_vec_formula_degree(i,:);
                            gOSI(endnum+1,1)=sortdata.globalOSI(i,:);
                            prefdir_vec_selecell(endnum+1,1)=sortdata.perfdir_vec_formula_degree(i,:);
                            DSI(endnum+1,1)=sortdata.DSI(i,:);
                            prefdir_basedori_selecell(endnum+1,1)=sortdata.prefdir_vec_formula_degree_basedori_new(i,:);
                            prefdir_mix_selecell(endnum+1,1)=sortdata.prefdir_mix(i,:);
                            DSI_new(endnum+1,1)=sortdata.DSI_new(i,:);
                        end
                    end                       
            end
        end
    end
    
    save([prefervectorpath 'tuning\response_load.mat'],'response_load');
    save([prefervectorpath 'tuning\cellname.mat'],'cellname'); 
    switch checktype
        case 'orientation'
            save([prefervectorpath 'tuning\prefori_vec_selecell.mat'],'prefori_vec_selecell');  
            save([prefervectorpath 'tuning\gOSI.mat'],'gOSI');
        case 'direction'
            save([prefervectorpath 'tuning\prefdir_basedori_selecell.mat'],'prefdir_basedori_selecell');  
            save([prefervectorpath 'tuning\prefdir_vec_selecell.mat'],'prefdir_vec_selecell');  
            save([prefervectorpath 'tuning\DSI.mat'],'DSI');
            save([prefervectorpath 'tuning\prefori_vec_selecell.mat'],'prefori_vec_selecell');  
            save([prefervectorpath 'tuning\gOSI.mat'],'gOSI');
        case 'dir_mix'
            save([prefervectorpath 'tuning\prefdir_basedori_selecell.mat'],'prefdir_basedori_selecell');  
            save([prefervectorpath 'tuning\prefori_vec_selecell.mat'],'prefori_vec_selecell');
            save([prefervectorpath 'tuning\prefdir_vec_selecell.mat'],'prefdir_vec_selecell'); 
            save([prefervectorpath 'tuning\DSI.mat'],'DSI');
            save([prefervectorpath 'tuning\DSI_new.mat'],'DSI_new');
            save([prefervectorpath 'tuning\gOSI.mat'],'gOSI');
            save([prefervectorpath 'tuning\prefdir_mix_selecell.mat'],'prefdir_mix_selecell');
    end
    clearvars -except selectmode ampMethod baselinemethod checktype saveflag calpath prefervectorpath preferpath RunFolderSeq RLBflag responsiveflag runind ;
    close all
end


%% subplot tunings

global calpath prefervectorpath preferpath
globalpara;

%subplot tunings
load([prefervectorpath 'tuning\response_load.mat']);
load([prefervectorpath 'tuning\cellname.mat']);
switch checktype
    case 'orientation'
        load([prefervectorpath 'tuning\prefori_vec_selecell.mat']);
        load([prefervectorpath 'tuning\gOSI.mat']);
    case 'direction'
        load([prefervectorpath 'tuning\prefdir_basedori_selecell.mat']);
        load([prefervectorpath 'tuning\prefdir_vec_selecell.mat']);
        load([prefervectorpath 'tuning\DSI.mat']);
        load([prefervectorpath 'tuning\prefori_vec_selecell.mat']);
        load([prefervectorpath 'tuning\gOSI.mat']);
    case 'dir_mix'
        load([prefervectorpath 'tuning\prefdir_basedori_selecell.mat']);
        load([prefervectorpath 'tuning\prefori_vec_selecell.mat']);
        load([prefervectorpath 'tuning\prefdir_vec_selecell.mat']);
        load([prefervectorpath 'tuning\DSI.mat']);
        load([prefervectorpath 'tuning\DSI_new.mat']);
        load([prefervectorpath 'tuning\gOSI.mat']);
        load([prefervectorpath 'tuning\prefdir_mix_selecell.mat']);
end
radius=[0,45,90,135,180,225,270,315,360];

for i=1:size(response_load,1)
    for j=1:size(response_load,2)
        minresp=min(response_load(i,j,:));
        if  minresp<0
            response_load(i,j,:)=response_load(i,j,:)-minresp;
        end                
        response_load(i,j,size(radius,2))=response_load(i,j,1);
    end
        
end
figurenum=fix(size(response_load,1)/36);
if figurenum==0
    
    for r=1:size(response_load,2)  %recordnum
        figure;hold on;
        for k=1:rem(size(response_load,1),36)

            subplot(6,6,k);
            polarplot(0:pi/4:2*pi, squeeze(response_load(k,r,:))); 
            if r==1
                recordname='bef';
            elseif r==2
                recordname='rep';
            elseif r==3
                recordname='aft';
            end
            
            switch checktype
                case 'orientation'
                    title(['prefori ' num2str(prefori_vec_selecell(k,r),'%.1f') ' / gOSI ' num2str(gOSI(k,r),'%.2f') ' / rec ' recordname]);
                case 'direction'
%                     title({['prefdir ' num2str(prefdir_vec_selecell(k,r),'%.1f') ' / DSI ' num2str(DSI(k,r),'%.2f')];['prefori ' num2str(prefori_vec_selecell(k,r),'%.1f') ' / gOSI ' num2str(gOSI(k,r),'%.2f') ' / rec ' recordname]});
                    title({['dirbsori ' num2str(prefdir_basedori_selecell(k,r),'%.1f') ' / ori ' num2str(prefori_vec_selecell(k,r),'%.1f') ' / gOSI ' num2str(gOSI(k,r),'%.2f')];['prefdir ' num2str(prefdir_vec_selecell(k,r),'%.1f') ' / DSI ' num2str(DSI(k,r),'%.2f') ' / rec ' recordname]});

                case 'dir_mix'
                    %title(['dir ' num2str(prefdir_vec_selecell(i*j+k),'%.1f') '/ ori ' num2str(prefori_vec_selecell(i*j+k),'%.1f') '/ dir_basedori ' num2str(prefdir_basedori_selecell(i*j+k),'%.1f') ' / DSI ' num2str(DSI(i*j+k),'%.2f')]);
                    %title({['dir ' num2str(prefdir_vec_selecell(i*j+k),'%.1f') '/ ori ' num2str(prefori_vec_selecell(i*j+k),'%.1f')];['dir basedori ' num2str(prefdir_basedori_selecell(i*j+k),'%.1f') ' / DSI ' num2str(DSI(i*j+k),'%.2f')]});
                    title({['dir ' num2str(prefdir_vec_selecell(k,r),'%.1f') '/ ori ' num2str(prefori_vec_selecell(k,r),'%.1f') '/ gOSI ' num2str(gOSI(k,r),'%.2f')];['dir basedori ' num2str(prefdir_basedori_selecell(k,r),'%.1f') ' / DSI ' num2str(DSI(k,r),'%.2f')];['dir mix ' num2str(prefdir_mix_selecell(k,r),'%.1f') ' / DSI new ' num2str(DSI_new(k,r),'%.2f') ' / rec ' recordname]});
            end

            legend(cellname{k});
            legend('off');
            rticklabels({});
            thetaticks([0 45 90 135 180 225 270 315])
            thetaticklabels({'0','45','90','135','180','225','270','315'})

        end
    end 
    
    
    
else 
    for r=1:size(prefdir_vec_selecell,2)  %recordnum
        if r==1
            recordname='bef';
        elseif r==2
            recordname='rep';
        elseif r==3
            recordname='aft';
        end
        for i=1:fix(size(response_load,1)/36)
            figure;hold on;
            
                for j=1:36

                    subplot(6,6,j);
                    polarplot(0:pi/4:2*pi, squeeze(response_load(((i-1)*36+j),r,:))); 
                    hold on;
                    polarplot([0 prefdir_basedori_selecell((i-1)*36+j,r)*pi/180],[0 max(response_load(((i-1)*36+j),r,:))]);
                    switch checktype
                        case 'orientation'
                            title(['prefori ' num2str(prefori_vec_selecell((i-1)*36+j,r),'%.1f') ' / gOSI ' num2str(gOSI((i-1)*36+j,r),'%.2f') ' / rec ' recordname]);
                        case 'direction'
                            title({['dirbsori ' num2str(prefdir_basedori_selecell((i-1)*36+j,r),'%.1f') ' / ori ' num2str(prefori_vec_selecell((i-1)*36+j,r),'%.1f') ' / gOSI ' num2str(gOSI((i-1)*36+j,r),'%.2f')];['prefdir ' num2str(prefdir_vec_selecell((i-1)*36+j,r),'%.1f') ' / DSI ' num2str(DSI((i-1)*36+j,r),'%.2f') ' / rec ' recordname]});
                        case 'dir_mix'
                            title({['dir ' num2str(prefdir_vec_selecell((i-1)*36+j,r),'%.1f') '/ ori ' num2str(prefori_vec_selecell((i-1)*36+j,r),'%.1f') '/ gOSI ' num2str(gOSI((i-1)*36+j,r),'%.2f')];['dir basedori ' num2str(prefdir_basedori_selecell((i-1)*36+j,r),'%.1f') ' / DSI ' num2str(DSI((i-1)*36+j,r),'%.2f')];['dir mix ' num2str(prefdir_mix_selecell((i-1)*36+j,r),'%.1f') ' / DSI new ' num2str(DSI_new((i-1)*36+j,r),'%.2f') ' / rec ' recordname]});
                            %title(['dir ' num2str(prefdir_vec_selecell((i-1)*36+j),'%.1f') '/ ori ' num2str(prefori_vec_selecell((i-1)*36+j),'%.1f') '/ dir_basedori ' num2str(prefdir_basedori_selecell((i-1)*36+j),'%.1f') ' / DSI ' num2str(DSI((i-1)*36+j),'%.2f')]);
                    end
                    legend(cellname{(i-1)*36+j});
                    legend('off');
                    rticklabels({});
                    thetaticks([0 45 90 135 180 225 270 315])
                    thetaticklabels({'0','45','90','135','180','225','270','315'})
                    hold off;
                end
            
            saveas(gcf,[prefervectorpath 'tuning\check\check' num2str(i) '.fig'],'fig')
            %close all
        end
    end
    
    for r=1:size(prefdir_vec_selecell,2)  %recordnum
        if r==1
            recordname='bef';
        elseif r==2
            recordname='rep';
        elseif r==3
            recordname='aft';
        end
        i=fix(size(response_load,1)/36);
        j=36;
        figure;hold on;
        for k=1:rem(size(response_load,1),36)

            subplot(6,6,k);
            polarplot(0:pi/4:2*pi, squeeze(response_load(i*j+k,r,:))); 
            hold on;
            polarplot([0 prefdir_basedori_selecell(i*j+k,r)*pi/180],[0 max(response_load(i*j+k,r,:))])
            switch checktype
                case 'orientation'
                    title(['prefori ' num2str(prefori_vec_selecell(i*j+k,r),'%.1f') ' / gOSI ' num2str(gOSI(i*j+k,r),'%.2f') ' / rec ' recordname]);
                case 'direction'
                    title({['dirbsori ' num2str(prefdir_basedori_selecell(i*j+k,r),'%.1f') '/ ori '  num2str(prefori_vec_selecell(i*j+k,r),'%.1f') ' / gOSI ' num2str(gOSI(i*j+k,r),'%.2f') ];['prefdir ' num2str(prefdir_vec_selecell(i*j+k,r),'%.1f') ' / DSI ' num2str(DSI(i*j+k,r),'%.2f') ' / rec ' recordname]});
                case 'dir_mix'
                    %title(['dir ' num2str(prefdir_vec_selecell(i*j+k),'%.1f') '/ ori ' num2str(prefori_vec_selecell(i*j+k),'%.1f') '/ dir_basedori ' num2str(prefdir_basedori_selecell(i*j+k),'%.1f') ' / DSI ' num2str(DSI(i*j+k),'%.2f')]);
                    %title({['dir ' num2str(prefdir_vec_selecell(i*j+k),'%.1f') '/ ori ' num2str(prefori_vec_selecell(i*j+k),'%.1f')];['dir basedori ' num2str(prefdir_basedori_selecell(i*j+k),'%.1f') ' / DSI ' num2str(DSI(i*j+k),'%.2f')]});
                    title({['dir ' num2str(prefdir_vec_selecell(i*j+k,r),'%.1f') '/ ori ' num2str(prefori_vec_selecell(i*j+k,r),'%.1f') '/ gOSI ' num2str(gOSI(i*j+k,r),'%.2f')];['dir basedori ' num2str(prefdir_basedori_selecell(i*j+k,r),'%.1f') ' / DSI ' num2str(DSI(i*j+k,r),'%.2f')];['dir mix ' num2str(prefdir_mix_selecell(i*j+k,r),'%.1f') ' / DSI new ' num2str(DSI_new(i*j+k,r),'%.2f') ' / rec ' recordname]});
            end

            legend(cellname{i*j+k});
            legend('off');
            rticklabels({});
            thetaticks([0 45 90 135 180 225 270 315])
            thetaticklabels({'0','45','90','135','180','225','270','315'})
        hold off;
        end
        saveas(gcf,[prefervectorpath 'tuning\check\check' num2str(i+1) '.fig'],'fig')
    end
    
end

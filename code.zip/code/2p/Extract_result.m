%% Extract prefdir_mix and DSI, gDSI, OSI, gOSI

global calpath prefervectorpath preferpath
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
baselinemethod='pretrig';
saveflag=1;

checktype='direction';   %'orientation' or 'direction'  or 'dir_mix'
selectmode='any';    %'all' or 'any'   %'all' means all recordings are selected; 'any' means as long as one of the recording is selected, it will be ploted
VirusExp= 'good';   %'good'  or  'bad'   or  'control' or 'all'
         
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));

runind=strfind((cell2mat(RunFolderSeq(:,2)))',1);  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    VLflag=RunFolderSeq{runind(f),3};   %1=this ROI has recording after VL
    repflag=RunFolderSeq{runind(f),4};  %1=this ROI has repeated recording before VL 
    blankflag=RunFolderSeq{runind(f),5};  %1=this ROI has the blank trials

    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
%     sortdata.prefdir_mix=sortdata.prefdir_vec_formula_degree_basedori_new;

    ROInum=size(sortdata.AVEpercFlu_amp,1);
    recordnum=size(sortdata.AVEpercFlu_amp,2);
    repnum=sortdata.repnum;        
    select_ROI=sortdata.selectROI_outlier & ~sortdata.removeflag_prefdir;

    if f==1       
        prefdir_vec_selecell=[];
        prefdir_basedori_selecell=[];
        prefdir_mix_selecell=[];
        DSI=[];
        gOSI=[];
        gDSI=[];
        OSI=[];
        
        
        prefdir_loadseq={sitename,1,sum(select_ROI),recordnum};
        prefdir_vec_selecell=sortdata.perfdir_vec_formula_degree(select_ROI);
        prefdir_basedori_selecell=sortdata.prefdir_vec_formula_degree_basedori_new(select_ROI);
        prefdir_mix_selecell=sortdata.prefdir_mix(select_ROI);
        DSI=sortdata.DSI_new_abs(select_ROI);
        gOSI=sortdata.globalOSI(select_ROI);
        gDSI=sortdata.globalDSI(select_ROI);
        OSI=sortdata.OSI(select_ROI);
        
        save([prefervectorpath 'tuning\prefdir_vec_selecell.mat'],'prefdir_vec_selecell');  
        save([prefervectorpath 'tuning\prefdir_basedori_selecell.mat'],'prefdir_basedori_selecell');
        save([prefervectorpath 'tuning\prefdir_mix_selecell.mat'],'prefdir_mix_selecell'); 
        save([prefervectorpath 'tuning\DSI.mat'],'DSI');
        save([prefervectorpath 'tuning\OSI.mat'],'OSI');
        save([prefervectorpath 'tuning\gOSI.mat'],'gOSI');
        save([prefervectorpath 'tuning\gDSI.mat'],'gDSI');
        save([prefervectorpath 'tuning\prefdir_loadseq.mat'],'prefdir_loadseq');


    else
    %load all the pref directions in an array
        load([prefervectorpath 'tuning\prefdir_vec_selecell.mat']);        
        load([prefervectorpath 'tuning\prefdir_basedori_selecell.mat']);
        load([prefervectorpath 'tuning\prefdir_mix_selecell.mat']);
        load([prefervectorpath 'tuning\DSI.mat']);
        load([prefervectorpath 'tuning\OSI.mat']);
        load([prefervectorpath 'tuning\gOSI.mat']);
        load([prefervectorpath 'tuning\gDSI.mat']);
        load([prefervectorpath 'tuning\prefdir_loadseq.mat']);
       
        endnum=size(prefdir_vec_selecell,1);
        prefdir_vec_selecell(endnum+1:(endnum+sum(select_ROI)),1)=sortdata.perfdir_vec_formula_degree(select_ROI);
        prefdir_basedori_selecell(endnum+1:(endnum+sum(select_ROI)),1)=sortdata.prefdir_vec_formula_degree_basedori_new(select_ROI);
        prefdir_mix_selecell(endnum+1:(endnum+sum(select_ROI)),1)=sortdata.prefdir_mix(select_ROI);
        DSI(endnum+1:(endnum+sum(select_ROI)),1)=sortdata.DSI_new_abs(select_ROI);
        OSI(endnum+1:(endnum+sum(select_ROI)),1)=sortdata.OSI(select_ROI);
        gOSI(endnum+1:(endnum+sum(select_ROI)),1)=sortdata.globalOSI(select_ROI);
        gDSI(endnum+1:(endnum+sum(select_ROI)),1)=sortdata.globalDSI(select_ROI);
        
        prefdir_loadseq(end+1,:)={sitename,endnum,endnum+sum(select_ROI),recordnum};
        save([prefervectorpath 'tuning\prefdir_vec_selecell.mat'],'prefdir_vec_selecell');  
        save([prefervectorpath 'tuning\prefdir_basedori_selecell.mat'],'prefdir_basedori_selecell');
        save([prefervectorpath 'tuning\prefdir_mix_selecell.mat'],'prefdir_mix_selecell'); 
        save([prefervectorpath 'tuning\DSI.mat'],'DSI');
        save([prefervectorpath 'tuning\OSI.mat'],'OSI');
        save([prefervectorpath 'tuning\gOSI.mat'],'gOSI');
        save([prefervectorpath 'tuning\gDSI.mat'],'gDSI');
        save([prefervectorpath 'tuning\prefdir_loadseq.mat'],'prefdir_loadseq');

    end
    clearvars -except selectmode ampMethod baselinemethod checktype saveflag calpath prefervectorpath preferpath RunFolderSeq RLBflag responsiveflag runind ;
    close all
end
%% plot
load([prefervectorpath 'tuning\prefdir_vec_selecell.mat']);        
load([prefervectorpath 'tuning\prefdir_basedori_selecell.mat']);
load([prefervectorpath 'tuning\prefdir_mix_selecell.mat']);
load([prefervectorpath 'tuning\DSI.mat']);
load([prefervectorpath 'tuning\OSI.mat']);
load([prefervectorpath 'tuning\gOSI.mat']);
load([prefervectorpath 'tuning\gDSI.mat']);
load([prefervectorpath 'tuning\prefdir_loadseq.mat']);

%plot distribution
binNumber_dir=8;
binInterval_dir=360/binNumber_dir;
%binResult_dir=zeros(ROInum,recordnum);
binDir=zeros(1,binNumber_dir);
for i=1:binNumber_dir
    binDir(i)=(i-1)*binInterval_dir;    
end
binhistcata_dir=[binDir-binInterval_dir/2 (binDir(end)-binInterval_dir/2+binInterval_dir)];
temp=[];
for i=1:size(prefdir_mix_selecell,1)
   if DSI(i,1)>=0.1
        if  prefdir_mix_selecell(i,1)>=337.5
           temp(end+1,1)=prefdir_mix_selecell(i,1)-360;
       else
           temp(end+1,1)=prefdir_mix_selecell(i,1);
       end
   end
end
figure
histogram(temp,binhistcata_dir,'Normalization','probability');

% plot DSI
figure
errorbar(mean(DSI),std(DSI)/sqrt(size(DSI,1)),'-o')


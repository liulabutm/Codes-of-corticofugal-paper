function output = sortonstim(parstruct, sortvar, sortdim, stim_sequence)
%parstruct, the parent structure on which new field is added;
%sortvar, variable to be sorted;
%sortdim, the dimension of sortvar to be sorted;
%stim_sequence, the sequence of stim based on which to sort. each colume saves values of one stim parameter

varstring = inputname(2);
if size(stim_sequence, 2)==1
    uniquestim=unique(stim_sequence);
    uniquestimnum=length(uniquestim);
elseif size(stim_sequence, 2)==2
    uniquestim1=unique(stim_sequence(:,1));
    uniquestimnum1=length(uniquestim1);
    uniquestim2=unique(stim_sequence(:,2));
    uniquestimnum2=length(uniquestim2);
    uniquestimnum=uniquestimnum1*uniquestimnum2;
end
parstruct.(varstring)=[];
for i=1:uniquestimnum
        if size(stim_sequence, 2)==1
            trialindex=find(abs(stim_sequence-uniquestim(i))<10^-8);
        elseif size(stim_sequence, 2)==2
            [sub1, sub2]=ind2sub([uniquestimnum1 uniquestimnum2], i);
            trialindex=find(abs(stim_sequence(:,1)-uniquestim1(sub1))<10^-8 & abs(stim_sequence(:,2)-uniquestim2(sub2))<10^-8);
        end
        switch length(size(sortvar))
            case 2
                switch sortdim
                    case 1
                        parstruct.(varstring)=cat(3, parstruct.(varstring), sortvar(trialindex,:));
                    case 2
                        parstruct.(varstring)=cat(3, parstruct.(varstring), sortvar(:,trialindex)); 
                end
            case 3
                switch sortdim
                    case 1
                        parstruct.(varstring)=cat(4, parstruct.(varstring), sortvar(trialindex,:,:));
                    case 2
                        parstruct.(varstring)=cat(4, parstruct.(varstring), sortvar(:,trialindex,:)); 
                    case 3
                        parstruct.(varstring)=cat(4, parstruct.(varstring), sortvar(:,:,trialindex));
                end
        end
end
output=parstruct;

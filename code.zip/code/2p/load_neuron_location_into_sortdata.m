% load neuron location into sortdata

global calpath prefervectorpath preferpath neuronlocationpath
globalpara;
ampMethod= 'peak';   %'peak' or 'integration'
%plottype='polar';   %'linear' or 'polar'
baselinemethod='pretrig';
saveflag=1;
%outlier=1;
%ignorecell=1;
VirusExp= 'all';   %'good'  or  'bad'   or  'control' or 'all' 
         
RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));
runind=[strfind((cell2mat(RunFolderSeq(:,2)))',1) strfind((cell2mat(RunFolderSeq(:,2)))',2) strfind((cell2mat(RunFolderSeq(:,2)))',3)];  %find which one is OS stim          
removeind=strfind(cell2mat(RunFolderSeq(runind,6))',0);  %find which one do not need to run within OS stim
runind(removeind)=[];  %remove the no-run one
switch VirusExp
    case 'all'
        runind=runind';
    case 'good'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[];
        runind=runind';
    case 'bad'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',2);  %remove the control group
        runind(removeind_2)=[]; 
        runind=runind';
    case 'control'
        removeind_1=strfind(cell2mat(RunFolderSeq(runind,8))',0);  %remove the bad expression
        runind(removeind_1)=[];
        removeind_2=strfind(cell2mat(RunFolderSeq(runind,8))',1);  %remove the good group
        runind(removeind_2)=[]; 
        runind=runind';
end
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};    
    stimtype=RunFolderSeq{runind(f),2};   %1=OS, 2=SF, 3=TF, 4=SI, 5=ori x SF
    Exptype=RunFolderSeq{runind(f),8};
    
    switch ampMethod
           case 'peak'
               load([calpath sitename '\peak\sortdata.mat']);
           case 'integration'
               load([calpath sitename '\integration\sortdata.mat']);
    end
    
    %neuron_location(sortdata.ignoreflag==1,:)=[];
    sortdata.Exptype=Exptype;
    
    
    if saveflag
        save([calpath sitename '\' ampMethod '\sortdata.mat'],'sortdata');
        %save([calpath sitename '\' ampMethod '\calFoutput.mat'],'calFoutput');    
    end
    
    
    
    
    clearvars -except neuronlocationpath ampMethod baselinemethod saveflag calpath prefervectorpath preferpath RunFolderSeq RLBflag responsiveflag runind ;
    close all
end
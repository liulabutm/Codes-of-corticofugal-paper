global NPYdataparentpath moviedataparentpath vsparaparentpath rawdataparentpath calpath
globalpara;

RunFolderSeq=table2cell(readtable([calpath 'RunFolderSeq.xlsx']));
runind=find(cell2mat(RunFolderSeq(:,6)));
for f=1:size(runind,1)
    sitename=RunFolderSeq{runind(f),1};
    temppos=strfind(sitename,'_');
    tempname=sitename(1:(temppos(end-1)-1));
    selpath=[rawdataparentpath '\' tempname];
    fastzflag=RunFolderSeq{runind(f),9};

    %read file name
    %selpath = uigetdir(rawdataparentpath, 'pick up a dir for original tif'); %select original tif
    filelist=dir(selpath);
    filelistsub={};%containing the file names of original tif
    for i=1:length(filelist)
        if ~isempty(strfind(filelist(i).name, '.tif'))
            filelistsub=[filelistsub filelist(i).name];
        end
    end
    
    %use first file to get the information about height, width
    filepathtemp=[selpath '\' filelistsub{1}];
    info=imfinfo(filepathtemp);
    numimgsperstim = size(info,1); % frame/movie  number of frames per stimulus of original tif
   
    backslashpos=strfind(selpath, '\');
    %createpath=mkdir(selpath(1:backslashpos(end)),[selpath(backslashpos(end)+1:end) '_comp']);
    createpath=mkdir(rawdataparentpath,[selpath(backslashpos(end)+1:end) '_remove']);

    remove_path=[rawdataparentpath selpath(backslashpos(end)+1:end) '_remove\'];
    actualImgHeight=round(info(1).Height);
    actualImgWidth=round(info(1).Width);
    
    parfor j=1:length(filelistsub)
        
        comp_im=zeros(actualImgHeight,actualImgWidth,200);
        for i=1:50
            for k=1:4
                tempI=double(imread([selpath '\' filelistsub{j}],(i-1)*6+k));
                comp_im(:,:,(i-1)*4+k)=tempI;
            end
        end
        for i=1:size(comp_im,3) 
            imwrite(uint16(comp_im(:,:,i)),[remove_path filelistsub{j}], 'WriteMode','append');% the min pixel value should be >=0
        end
    end
    filenum=length(filelistsub);
    imageformat='unit16';
    
    
    
end
    
    
    
    